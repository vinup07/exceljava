package stepDefinitionsUI;

import uiUtils.Driver;
import ui_aria.AriaAccountSearch;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Aria_Account_Overview extends Driver
{
	@Given("^Aria URL for logging in with valid credentials$")
	public void Aria_URL_for_logging_in_with_valid_credentials() throws Throwable {

		//invoke api;
	}

	@When("^Valid userid and password are present$")
	public void Valid_userid_and_password_are_present() throws Throwable {
	
		//invoke api;
	}
	
	@Then("^User should be successfully logged into Aria and Account overview page should be displayed$")
	public void user_should_be_successfully_logged_into_Aria_and_Account_overview_page_should_be_displayed() throws Throwable {
		Driver.launchbrowser();
		Driver.logintoAria();
		AriaAccountSearch.ariaAccountsearch();


	}
}