package stepDefinitionsUI;

import uiUtils.Driver;
import ui_ocs.OcsLogin;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OCS_Verify_Login extends Driver
{
	@Given("^OCS URL for logging in with valid credentials$")
	public void OCS_URL_for_logging_in_with_valid_credentials() throws Throwable {

		//invoke api;
	}

	@When("^Valid username and password are present$")
	public void Valid_username_and_password_are_present() throws Throwable {
	
		//invoke api;
	}
	
	@Then("^User should be successfully logged into OCS$")
	public void User_should_be_successfully_logged_into_OCS() throws Throwable {
		Driver.launchbrowser();
		Driver.logintoOcs();
		OcsLogin.ocsViewsubscriber();

	}
}