package stepDefinitionsUI;

import uiUtils.Driver;
import ui_tconnect.TConnectPayments;
import ui_tconnect.TConnect_Billingpage;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;

public class TConnect_Payment_Details extends Driver
{
	@Given("^TConnect URL for logging with credential$")
	public void TConnect_URL_for_logging_with_credential() throws Throwable {

		//invoke api;
	}

	@And("^User and Password are present$")
	public void User_and_Password_are_present() throws Throwable {
	
		//invoke api;
	}
	
	@And("^User successfully logged to TConnect$")
	public void User_successfully_logged_to_TConnect() throws Throwable {
		Driver.launchbrowser();
		Driver.logintoTConnect();

	}
	
	@When("^User is redirected to Billing webpage$")
	public void User_is_redirected_to_Billing_webpage() throws Throwable {
		TConnect_Billingpage.goToBilling();
	}
	
	@Then("^User is redirected to the Payments webpage$")
	public void User_is_redirected_to_the_Payments_webpage() throws Throwable {
		TConnectPayments.goToPayments();
	}

}
