package stepDefinitionsUI;

import uiUtils.Driver;
import ui_tconnect.TConnectInvoice;
import ui_tconnect.TConnect_Billingpage;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;

public class TConnect_Invoice_Details extends Driver
{
	@Given("^TConnect URL for logging in with credential$")
	public void TConnect_URL_for_logging_in_with_credential() throws Throwable {

		//invoke api;
	}

	@And("^Userid and Password are present$")
	public void Userid_and_Password_are_present() throws Throwable {
	
		//invoke api;
	}
	
	@And("^User is successfully logged to TConnect$")
	public void User_is_successfully_logged_to_TConnect() throws Throwable {
		Driver.launchbrowser();
		Driver.logintoTConnect();

	}
	
	@And("^User is redirected to the Billing webpage$")
	public void User_is_redirected_to_the_Billing_webpage() throws Throwable {
		TConnect_Billingpage.goToBilling();
	}
	
	@When("^User is redirected to Invoice webpage$")
	public void User_is_redirected_to_Invoice_webpage() throws Throwable {
		TConnectInvoice.goToInvoice();
	}
	
	@Then("^User is able to view invoice details for an account$")
	public void User_is_able_to_view_invoice_details() throws Throwable {
			//invoke api;
	}

}
