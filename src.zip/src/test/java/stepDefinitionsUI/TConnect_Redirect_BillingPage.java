package stepDefinitionsUI;

import uiUtils.Driver;
import ui_tconnect.TConnect_Billingpage;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;

public class TConnect_Redirect_BillingPage extends Driver
{
	@Given("^TConnect URL for logging in with credentials$")
	public void TConnect_URL_for_logging_in_with_credentials() throws Throwable {

		//invoke api;
	}

	@And("^Username and Password are present$")
	public void Username_and_Password_are_present() throws Throwable {
	
		//invoke api;
	}
	
	@When("^User is successfully logged into TConnect$")
	public void User_is_successfully_logged_into_TConnect() throws Throwable {
		Driver.launchbrowser();
		Driver.logintoTConnect();

	}
	
	@Then("^User is redirected to Billing page$")
	public void User_is_redirected_to_Billing_page() throws Throwable {
		TConnect_Billingpage.goToBilling();
	}
}