package stepDefinitionsUI;

import uiUtils.Driver;
import ui_tconnect.TConnect_Billingpage;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TConnect_Verify_Login extends Driver
{
	@Given("^TConnect URL for logging in with valid credentials$")
	public void TConnect_URL_for_logging_in_with_valid_credentials() throws Throwable {

		//invoke api;
	}

	@When("^Valid Username and Password are present$")
	public void Valid_Username_and_Password_are_present() throws Throwable {
	
		//invoke api;
	}
	
	@Then("^User should be successfully logged into TConnect$")
	public void User_should_be_successfully_logged_into_TConnect() throws Throwable {
		Driver.launchbrowser();
		Driver.logintoTConnect();

	}
}