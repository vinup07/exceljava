package stepDefinitionsUI;

import uiUtils.Driver;
import ui_tconnect.TConnectCreditAdj;
import ui_tconnect.TConnect_Billingpage;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;

public class TConnect_CreditAdj_Details extends Driver
{
	@Given("^TConnect link for logging with credential$")
	public void TConnect_link_for_logging_with_credential() throws Throwable {

		//invoke api;
	}

	@And("^Usernames and Password are present$")
	public void Usernames_and_Password_are_present() throws Throwable {
	
		//invoke api;
	}
	
	@And("^User successfully logged on to TConnect$")
	public void User_successfully_logged_on_to_TConnect() throws Throwable {
		Driver.launchbrowser();
		Driver.logintoTConnect();

	}
	
	@When("^User is redirected Billing webpage$")
	public void User_is_redirected_Billing_webpage() throws Throwable {
		TConnect_Billingpage.goToBilling();
	}
	
	@Then("^User is redirected to the Credit Adjustment webpage$")
	public void User_is_redirected_Credit_Adjustment_webpage() throws Throwable {
		TConnectCreditAdj.goToCredits();
	}

}
