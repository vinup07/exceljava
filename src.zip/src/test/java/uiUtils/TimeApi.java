package uiUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

public class TimeApi {

	public static void main(String[] args) {
		String Name="Rafiq";
		String NewName = Name.replaceAll("^\"|\"$", "");
		System.out.println(NewName);
	}

}
