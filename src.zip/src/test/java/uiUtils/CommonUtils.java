package uiUtils;

import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;

public class CommonUtils extends Driver {

	private static final Logger LOG = Logger.getLogger(CommonUtils.class);

	public static void waitForPageLoad() {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

	}

	public static void waitForElement(By locator) {
		WebDriverWait waitone = new WebDriverWait(driver, 30);
		waitone.until(ExpectedConditions.presenceOfElementLocated(locator));

	}

	public static void waitLongForElement(By locator) {
		WebDriverWait waitone = new WebDriverWait(driver, 2000);
		waitone.until(ExpectedConditions.presenceOfElementLocated(locator));

	}

	public static WebElement waitAndReturnElement(By locator) {
		WebDriverWait waitone = new WebDriverWait(driver, 10);
		WebElement elementone = waitone.until(ExpectedConditions.presenceOfElementLocated(locator));
		return elementone;
	}

	public static void waitAndClickElement(By locator) {
		WebDriverWait waitone = new WebDriverWait(driver, 10);
		WebElement elementone = waitone.until(ExpectedConditions.presenceOfElementLocated(locator));
		elementone.click();
	}

	public static void waitForFrameAndSwitch(String frameName) {
		WebDriverWait waitone = new WebDriverWait(driver, 10);
		WebElement elementone = (WebElement) waitone
				.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameName));
		elementone.click();
	}

	public static void waitForDataIntegration() throws InterruptedException {
		LOG.info("DataIntegration Break");
		Thread.sleep(30000);
		;

	}

	public static void waitForLoad(int sec) throws InterruptedException {
		Thread.sleep(sec);
		;

	}

	public static String getBackendAttributeText(By locator) {
		WebDriverWait waitone = new WebDriverWait(driver, 10);
		String eleAttribute = waitone.until(ExpectedConditions.presenceOfElementLocated(locator)).getText();
		return eleAttribute;

	}

	public static String getBackendAttributeValue(By locator) {
		WebDriverWait waitone = new WebDriverWait(driver, 10);
		String eleAttribute = waitone.until(ExpectedConditions.presenceOfElementLocated(locator)).getAttribute("value");
		return eleAttribute;

	}

	public static void selectByVisibleText(By locator, String VisibleText) {
		WebElement sel = waitAndReturnElement(locator);
		Select Category = new Select(sel);
		Category.selectByVisibleText(VisibleText);

	}

	public static void selectByValue(By locator, String value) {
		WebElement sel = waitAndReturnElement(locator);
		Select Category = new Select(sel);
		Category.selectByValue(value);

	}

	public static void switchToFrameByName(String value) {
		driver.switchTo().frame(value);

	}

	public static void switchToFrameById(String value) {
		driver.switchTo().frame(value);

	}

	public static void switchToFrameByIndex(int value) {
		driver.switchTo().frame(value);

	}

	public static void switchFromFrameToMainWindow() {
		driver.switchTo().defaultContent();

	}

	public static void performKeybordActionEnter() {
		Actions action = new Actions(driver);
		action.sendKeys(Keys.ENTER).build().perform();

	}

	public static void switchToChildWindow(WebDriver driver) {
		Set<String> set1 = driver.getWindowHandles();
		Iterator<String> win1 = set1.iterator();
		@SuppressWarnings("unused")
		String parent = win1.next();
		String child = win1.next();

		driver.switchTo().window(child);
		driver.manage().window().maximize();
	}

	public void switchToParanetWindow(WebDriver driver) {
		Set<String> set1 = driver.getWindowHandles();
		Iterator<String> win1 = set1.iterator();
		String parent = win1.next();
		driver.switchTo().window(parent);
	}

	public static String getAppointmentstartDate() throws IOException {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat dateFormat1 = new SimpleDateFormat("HH:mm:ss");
		Date date = new Date();
		String AppointmentStartDate = dateFormat.format(date) + "T" + dateFormat1.format(date);
		return AppointmentStartDate;
	}

	public static String getAppointmentEndDate(String method) throws IOException {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm:ss");

		Calendar c = Calendar.getInstance();
		c.setTime(new Date()); // Now use today date.
		c.add(Calendar.DATE, 02); // Adding 2 days
		String output1 = sdf.format(c.getTime());
		String output = sdf1.format(c.getTime());
		if (method.equalsIgnoreCase("UI")) {
			String AppointmentEndDate = output1 + " " + output;
			return AppointmentEndDate;
		} else {
			String AppointmentEndDate = output1 + "T" + output;
			return AppointmentEndDate;
		}

	}

	public static String getMobileNumber() throws IOException {
		int MNumber = 0;
		String addmobilenumber = "+61 ";
		MNumber = (int) ((Math.random() * 900000000) + 1000000);
		String MobileNumber = addmobilenumber+MNumber;
		System.out.print((MobileNumber));
		return MobileNumber;
	}

	public static void rightClickSave(WebDriver driver) throws InterruptedException {
		Actions action = new Actions(driver);
		action.moveToElement(
				driver.findElement(By.xpath("//nav[contains(@class,'ng-scope')]//div[@class='container-fluid']")))
				.build().perform();
		action.contextClick(
				driver.findElement(By.xpath("//nav[contains(@class,'ng-scope')]//div[@class='container-fluid']")))
				.build().perform();
		Thread.sleep(3000);
		action.click(driver.findElement(By.xpath("//div[text()='Save']"))).build().perform();
	}

	public static void windowscrollByToElement(WebElement element) {
		// JavascriptExecutor js = (JavascriptExecutor) driver;
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", element);

	}

	public static String getAppointmentEndDateNoslots(String method) throws IOException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm:ss");

		Calendar c = Calendar.getInstance();
		c.setTime(new Date()); // Now use today date.
		c.add(Calendar.DATE, 01); // Adding 10 days
		String output1 = sdf.format(c.getTime());
		String output = sdf1.format(c.getTime());
		if (method.equalsIgnoreCase("UI")) {
			String AppointmentEndDate = output1 + " " + output;
			return AppointmentEndDate;
		} else {
			String AppointmentEndDate = output1 + "T" + output;
			return AppointmentEndDate;
		}
	}

	public static String getAppointmentEndDateBookAnotherslot() throws IOException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm:ss");

		Calendar c = Calendar.getInstance();
		c.setTime(new Date()); // Now use today date.
		c.add(Calendar.DATE, 10); // Adding 10 days
		String output1 = sdf.format(c.getTime());
		String output = sdf1.format(c.getTime());
		String AppointmentEndDate = output1 + " " + output;
		return AppointmentEndDate;
	}

	public static String getAppointmentEndDateforAnotherslot() throws IOException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm:ss");

		Calendar c = Calendar.getInstance();
		c.setTime(new Date()); // Now use today date.
		c.add(Calendar.DATE, 9); // Adding 9 days
		String output1 = sdf.format(c.getTime());
		String output = sdf1.format(c.getTime());
		String AppointmentEndDate = output1 + "T" + output;
		return AppointmentEndDate;
	}

	public static String takeScreenshot(String filename) throws IOException {

		try {
			File file = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			String filePath = (System.getProperty("user.dir") + "//target//screenshot//" + filename + ".jpg");
			FileUtils.copyFile(file, new File(filePath));
			return filePath;
		} catch (WebDriverException e) {
			LOG.error(e.getMessage());
			return null;
		}
	}

}
