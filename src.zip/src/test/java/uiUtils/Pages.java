package uiUtils;



import org.openqa.selenium.By;


public class Pages {
	public static final String CONFIG_FILE_PATH = "src/test/java/Config/";
	
	
	 	/*--------------------------------------- T-Connect Objects ------------------------------------------*/
		public static String tCurl="https://qa.connectapp.telstra.com";
		public static String tCuname="Sandra.Young2@team.telstra.com";
		public static String tCpwd="TCApp2SServe_4BE";
		public static By signin=By.xpath("//form/button");
		public static By user=By.id("username");
		public static By pass=By.id("password");
		
		//-- Billing Page --//
		public static By bills=By.linkText("View and manage your bills");
		public static By invoices=By.linkText("Invoices");
		//public static By clickinvoices=By.xpath("//div[@class='tc-limit']");
		public static By bansearch=By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/a[1]");
		public static By bansearch1=By.xpath("//input[@class='text-field']");
		public static By bandisplay=By.xpath("//span[@class='highlight-text']");
		//public static By bandetails=By.xpath("//div[@class='tc-cell col-xs-2 tc-account-id ui-account-id']//div[@class='tc-vcenter']");
		public static By bandetails=By.xpath("//*[@id='root']/div/div/div/div[2]/div/div/div[2]/div[2]/div/div/div[2]/div[1]/div/div/a/div/div[1]/div/div/div");
		public static By pdfdwnld=By.xpath("//*[@id='root']/div/div/div/div[2]/div/div/div[4]/div/div[1]/div[1]/button[1]");
		public static By csvdwnld=By.xpath("//*[@id='root']/div/div/div/div[2]/div/div/div[4]/div/div[1]/div[1]/button[2]");
		public static By payments=By.linkText("Payments");
		public static By adjustments=By.linkText("Credit adjustments");
	
		public static By accid=By.xpath("//div[@class='tc-limit' and contains(text(),'700000480470')]");
		public static By Filter_Nav=By.xpath(".//*[@id='filter']");

		
		 /*--------------------------------------- OCS Objects ------------------------------------------*/
		 
		
		public static String Ocsurl="http://wdvuser:test123@ocstool-host.devopnet.in.telstra.com.au/OCS_STK.html";
		//public static String Ocsuname="wdvuser";
		//public static String Ocspwd="test123";
		
		
		//-- Main Page --//
		
		public static By OcsViewSubscriberProfile=By.xpath("/html[1]/body[1]/div[1]/ul[1]/li[2]");
		public static By Ocsmsisdn=By.cssSelector("body>form>p:nth-child(1)>input[type=text]");
		public static By OcsNode=By.xpath("/html[1]/body[1]/form[1]/p[1]/select[1]/option[4]");
		public static By OcsViewSubscriber=By.xpath("/html[1]/body[1]/form[1]/p[2]/input[1]");
		
				
		
		
	 
		/*--------------------------------------- Aria Objects ------------------------------------------*/
	 
	 	public static String ARurl="https://sa.thyra.telstra.com/SecureAuth243/";
		public static String ARuname="d898452";
		public static String ARpwd="01Dupoo@10";
		public static By userid=By.xpath("//*[@id='ContentPlaceHolder1_MFALoginControl1_UserIDView_txtUserid_UiInput']");
		public static By password=By.xpath("//*[@id='ContentPlaceHolder1_MFALoginControl1_UserIDView_tbxPassword_UiInput']");
		public static By submit=By.xpath("//*[@id='ngView']/div[2]/div[1]/user-id-button/div/div/a");
		
		//---- Accounts Page ---//
		public static By account=By.xpath("//*[@id='ui-id-3']/a/div");
		public static By search=By.xpath("//div[@class='navCss'][contains(text(),'Search')]");
		public static By search_value=By.xpath("//*[@id='QuickSearch_searchValue']");
		public static By search_button=By.xpath("//button[@id='QuickSearch_searchButton']");
		public static By accountovrview=By.xpath("/html[1]/body[1]/div[1]/div[3]/div[1]/div[1]/div[2]/div[3]");
		public static By balancedetails=By.xpath("//*[@id='content-wrapper']/div[4]");
		
		//---- Plans Page ---//
		public static By plan=By.partialLinkText("View All Plans");
    
    	//-- Main Page --//
		
		public static String Filter_value_plrTransaction="PLR Transactions";
		public static String incident="Incident.LIST";
		public static String ouboundTransactionlogs="outbound transaction";
		public static String inboundTransactionlogs="Inbound transaction";

 
		 	//---- Accounts Page ---//
		 public static By accountSelectFilter=By.xpath("//select[@class='form-control']");
		 public static By accountSearchField=By.xpath("//div[@class='input-group']//input[@placeholder='Search']");
		 public static By accountNameLink=By.xpath("//a[@class='linked formlink']");
		 public static By accountNameField=By.xpath("//input[@id='customer_account.name']");
		 public static By accountCIDNField=By.xpath("//input[@id='customer_account.u_cidn']");
		 public static By accountCACNumberField=By.xpath("//input[@id='customer_account.u_cac']");
		 public static By accountCustomerTypeField=By.xpath("//input[@id='customer_account.u_customer_type']");
		 public static By accountSourceIdField=By.xpath("//input[@id='customer_account.u_sourceid']");
		 public static By accountSourceField=By.xpath("//input[@id='customer_account.u_source']");
		 public static By accountRelationshipTab=By.xpath("//*[@id='tabs2_list']/span[8]/span");
		 public static By relationshipTypeLink=By.xpath("//table[@id='customer_account.account_relationship.from_company_table']/tbody/tr/td[3]/a");
		
		 public static By accSaveBtn=By.xpath("//button[@title='Save']");
		 public static By accPartnerAccCheck=By.xpath("//input[@id='customer_account.partner']");
		 public static By accPageSourceIdField=By.xpath("//input[@id='sys_readonly.customer_account.u_sourceid']"); 
	
		 	//---- Contacts Page ---//
		 public static By contactSearchField=By.xpath("//div[@class='input-group']//input[@placeholder='Search']");
		 public static By contactNameLink=By.xpath("//a[@class='linked formlink']");
		 public static By contactFirstName=By.xpath("//*[@id='customer_contact.first_name']");
		 public static By contactLastName=By.xpath("//*[@id='customer_contact.last_name']");
		 public static By contactEmailId=By.xpath("//*[@id='customer_contact.email']");
		 public static By contactBusinessNumber=By.xpath("//*[@id='customer_contact.phone']");
		 public static By contactMobileNumber=By.xpath("//*[@id='customer_contact.mobile_phone']");
		 public static By contactSource=By.xpath("//*[@id='sys_readonly.customer_contact.source']");
		 public static By contactManager=By.xpath("//input[@name='customer_contact.manager_label']");
		 public static By contactSelectFilter=By.xpath("//*[@id='customer_contact_hide_search']//select");

			//---- Location Page ---//
		 public static By locationSearchField=By.xpath("//div[@class='input-group']//input[@placeholder='Search']");
		 public static By locationNameLink=By.xpath("//a[@class='linked formlink']");
		 public static By locationNameField=By.xpath("//div[label[span[text()='Name']]]/following::div/input[@id='cmn_location.name']");
		 public static By locationAddressIDField=By.xpath("//input[@id='cmn_location.u_address_id']");
		 public static By locationSelectFilter=By.xpath("//select[@class='form-control']");
		 public static By locationAccField=By.xpath("//input[@id='cmn_location.account_label']");
																						 
		 
		 /*--------------------------------------- Sales force Objects ------------------------------------------*/
		 
		 //--- Login ---//
		public static By login_Btn = By.id("Login");
		public static By sFuser_Field = By.id("username");
		public static By sFpass_Field = By.id("password");
		public static String sFurl=	"https://telstrab2b--TB2BQA2.cs116.my.salesforce.com/";
		public static String sFuname="saiprakash.karra@team.telstra.com.tb2bqa2";
		public static String sFpwd="Mits^1998";

		public static String sFuser_name="anoop.Kwatra@team.telstra.com.tb2bqa2";
	    public static String sFpass_word="Feb@2018";
	    
	    // --- logout ---//
	    public static By profileViewButton=By.xpath("//div[@class='profileTrigger branding-user-profile bgimg slds-avatar slds-avatar_profile-image-small circular forceEntityIcon']//span[@class='uiImage']");
	    public static By logoutLink=By.xpath("//a[@class='profile-link-label logout uiOutputURL']");
	  
	 	//---- Accounts Page ---//
		public static By testAccount_button=By.xpath("//*[@id='idp_section_buttons']/button");
		public static By loginn=By.id("Login");
		public static By sFuser=By.id("username");
		public static By sFpass=By.id("password");
		public static By accName=By.xpath("//div[label[span[text()='Account Name']]]/input");
		public static By cIDNField=By.xpath("//div[contains(@class,'slds-form-element__control')]//div[label[span[text()='CIDN']]]/input");
		public static By cacNumberField=By.xpath("//div[contains(@class,'slds-form-element__control')]//div[label[span[text()='CAC']]]/input");
		public static By accCustomerTypeSelect=By.xpath("//span[span[text()='Type']]/following-sibling::div//a[@class='select']");
		public static By accCustomerStatusSelect=By.xpath("//span[span[text()='Customer Status']]/following-sibling::div//a[@class='select']");
		public static By allAccount=By.xpath("//span[@class='slds-truncate'][contains(text(),'Accounts')]");
		public static By allContact=By.xpath("//span[@class='slds-truncate'][contains(text(),'Contacts')]");
		public static By accPageCheck=By.xpath("//span[@title='Follow']");
		public static By accountNewBtn=By.xpath("//div[@title='New']");
		public static By accountEditBtn=By.xpath("//div[@title='Edit']");
		
		
		
		
			//-- Contact Page --//
		public static By contactNewBtn=By.xpath("//div[@title='New']");
		public static By contactEditBtn=By.xpath("//div[@title='Edit']");
		public static By cntPrfName=By.xpath("//label/span[contains(text(),'Preferred Name')]/following::input[1]");
		public static By cntAccName=By.xpath("//label/span[contains(text(),'Account Name')]//following::div/input[@title='Search Accounts']");
		public static By cntSelAccName=By.xpath("//div[div[@title='12345']]");
		public static By cntPageCheck=By.xpath("//div[@title='Edit']");
		public static By cntTitle=By.xpath("//div[@class='salutation compoundTLRadius compoundTRRadius compoundBorderBottom form-element__row uiMenu']//a[text()='--None--']");
		public static By cntTitleMr=By.xpath("//a[@title='Mr']");
		public static By cntFirstName=By.xpath("//input[@class='firstName compoundBorderBottom form-element__row input']");	
		public static By cntLastName=By.xpath("//input[@class='lastName compoundBLRadius compoundBRRadius form-element__row input']");		
		public static By cntEmail=By.xpath("//input[@type='email']");
		public static By cntMobile=By.xpath("//label[span[text()='Mobile']]/following-sibling::input[@type='tel']");
		public static By cntBusiness=By.xpath("//label[span[text()='Phone']]/following-sibling::input[@type='tel']");
		public static By cntReportTo=By.xpath("//label[span[text()='Reports To']]/following-sibling::div//input[@title='Search Contacts']");
		public static By cntSelReportTo=By.xpath("//mark[contains(text(),'Autochsm4')]");
		public static By cntSaveBtn=By.xpath("//button[@title='Save']/span[text()='Save']");	
		
		
			//-- New ACR creation Page --//
		public static By cntRelatedLink=By.xpath("//div[@class='windowViewMode-normal oneContent active lafPageHost']//span[text()='Related']");	
		public static By addRelationshipButton=By.xpath("//div[text()='Add Relationship']");	
		public static By acrAccountField=By.xpath("//div[text()='Add Relationship']");	
		public static By acrSelAccName=By.xpath("//div[div[text()='8899460638']]");	
		public static By acrSaveButton=By.xpath("//span[text()='Save']");	
		public static By acrJobFunctionList=By.xpath("//div[span[span[text()='Job Function']]]/div/div/div/div");	
		public static By acrJobFunctionListValue=By.xpath("//a[contains(@title,'Accounting')]");	
		public static By acrJobSeniorityList=By.xpath("//div[span[span[text()='Seniority Level']]]/div/div/div/div");	
		public static By acrJobSeniorityListValue=By.xpath("//a[contains(@title,'Board Member')");	
		public static By accountOpportunityLink=By.xpath("//div[contains(@class,'windowViewMode-normal oneContent active lafPageHost')]//div[contains(@class,'container')]//div[1]//article[1]//div[1]//div[1]//div[1]//ul[1]//li[1]//a[1]//div[1]");
		
			//-- New Site Creation --//
		public static By siteNewButton=By.xpath("//div[header[div[h2[a[span[text()='Sites']]]]]]/descendant::div[text()='New']");
		public static By siteSearchField=By.xpath("//*[@placeholder='Search Addresses']");
		public static By siteNewAddressButton=By.xpath("//span[contains(@class,'slds-lookup__item-action slds-lookup__item-action--label')]/span");
		public static By siteAdborIdButton=By.xpath("//span[text()='ADBOR ID']");
		public static By siteAdborIdValueField=By.xpath("//*[@placeholder='Please enter only numeric values for adborid']");
		public static By siteSearchBtn=By.xpath("//footer/button[text()='Search']");
		public static By siteSelectList=By.xpath("//*[@id='141302481']");
		public static By siteNameField=By.xpath("//*[@name='SiteName']");
		public static By siteAddressField=By.xpath("//div/div/div[2]/div/div/div[2]/div[2]/div/div/div/div/div[1]/span/span");
		
		public static By siteSaveBtn=By.xpath("//button[text()='Save']");

		
		 /*------------------------------- ----------- Appointment Management --------------------------------*/   
		   
		 public static By caseNewCreate=By.xpath("//*[a[span[text()='Cases']]]//div[text()='Create New']");   
		 public static By clickaddattachment=By.xpath("//div[@class='navbar-right']//button[@id='header_add_attachment' and @data-original-title='Manage Attachments']");
		 public static By clickChooseFile=By.xpath(" //input[@id='loadFileXml']");
         public static By CloseAttachment=By.xpath("//button[@id='attachment_closemodal']");

		 public static By clickContactsLink=By.xpath("//div[@class='sn-widget-list-title' and contains(text(),'Contacts')]");
		 public static By clickTelstrafieldsupportLink=By.xpath("//div[@class='sn-widget-list-title' and contains(text(),'Telstra Field Supports')]");
		 
		 public static By ApptsearchID=By.xpath("//input[@id='x_teeag_telstra_ap_telstra_appointments_table_header_search_control']");
		 
		    
		    public static By clickAll=By.xpath("//a[@id='50abb177c342310015519f2974d3aead']//div[@class='sn-widget-list-title' and text()='All']");
		    public static By ClickIncidents=By.xpath("//div[@class='sn-widget-list-title' and text()='Incidents']");
		 
		    public static By clickNew=By.xpath("//button[@type='submit' and text()='New']");
		    public static By clickCancel=By.xpath("//button[@id='15a7e6d0dbadb300caede2564a961917' and contains(text(),'Cancel')]");
		 
		    public static By clickNew_Inc=By.xpath("//a[@id='8f0ab177c342310015519f2974d3ae12']//div[@class='sn-widget-list-title' and contains(text(),'Create New')]");
		   
		    public static By numberSearch=By.xpath("//input[@id='sn_customerservice_case_table_header_search_control' and @type='search']");
		    public static By numberSearchInc=By.xpath(" //input[@type='search' and @id='incident_table_header_search_control']");
		 
		   public static By caseSelectFilter=By.id("sn_customerservice_case.category");
		   public static By ReschdeuleReasonCode=By.xpath("//select[@id='x_teeag_telstra_ap_telstra_appointments.reschedule_reason']");
		
		   public static By caseCreateContact=By.id("sys_display.sn_customerservice_case.contact");
		   public static By caseCreateAsset=By.id("sys_display.sn_customerservice_case.asset");
		   public static By caseCreateShortDescription=By.id("sn_customerservice_case.short_description");
		   public static By caseSubmit=By.xpath("//*[@id='sysverb_insert' and text()='Submit']");
		   public static By caseSave=By.xpath("//*[@id='sysverb_update_and_stay' and text()='Save']");
		   public static By IncSubmit=By.xpath("//button[@type='submit' and contains(text(),'Submit')]");
		   public static By ContactSubmit=By.xpath(" //button[@id='sysverb_insert' and contains(text(),'Submit')]");
		 
		   public static By Update=By.xpath("//button[@id='sysverb_update']");
		 
		   public static By incidentNewCreate=By.xpath("//span[contains(text(),'Incidents (1)')]");
		   public static By CaseNumber=By.xpath("//div[@class='navbar-title-display-value']");
		   public static By AppointmentNumber=By.xpath("//div[@class='navbar-title-display-value' and contains(text(),'TNE00')]");
		   public static By getIncNumberfromCase=By.xpath("//div[@class='outputmsg_text']");
		   public static By getIncNumber=By.xpath("//div[@class='navbar-title-display-value']");
		   public static By ClickCreatedInc=By.xpath("//a[@class='linked formlink' and contains(text(),'TNI0')]");
		   public static By ClickCreatedContact=By.xpath("//a[@class='linked formlink']");
		   public static By IncNumber=By.xpath("//div[@class='navbar-title-display-value']");
		   public static By clickOnINcidentTab=By.xpath("//span[@class='tab_caption_text' and contains(text(),'Incidents')]");
		   public static By SelectSlot=By.xpath("//input[@id='radioId']");
		   public static By CancelSlotWindow=By.xpath("//input[@class='btn btn-danger']");
		   public static By OkSlotWindow=By.xpath("//input[@class='btn btn-primary btn-sm']");
		   public static By SubmitSlotWindow=By.xpath("//input[@id='btn']");
		   public static By SubmitSlotWindowforReschedule=By.xpath("//input[@class='btn btn-primary']");
		   public static By CloseAPPTWindow=By.xpath("//button[@id='x_teeag_telstra_ap_bookedTimeSlot_closemodal']");
		   public static By CloseNBNAPPTWindow=By.xpath("//button[@id='x_teeag_nbn_field_INF_R2R_CA_NBN_Field_Support_closemodal']");
		 
		   
		   public static By CloseupdateWindow=By.xpath("//button[@id='close-messages-btn']");
		   public static By APPTMenubutton=By.xpath("//button[@class='btn btn-icon icon-menu navbar-btn additional-actions-context-menu-button']");
		   public static By Reloadform=By.xpath("//div[@href='reloadWindow(window);']");
		   
		 
		 
		   public static By clickOnExternalTab=By.xpath("//span[@class='tab_caption_text' and contains(text(),'External')]");
		   public static By clickOnNEW=By.xpath("//nav[@id='list_nav_incident.u_external_task.parent']//button[@gsft_id='7b37cc370a0a0b34005bd7d7c7255583']");
		   public static By clickOnINcident=By.xpath("//a[contains(text(),'TNI') and @class='linked formlink']");
		   public static By incidentAssignmentGroup=By.xpath("//input[@name='sys_display.incident.assignment_group']");
		   public static By clickonTelstraFieldSupport=By.xpath("//div[@class='container-fluid wizard-container' ]//a[contains(text(),'Telstra Field Support')]");
		   public static By clickonNBNFieldSupport=By.xpath("//div[@class='container-fluid wizard-container' ]//a[contains(text(),'NBN Field Support')]");
		   
		   public static By incidentUpdate=By.id("sysverb_update");
		  //public static By incidentNumber=By.id("sys_readonly.incident.number");
		   public static By ItamExternalReference=By.id("incident.correlation_display");
		   public static By incidentCategory=By.id("incident.category");
		   public static By incidentSubCategory=By.id("incident.subcategory");
		   // public static By ouboundlogsITAM=By.xpath("//div[text()='Outbound transactions']");
		   public static By itamIntegration=By.xpath("//span[contains(text(),'ITAM Integration')]");
		   public static By ouboundlogsITAM=By.xpath("//div[@class='sn-widget-list-title' and text()='Outbound Transaction']");
		   
		  // public static By generateOutboundLogwithInc=By.xpath("//span[@class='sr-only' and text()='Press Enter from within the input to submit the search.']");
		  public static By generateOutboundLogwithInc=By.xpath("//input[@id='x_teeag_payload_pr_outbound_transaction_log_table_header_search_control']");
		
		   //public static By generateOutboundLogwithInc=By.xpath("//input[@class='form-control' and @placeholder='Search']//preceding-sibling::span[@class='sr-only' and text()='Press Enter from within the input to submit the search.']");
		  // public static By generateInboundLongwithItam=By.xpath("//div[text()='Outbound transactions']");
		   
		   
		   public static By incidentvalue=By.xpath("//input[@id='00b230fedbe3270033b5c4048a9619bb_text']");
		   
		   public static By selectGoto=By.xpath("//select[@class='form-control']");
		   
		   public static By iTAMClickOnlogs=By.xpath("//a[@class='linked formlink']");
		   public static By iTAMlogsReturn=By.xpath("//textarea[@id='x_teeag_payload_pr_outbound_transaction_log.request']");
		   public static By inboundLogsITAM=By.xpath("//div[text()='Inbound transaction']");
		   //public static By incidentNumberSearch=By.xpath("//INPUT[@placeholder='Search']");
		   public static By incidentNumberSearch=By.xpath("//input[@placeholder='Search' and @type='search' and @id='incident_table_header_search_control']");
		   public static By clickONIncident=By.xpath("//a[@class='linked formlink']");
		   public static By additionalComment=By.id("activity-stream-comments-textarea");
		  // public static By Update=By.xpath("//span[@class='ui_action_container_primary']//*[@id='sysverb_update']");
		   public static By incidentStatus=By.xpath("");
		   public static By plrTransaction=By.xpath("//div[text()='PLR Transactions']");
		   public static By outboundTransactionLogs=By.xpath("//div[@class='sn-widget-list-title' and contains(text(),'Outbound Transaction Logs')]");
		   public static By InboundTransactionLogs=By.xpath("//div[@class='sn-widget-list-title' and contains(text(),'Inbound Transaction')]");
		   
		   public static By Outboundsearch =By.xpath("//input[@id='x_teeag_payload_pr_outbound_transaction_log_table_header_search_control']");
		   public static By OutboundResponseSearch =By.xpath("//input[@aria-label='Search column: response']");
		   public static By OutboundRequestSearch =By.xpath("//input[@aria-label='Search column: request']");
		   public static By OutboundTargetSearch =By.xpath("//input[@aria-label='Search column: target']");
		   public static By InboundRequestSearch =By.xpath(" //input[@aria-label='Search column: request']");
			   
		  
		   public static By PlrSearch =By.xpath("//div[@class='input-group-transparent']//input[@type='search' and @aria-label='Search column: key identifier']");
		   public static By eventTimestampClick = By.xpath("//a[@class='column_head list_hdrcell table-col-header' and @ data-original-title='Sorted in ascending order']");
		   public static By SelectfirstLog=By.xpath("//a[@class='linked formlink']");
		   public static By SelectfirstLogforOutboundTransactionLog=By.xpath("//*[@class='list_row list_odd']");
		   public static By GetRequest=By.xpath("//textarea[@id='x_teeag_payload_pr_outbound_transaction_log.request']");
		   public static By GetResponse=By.xpath("//textarea[@id='x_teeag_payload_pr_outbound_transaction_log.response']");
		   
		   public static By GetRequestInbound=By.xpath("//textarea[@id='x_teeag_payload_pr_inbound_transaction_log.request']");
		   public static By GetResponseInbound=By.xpath("//textarea[@id='x_teeag_payload_pr_inbound_transaction_log.response']");
		   
		   
		   public static By SelectsecondLog=By.xpath("//*[@class='list_row list_even']/td[3]/a");
		   public static By PIIAccessArray=By.xpath("//textarea[@id='x_teeag_plr_trans_u_plr_transactions.u_pii_access_ary']");
		   public static By PIIindicatorCount=By.xpath("//input[@name='x_teeag_plr_trans_u_plr_transactions.u_pii_ind_count']");
		   public static By RecordType=By.xpath("//input[@type='hidden' and @id='sys_original.x_teeag_plr_trans_u_plr_transactions.u_record_type']");
		   public static By UserID=By.xpath("//input[@id='x_teeag_plr_trans_u_plr_transactions.u_userid']");
		   
		
		 /*----------------------------------- Excel TestData Details ----------------------------------------*/
		
	     public static final String Path_TestData = System.getProperty("user.dir") + "//DataSheet//TestData.xlsx";
																								   
	
		
}
