package uiUtils;

import java.awt.AWTException;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.apache.log4j.Logger;


import uiUtils.Pages;

public class Driver {
	private static final Logger LOG = Logger.getLogger(Driver.class);
	public static WebDriver driver;

	static Properties Prop = new Properties();

	public static void launchbrowser() throws InterruptedException, IOException {
		FileInputStream fis = new FileInputStream("config/config.properties");
		Prop.load(fis);
		final String bType = Prop.getProperty("browserType");
		if (bType.equals("Chrome")) {
			ChromeOptions chromeOptions = Browsers.getChromeDesiredCapabilities();
			System.setProperty("webdriver.chrome.driver", "tools/chrome/chrome75/chromedriver.exe");
			driver = new ChromeDriver(chromeOptions);
			Thread.sleep(5000);
			driver.manage().window().maximize();
			
			LOG.info("Driver Initialized");
		}
		
		LOG.info("Browser is launched");
		
	  
	}

	public static void logintoTConnect() throws InterruptedException {
		LOG.info("Launching TConnect");
		driver.manage().window().maximize();
		driver.get(Pages.tCurl);
		LOG.info("Redirected to URL: " + Pages.tCurl);
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.findElement(Pages.user).sendKeys(Pages.tCuname);
		driver.findElement(Pages.pass).sendKeys(Pages.tCpwd);
		driver.findElement(Pages.signin).click();
		LOG.info("Logged in TConnect");
	}

	public static void logintoAria() throws InterruptedException {
		LOG.info("Launching Aria");
		driver.manage().window().maximize();
		driver.get(Pages.ARurl);
		LOG.info("Redirected to URL: " + Pages.ARurl);
		driver.manage().window().maximize();
		// driver.switchTo().frame("gsft_main");
		Thread.sleep(10000);
		driver.findElement(Pages.userid).sendKeys(Pages.ARuname);
		driver.findElement(Pages.password).sendKeys(Pages.ARpwd);
		driver.findElement(Pages.submit).click();
		LOG.info("Logged in Aria");
	}
	
	public static void logintoOcs() throws InterruptedException {
		LOG.info("Launching OCS Tool");
		driver.manage().window().maximize();
		driver.get(Pages.Ocsurl);
		LOG.info("Redirected to URL: " + Pages.Ocsurl);
		driver.manage().window().maximize();
		// driver.switchTo().frame("gsft_main");
		Thread.sleep(2000);
		//driver.findElement(Pages.user).sendKeys(Pages.Ocsuname);
		//driver.findElement(Pages.pass).sendKeys(Pages.Ocspwd);
		//driver.findElement(Pages.signin).click();
		LOG.info("Logged in OCS Tool");
	}
	

	public static void login_to_Salesforce() throws InterruptedException {
		LOG.info("Launching Salesforce");
		driver.get(Pages.sFurl);
		LOG.info("Redirected to URL: " + Pages.sFurl);
		driver.manage().window().maximize();
		CommonUtils.waitForPageLoad();
		driver.findElement(Pages.sFuser).sendKeys(Pages.sFuname);
		driver.findElement(Pages.sFpass).sendKeys(Pages.sFpwd);
		driver.findElement(Pages.loginn).click();
		CommonUtils.waitForPageLoad();
		CommonUtils.waitForPageLoad();

		LOG.info("Logged in to SalesForce");
	}

}
