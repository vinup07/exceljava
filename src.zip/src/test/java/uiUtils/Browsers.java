package uiUtils;

import java.util.logging.Level;

//import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Browsers {
	
	public static ChromeOptions getChromeDesiredCapabilities() {
		LoggingPreferences logs = new LoggingPreferences();
		logs.enable(LogType.DRIVER, Level.OFF);
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(CapabilityType.LOGGING_PREFS, logs);
		// capabilities.setCapability(CapabilityType.PROXY, Params.PROXY);
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("--disable-web-security");
		chromeOptions.addArguments("--test-type");
		chromeOptions.addArguments("--disable-notifications");
		chromeOptions.addArguments("--disable-extensions");
		chromeOptions.addArguments("disable-popup-blocking");
		capabilities.setCapability("chrome.verbose", false);
		capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
		chromeOptions.merge(capabilities);
		return chromeOptions;
	}
	public static DesiredCapabilities getFireFoxDesiredCapabilities() {
		LoggingPreferences logs = new LoggingPreferences();
		logs.enable(LogType.DRIVER, Level.OFF);
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		capabilities.setBrowserName("firefox");
		capabilities.setCapability("disable-restore-session-state", true);
		// capabilities.setCapability(CapabilityType.PROXY, Params.PROXY);
		capabilities.setCapability("marionette", true);
	//	capabilities.setCapability(CapabilityType.PROXY, Params.PROXY);
		return capabilities;
	}
//	public static DesiredCapabilities getIEDesiredCapabilities() {
//		LoggingPreferences logs = new LoggingPreferences();
//		logs.enable(LogType.DRIVER, Level.OFF);
//		DesiredCapabilities capabilities = new DesiredCapabilities();
//		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
//		capabilities.setBrowserName("IE");
//		capabilities.setCapability("disable-restore-session-state", true);
//		// capabilities.setCapability(CapabilityType.PROXY, Params.PROXY);
//		capabilities.setCapability("marionette", true);
//	//	capabilities.setCapability(CapabilityType.PROXY, Params.PROXY);
//		return capabilities;

//}
}
