package api;


import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.log4j.Logger;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import java.util.*;
import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;

import static apiUtils.GlobalConstants.Okapi;
import static apiUtils.GlobalConstants.PaymentRetrievalURL;
import static io.restassured.specification.ProxySpecification.host;
import static org.junit.Assert.assertEquals;

public class PaymentBds {

    static Logger log = Logger.getLogger(PaymentBds.class);
    static int num = 10, count = 1;

    public static void PaymentRet() {
        try {
            String token = AllocateBAN.getToken ();
            int statuscode = PaymentRetr (token);
        }catch (Exception e){
            System.out.println (e.getMessage ());
            log.fatal ("T-Connect :Payment Retrieval from BDS to ARIA failed and needs investigation");
            e.printStackTrace ();

        }
    }

    public static int PaymentRetr(String token) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
    	Properties p=new Properties();
    	p.load(reader);
    	String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
        RequestSpecification tokenRequest = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth("d318101", decodedPassword));
        tokenRequest.auth().none();
        tokenRequest.header("Content-Type", "application/json");
        String tokenHeader = "Bearer " + token;
        tokenRequest.header("Authorization", tokenHeader);
        UUID uuid = UUID.randomUUID();
        tokenRequest.header("correlation-Id", uuid.toString());
        tokenRequest.header("source-System", "TConnect");
        tokenRequest.config(AllocateBAN.setCertificates());

        File file = new File ("payinput.txt");

        Scanner sc = new Scanner (file);

        String Input = null;
        int a=0;
        String Pay_id[] = new String [5];
        //  for ( array[a]=1; array[a]<=2; array[a]++){
        while (sc.hasNextLine ()) {
            Input = sc.nextLine ();
            System.out.println (Input);
            Pay_id[a] =  Input;
            a++;
        }
        sc.close ();
        String Billing_no =  Pay_id[0];
        String Invoice_no =  Pay_id[1];
        System.out.println(Billing_no);
        System.out.println(Invoice_no);

        Response tokenResponse = tokenRequest.get (PaymentRetrievalURL + Billing_no + "/invoices/" + Invoice_no + "/payments");

        Assert.assertEquals(200 , tokenResponse.getStatusCode());

        tokenResponse.then().log().all();

        JsonPath jsonRespBody = tokenResponse.jsonPath();
        log.info("Payment Retrieval Response:--->" + tokenResponse.asString ());

        int statuscode = jsonRespBody.get("status");
        return statuscode;
    }
    
    public static String getToken_PaymentProcessor() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException
	{
		FileReader reader = new FileReader("configs/credentialSetting.properties");
		Properties p = new Properties();
		p.load(reader);
		String decodedPassword = utils.EncryptPassword.decryptPassword(p.getProperty("password"));
		RequestSpecification tokenRequest = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
		log.warn("Invoked Okapi URL by passing proxy credentials");
		RestAssured.useRelaxedHTTPSValidation();
		tokenRequest.relaxedHTTPSValidation();
		tokenRequest.auth().none();
		log.info("Retrieve token from Okapi to authorize the transaction");
		tokenRequest.header("Content-Type", "application/x-www-form-urlencoded");
//		tokenRequest.config(setCertificates());
		tokenRequest.config(AllocateBAN.setCertificates());
		String bodyToken = "clie" + "nt_id=7lS4Eo2rFo68fofJIikvQGVTdV8TwOyo&client_secret=FaDQw7xRr542vB7C&grant_type=client_credentials&App Name=B2B-U2C-Agilebiller-PP-Application-Testing";
		tokenRequest.body(bodyToken);
		Response tokenResponse = tokenRequest.post(Okapi);
		System.out.println(tokenResponse.asString());
		tokenResponse.then().log().all();
		JsonPath jsonRespBody = tokenResponse.jsonPath();
		String bdsToken = "";
		bdsToken = jsonRespBody.get("access_token");
		System.out.println("Generated Token : " + bdsToken);
		assertEquals(200, tokenResponse.getStatusCode());
		log.info("Token Response:--->" + tokenResponse.asString());
		if (bdsToken == null)
		{
			while (count <= num)
			{
				count++;
				System.out.println("Count of the loop is : " + count);
				log.fatal("Failed to fetch Okapi token for the first time and retry for 10 times");
				log.error("Okapi token failed due to timeout or endpoint issue");
				getToken_PaymentProcessor();
			}
		}
		return bdsToken;
	}

}




