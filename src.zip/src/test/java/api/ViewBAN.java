package api;

import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.log4j.Logger;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
//import org.testng.Assert;
import java.util.*;
import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.UUID;

import static apiUtils.GlobalConstants.ViewBanURL;
import static io.restassured.specification.ProxySpecification.host;
import static org.junit.Assert.assertEquals;

public class ViewBAN
{

	static Logger log = Logger.getLogger(ViewBAN.class);

	public static void ViewBillingAccount() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException
	{
		String token = AllocateBAN.getToken();
		int statuscode = viewBAN(token);
		System.out.println("Statuscode" + ":" + statuscode);

	}

	public static int viewBAN(String token) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException
	{
		FileReader reader = new FileReader("configs/credentialSetting.properties");
		Properties p = new Properties();
		p.load(reader);
		String decodedPassword = utils.EncryptPassword.decryptPassword(p.getProperty("password"));
		RequestSpecification tokenRequest = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth("d318101", decodedPassword));
		tokenRequest.auth().none();
		tokenRequest.header("Content-Type", "application/json");
		String tokenHeader = "Bearer " + token;
		System.out.println(token);
		tokenRequest.header("Authorization", tokenHeader);
		tokenRequest.header("Source-System", "SFDC");
		UUID uuid = UUID.randomUUID();
		tokenRequest.header("Correlation-Id", uuid.toString());
		System.out.println("Correlation Id is " + uuid.toString());
		tokenRequest.config(AllocateBAN.setCertificates());

		// Start - Read Billing account number from file created in Allocate BAN

		BufferedReader br = null;
		FileReader fr = null;

		fr = new FileReader("accountsit.txt");
		br = new BufferedReader(fr);

		String Billact;

		while ((Billact = br.readLine()) != null && !Billact.equals(""))
		{
			System.out.println(Billact);
			break;
		}

		if (br != null)
			br.close();

		if (fr != null)
			fr.close();

		// End - Read Billing account number from file created in Allocate BAN

		Long Billingno = 0L;
		Billingno = Long.valueOf(Billact);
		log.info("Invoke VIEW BAN API");
		log.info("VIEW BAN Request:--->" + Billingno);

		// Response tokenResponse = tokenRequest.get("https://slot1.org009.t-dev.telstra.net/application/b2b-bds-sit/v2.0/billing-accounts/" + Billingno + "");
		Response tokenResponse = tokenRequest.get(ViewBanURL + Billingno);

		log.info("View BAN Response:--->" + tokenResponse.asString());
		assertEquals(200, tokenResponse.getStatusCode());
		System.out.println(tokenResponse.asString());

		// Assert.assertEquals(tokenResponse.getStatusCode(), 200);

		tokenResponse.then().log().all();

		// System.out.println(jsonRespBody.get("errors"));
		JsonPath jsonRespBody = tokenResponse.jsonPath();

		// System.out.println(jsonRespBody.get("errors"));

		int statuscode = jsonRespBody.get("status");
		String message = jsonRespBody.get("message");
		System.out.println(message);
		return statuscode;
	}

	// Start- Setting up the certificates to invoke API
	// private static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException {
	//
	// String password = "secret";
	//
	// KeyStore keyStore = KeyStore.getInstance("jks");
	// KeyStore trustStore = KeyStore.getInstance("jks");
	//
	// keyStore.load(
	// new FileInputStream (new File("src/test/resources/certificates/keystore.jks")),
	// password.toCharArray());
	//
	// trustStore.load(
	// new FileInputStream(new File("src/test/resources/certificates/okapi.jks")),
	// password.toCharArray());
	//
	// RestAssuredConfig restAssuredConfig = null;
	//
	// restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig()
	// .keyStore("src/test/resources/certificates/keystore.jks", password).
	// trustStore("src/test/resources/certificates/okapi.jks", password));
	//
	// restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig()
	// .trustStore(trustStore).trustStoreType("JKS")
	// .keyStore(new File("src/test/resources/certificates/keystore.jks"), password).keystoreType("JKS").and().allowAllHostnames());
	// // restAssuredConfig.getSSLConfig().allowAllHostnames();
	//
	// if (null == restAssuredConfig) {
	// System.out.println("Certificate not Set");
	// }
	// return restAssuredConfig;
	// }

	// End- Setting up the certificates to invoke API
}
