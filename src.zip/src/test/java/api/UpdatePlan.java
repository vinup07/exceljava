package api;

import static apiUtils.GlobalConstants.AgileKeyStoreForAuthToekn;
import static apiUtils.GlobalConstants.AgileTrustStoreForAuthToeknPresit;
import static apiUtils.GlobalConstants.OfferupdateInputfile;
import static apiUtils.GlobalConstants.SigmaOffer;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import apiUtils.ApiUtils;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdatePlan
{

	static Logger log = Logger.getLogger(UpdatePlan.class);

	public static void updateplan() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException
	{
		RequestSpecification tokenRequest = new RestAssured().given();
		RequestSpecification tokenRequestForAuthKey = new RestAssured().given();
		tokenRequest.auth().none();
		tokenRequest.header("Content-Type", "application/json");
		UUID uuid = UUID.randomUUID();
		tokenRequest.header("CorrelationId", uuid.toString());
		tokenRequestForAuthKey.config(setCertificatesForAuthToken());
		Response authKey = tokenRequestForAuthKey.get("https://b2b-agilebiller-presit.np.in.telstra.com.au/jwttoken/getToken");
		// System.out.println("Auth Key " + authKey.body().toString());
		// System.out.println("Auth Key " + authKey.asString());
		String authKey1 = authKey.asString();
		tokenRequest.header("Authorization", "Bearer " + authKey1);
		System.out.println("Correlation Id is " + uuid.toString());
		tokenRequest.config(CreatePlan.setCertificates());
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("ddMMyyhhmmss");
		String finalUuid = simpleDateFormat.format(new Date());
		System.out.println(finalUuid);
		Date curDate = new Date();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EffDate = format.format(curDate);
		System.out.println(EffDate);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar c = Calendar.getInstance();
		c.setTime(new Date()); // Now use today date.
		c.add(Calendar.DATE, 60); // Adding 5 days
		String Availd = sdf.format(c.getTime());
		System.out.println(Availd);
		// Start - Reading Offer Update payload from the file
		// JSONObject jsonBody = ApiUtils.getJsonFromFile("/src/test/resources/payloads/sigmaofferupdate.json");
		JSONObject jsonBody = ApiUtils.getJsonFromFile(OfferupdateInputfile);
		BufferedReader br = null;
		FileReader fr = null;
		// br = new BufferedReader(new FileReader(FILENAME));
		fr = new FileReader("sigmaspecidsit.txt");
		br = new BufferedReader(fr);
		String SpecID;

		while ((SpecID = br.readLine()) != null && !SpecID.equals(""))
		{
			System.out.println(SpecID);
			break;
		}

		if (br != null)
			br.close();

		if (fr != null)
			fr.close();
		JSONObject Package = (JSONObject) jsonBody.get("package");
		System.out.println("package is " + Package.get("specId"));
		Package.remove("specId");
		Package.remove("effectiveStartDate");
		Package.remove("availableStartDate");
		Package.put("specId", SpecID);
		Package.put("effectiveStartDate", EffDate);
		Package.put("availableStartDate", Availd);
		tokenRequest.body(jsonBody.toString());
		System.out.println(jsonBody.toString());
		log.info("Invoke Sigma Offer Update API");
		log.info("SIGMA Offer Update:--->" + jsonBody.toString());
		// Response tokenResponse = tokenRequest.patch ("https://b2b-agilebiller-sit.np.in.telstra.com.au/offermanagement/manageoffer");
		Response tokenResponse = tokenRequest.patch(SigmaOffer);
		System.out.println(tokenResponse.asString());
		System.out.println(tokenResponse.body().toString());
		log.info("SIGMA Offer Update Response:--->" + tokenResponse.asString());
		String statusCode = tokenResponse.then().extract().path("errorCode").toString();
		System.out.println("Status Code is "+statusCode);
		Assert.assertEquals("[200]", statusCode);
		tokenResponse.then().log().all();
		JsonPath jsonRespBody = tokenResponse.jsonPath();
	}

//	public static RestAssuredConfig setCertificatesForAuthToken() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException
//	{
//		String password = "U2CEDGE";
//		KeyStore keyStore = KeyStore.getInstance("jks");
//		KeyStore trustStore = KeyStore.getInstance("jks");
//		keyStore.load(new FileInputStream(new File(AgileKeyStoreForAuthToekn)), password.toCharArray());
//		// new FileInputStream (new File ("src/test/resources/certificates/b2b-agilebiller-keystore-sit.jks")),
//		trustStore.load(new FileInputStream(new File(AgileTrustStoreForAuthToeknPresit)), password.toCharArray());
//		// new FileInputStream(new File("src/test/resources/certificates/b2b-agilebiller-truststore-sit.jks")),
//		RestAssuredConfig restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig().keyStore(AgileKeyStoreForAuthToekn, password).trustStore(AgileTrustStoreForAuthToeknPresit, password));
//		// .keyStore("src/test/resources/certificates/b2b-agilebiller-keystore-sit.jks",password)
//		// .trustStore("src/test/resources/certificates/b2b-agilebiller-truststore-sit.jks",password));
//		System.out.println("Certificate Loaded Successfully");
//		return restAssuredConfig;
//	}
	public static RestAssuredConfig setCertificatesForAuthToken() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException
	{
		String password = "U2CEDGE";
		KeyStore keyStore = KeyStore.getInstance("jks");
		TrustStrategy acceptingTrustStrategy = new TrustStrategy()
		{
			@Override
			public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException
			{
				return true;
			}
		};
		keyStore.load(new FileInputStream(new File(AgileKeyStoreForAuthToekn)), password.toCharArray());
		SSLContext sslContext1 = new SSLContextBuilder().useProtocol("TLSv1.2").loadKeyMaterial(keyStore, password.toCharArray()).loadTrustMaterial(null, acceptingTrustStrategy).build();
		@SuppressWarnings("deprecation")
		SSLSocketFactory factory = new SSLSocketFactory(sslContext1, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
		RestAssuredConfig restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig().sslSocketFactory(factory));
		return restAssuredConfig;
	}
	// Start - Setting certificates for this API call

	// private static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException {
	//
	// String password = "U2CEDGE";
	// KeyStore keyStore = KeyStore.getInstance("jks");
	// KeyStore trustStore = KeyStore.getInstance("jks");
	//
	// keyStore.load(
	// new FileInputStream (new File ("src/test/resources/certificates/b2b-agilebiller-keystore-sit.jks")),
	// password.toCharArray());
	//
	// trustStore.load(
	// new FileInputStream(new File("src/test/resources/certificates/b2b-agilebiller-truststore-sit.jks")),
	// password.toCharArray());
	//
	// RestAssuredConfig restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig()
	// .keyStore("src/test/resources/certificates/b2b-agilebiller-keystore-sit.jks",password)
	// .trustStore("src/test/resources/certificates/b2b-agilebiller-truststore-sit.jks",password));
	//
	// return restAssuredConfig;
	//
	// }
	// End - setting the certificates
}
