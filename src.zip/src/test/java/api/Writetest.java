package api;

import org.json.simple.parser.ParseException;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import static apiUtils.ApiUtils.randomAlphaNumeric;

public class Writetest {


    public static void WriteA() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {


        // Start - Generating unique  Product ID

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat ("ddMMyyhhmmss");
        String finalUuid = simpleDateFormat.format (new Date ());
        System.out.println (finalUuid);

        int ParCnt = 0;
        ParCnt++;

        String ParentID = "";
        ParentID = "FN" + "-" + finalUuid + ParCnt;

        System.out.println ("ParentProductinstanceID Id is " + ParentID);

        // End - Generating unique  Product ID

        // Start - Generating unique Recurring charge product instance ID

        int RcCnt = 1;
        RcCnt++;

        String RCParentID = "";
        RCParentID = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (3) + "-" + finalUuid + RcCnt;
        System.out.println ("RCProductinstanceID Id is " + RCParentID);

        // End - Generating unique Recurring charge product instance ID


        FileWriter fw = new FileWriter("prodinidsit.txt");
        PrintWriter pw = new PrintWriter(fw, true);


            pw.println(ParentID); //A number on a line by itself!
            //pw.println("A line"); // A line with a newline at the end
            pw.print(RCParentID);

        fw.close();


        File file = new File ("prodinidsit.txt");

        Scanner sc = new Scanner (file);

        String ProdID = null;
        int a=0;
        String Prod_id[] = new String [10];
      //  for ( array[a]=1; array[a]<=2; array[a]++){
        while (sc.hasNextLine ()) {
            ProdID = sc.nextLine ();
            System.out.println (ProdID);
            Prod_id[a] =  ProdID;
            a++;
        }
        sc.close ();
        String ParentProd_ID =  Prod_id[0];
        String RCProd_id     =  Prod_id[1];
        System.out.println(ParentProd_ID);
        System.out.println(RCProd_id);


    }}


