package api;

import apiUtils.ApiUtils;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import java.io.*;
import java.util.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.UUID;

import static api.AllocateBAN.setCertificates;
import static apiUtils.ApiUtils.randomAlphaNumeric;
import static apiUtils.GlobalConstants.*;
import static io.restassured.specification.ProxySpecification.host;
import static org.junit.Assert.assertEquals;

public class ModifyBAN {

    static Logger log = Logger.getLogger(ModifyBAN.class);
    public static void PostModifyBan() {
        String correlationId = "";
        correlationId = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (12);
        //System.out.println ("Correlation Id is " + correlationId);
        try {
            String token = AllocateBAN.getToken ();
            int statuscode = modifyBAN (correlationId,token);
            // System.out.println ("Cor Id : Statuscode" + "-" + correlationId + ":" + statuscode);
        }catch (Exception e){
            System.out.println (e.getMessage ());
            log.fatal ("Modify BAN failed from BDS/ARIA and needs investigation");
            e.printStackTrace ();

        }
    }

    public static int modifyBAN(String correlationId, String token) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
    	Properties p=new Properties();
    	p.load(reader);
    	String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
        RequestSpecification tokenRequest = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth("d318101", decodedPassword));
        tokenRequest.auth().none();
        tokenRequest.auth().none();
        tokenRequest.header("Content-Type", "application/json");
        String tokenHeader = "Bearer " + token;
        System.out.println(token);
        tokenRequest.header("Authorization", tokenHeader);
        tokenRequest.header("Source-System","SFDC");
        UUID uuid = UUID.randomUUID();
        tokenRequest.header("Correlation-Id", uuid.toString());
        System.out.println ("Correlation Id is " + uuid.toString());
        tokenRequest.config(AllocateBAN.setCertificates());

//        JSONObject jsonBody = ApiUtils.getJsonFromFile("/src/test/resources/payloads/ModifyBAN.json");
        JSONObject jsonBody = ApiUtils.getJsonFromFile(ModifyBANInputFile);

        // Start - Read Billing account number from file created in Allocate BAN

        BufferedReader br = null;
        FileReader fr = null;

        fr = new FileReader("accountsit.txt");
        br = new BufferedReader(fr);

        String Billact;

        while ((Billact = br.readLine()) != null && !Billact.equals("")){
            System.out.println(Billact);
            break;
        }

        if (br != null)
            br.close();

        if (fr != null)
            fr.close();

        // End - Read Billing account number from file created in Allocate BAN

        JSONObject billingAccount = (JSONObject) jsonBody.get("billingAccount");

        //jsonBody.get ("billingAccountNumber");

        System.out.println("billingAccountNumber is "+ billingAccount.get ("billingAccountNumber"));

        billingAccount.remove ("billingAccountNumber");

        System.out.println("  billingAccount is "+ jsonBody);

        //  billingAccount.put (billingAccount.put("billingAccountNumber"),"q233434");

        billingAccount.put ("billingAccountNumber",Long.valueOf (Billact));

        System.out.println("  put billingAccount is "+ jsonBody);

        tokenRequest.body(jsonBody.toString());

        Long Billingno = 0L;
        Billingno = Long.valueOf (Billact);

        System.out.println(jsonBody.toString());
        log.info("Invoke Modify BAN API");
        log.info("Modfify BAN Request:--->" + jsonBody.toString ());

//        Response tokenResponse = tokenRequest.patch ("https://slot1.org009.t-dev.telstra.net/application/b2b-bds-sit/v2.1/billing-accounts/" + Billingno + "");
        Response tokenResponse = tokenRequest.patch (ModifyBanURL+Billingno);
        log.info("Modify BAN Response:--->" + tokenResponse.asString ());
//        Assert.assertEquals(tokenResponse.getStatusCode(), 200);
        assertEquals(200, tokenResponse.getStatusCode());
        System.out.println(tokenResponse.asString());
        tokenResponse.then().log().all();
        JsonPath jsonRespBody = tokenResponse.jsonPath();
        //System.out.println(jsonRespBody.get("errors"));
        int statuscode = jsonRespBody.get("status");
        return statuscode;
    }

    // Start- Setting up the certificates to invoke API
//    private static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException {
//
//        String password = "secret";
//
//        KeyStore keyStore = KeyStore.getInstance("jks");
//        KeyStore trustStore = KeyStore.getInstance("jks");
//
//        keyStore.load(
//                new FileInputStream (new File("src/test/resources/certificates/keystore.jks")),
//                password.toCharArray());
//
//        trustStore.load(
//                new FileInputStream(new File("src/test/resources/certificates/okapi.jks")),
//                password.toCharArray());
//
//        RestAssuredConfig restAssuredConfig = null;
//
//        restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig()
//                .keyStore("src/test/resources/certificates/keystore.jks", password).
//                        trustStore("src/test/resources/certificates/okapi.jks", password));
//
//        restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig()
//                .trustStore(trustStore).trustStoreType("JKS")
//                .keyStore(new File("src/test/resources/certificates/keystore.jks"), password).keystoreType("JKS").and().allowAllHostnames());
//        // restAssuredConfig.getSSLConfig().allowAllHostnames();
//
//        if (null == restAssuredConfig) {
//            System.out.println("Certificate not Set");
//        }
//        return restAssuredConfig;
//    }
    // End- Setting up the certificates to invoke API
}