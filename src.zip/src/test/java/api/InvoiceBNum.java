package api;

import apiUtils.ApiUtils;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.UUID;

import static apiUtils.GlobalConstants.*;
import static org.junit.Assert.assertEquals;

public class InvoiceBNum
{

	static Logger log = Logger.getLogger(InvoiceBNum.class);

	// @Test
	public void testInvoice() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException
	{
		invoice();

	}

	public static void invoice() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException
	{
		RequestSpecification tokenRequest = new RestAssured().given();
		tokenRequest.auth().none();
		tokenRequest.header("Content-Type", "application/json");
		UUID uuid = UUID.randomUUID();
		tokenRequest.header("CorrelationId", uuid.toString());
		System.out.println("Correlation Id is " + uuid.toString());
		tokenRequest.header("Accept", "application/pdf");
		tokenRequest.config(CreatePlan.setCertificates());
		JSONObject jsonBody = ApiUtils.getJsonFromFile(InvoiceBnumFile);
		String Invoicenum;
		Invoicenum = (String) jsonBody.get("invoiceNumber");
		System.out.println("Invoicenum is " + Invoicenum);
		tokenRequest.body(jsonBody.toString());
		log.info("Invoke Invoice Manager API from T-Connect");
		log.info("Invoice Manager Request:--->" + jsonBody.toString());
		Response tokenResponse = tokenRequest.post(InvoiceBnumURL);
		log.info("Invoice Manager Response:--->" + tokenResponse.asString());
		// Assert.assertEquals (tokenResponse.getStatusCode (), 200);
		assertEquals(200, tokenResponse.getStatusCode());
		// tokenResponse.then ().log ().all ();
		JsonPath jsonRespBody = tokenResponse.jsonPath();
		InputStream is = tokenResponse.getBody().asInputStream();
		// File invoice = new File("src/test/resources/Invoices/Invoicenum.pdf");
		File invoice = new File(InvoicePDFpath + Invoicenum + ".pdf");
		invoice.createNewFile();
		ApiUtils.copyInputStreamToFile(is, invoice);
		// Start - Setting certificates for this API call
	}

	// private static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException {
	//
	// String password = "U2CEDGE";
	// KeyStore keyStore = KeyStore.getInstance("jks");
	// KeyStore trustStore = KeyStore.getInstance("jks");
	//
	// keyStore.load(
	// new FileInputStream(new File("src/test/resources/certificates/b2b-agilebiller-keystore-sit.jks")),
	// password.toCharArray());
	//
	// trustStore.load(
	// new FileInputStream(new File("src/test/resources/certificates/b2b-agilebiller-truststore-sit.jks")),
	// password.toCharArray());
	//
	// RestAssuredConfig restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig()
	// .keyStore("src/test/resources/certificates/b2b-agilebiller-keystore-sit.jks",password)
	// .trustStore("src/test/resources/certificates/b2b-agilebiller-truststore-sit.jks",password));
	//
	// return restAssuredConfig;
	//
	// }
	// End - setting the certificates
}
