package api;

import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.log4j.Logger;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import java.io.*;
import java.util.*;
import java.security.*;
import java.security.cert.CertificateException;

import static api.AllocateBAN.setCertificates;
import static apiUtils.GlobalConstants.CustomerMS;
import static apiUtils.GlobalConstants.Okapi;
import static apiUtils.GlobalConstants.ViewBanURL;
import static io.restassured.specification.ProxySpecification.host;
import static org.junit.Assert.assertEquals;

public class BDSCustomerMS {

    static Logger log = Logger.getLogger(BDSCustomerMS.class);
    static int num = 10, count = 1;

    public static void CustomerMS() {
        try {
//            String token = AllocateBAN.getToken ();
        	String token = getToken();
            int statuscode = customerMS (token);
        }catch (Exception e){
            System.out.println (e.getMessage ());
            log.fatal ("BDS/Customer MS - CIDN to BAN retrieval is failed and needs investigation");
            e.printStackTrace ();

        }
    }
    
    public static String getToken() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException
	{
		FileReader reader = new FileReader("configs/credentialSetting.properties");
		Properties p = new Properties();
		p.load(reader);
		String decodedPassword = utils.EncryptPassword.decryptPassword(p.getProperty("password"));
		RequestSpecification tokenRequest = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
		log.warn("Invoked Okapi URL by passing proxy credentials");
		RestAssured.useRelaxedHTTPSValidation();
		tokenRequest.relaxedHTTPSValidation();
		tokenRequest.auth().none();
		log.info("Retrieve token from Okapi to authorize the transaction");
		tokenRequest.header("Content-Type", "application/x-www-form-urlencoded");
//		tokenRequest.config(setCertificates());
		tokenRequest.config(setCertificates());
		String bodyToken = "clie" + "nt_id=ZFhclSTkGtpsDaqGqvcxCu4CXSd0krSF&client_secret=wc4q7TtNUzVCNwrt&grant_type=client_credentials";
		tokenRequest.body(bodyToken);
		Response tokenResponse = tokenRequest.post(Okapi);
		System.out.println(tokenResponse.asString());
		tokenResponse.then().log().all();
		JsonPath jsonRespBody = tokenResponse.jsonPath();
		String bdsToken = "";
		bdsToken = jsonRespBody.get("access_token");
		System.out.println("Generated Token : " + bdsToken);
		assertEquals(200, tokenResponse.getStatusCode());
		log.info("Token Response:--->" + tokenResponse.asString());
		if (bdsToken == null)
		{
			while (count <= num)
			{
				count++;
				System.out.println("Count of the loop is : " + count);
				log.fatal("Failed to fetch Okapi token for the first time and retry for 10 times");
				log.error("Okapi token failed due to timeout or endpoint issue");
				getToken();
			}
		}
		return bdsToken;
	}

    public static int customerMS(String token) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
    	Properties p=new Properties();
    	p.load(reader);
    	String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
        RequestSpecification tokenRequest = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
        tokenRequest.auth().none();
        tokenRequest.header("Content-Type", "application/json");
        String tokenHeader = "Bearer " + token;
        tokenRequest.header("Authorization", tokenHeader);
        UUID uuid = UUID.randomUUID();
        tokenRequest.header("correlation-Id", uuid.toString());
        tokenRequest.header("source-System", "TConnect");
        tokenRequest.config(setCertificates());

      // Start - Read CIDN number from file

        BufferedReader br = null;
        FileReader fr = null;

        fr = new FileReader("cidnsit.txt");
        br = new BufferedReader(fr);

        String CIDN;

        while ((CIDN = br.readLine()) != null && !CIDN.equals("")){
            System.out.println(CIDN);
            break;
        }

        if (br != null)
            br.close();

        if (fr != null)
            fr.close();

        // End - Read CIDN from file

        log.info("Invoke BAN Retrieval from Customer MS through BDS API");
        log.info("BAN Retrieval from Customer MS Request:--->" + CIDN);


//        Response tokenResponse = tokenRequest.get ("https://slot1.org009.t-dev.telstra.net/application/b2b-bds-sit/v2.0/billing-accounts/customers-relationships/" + CIDN);
        Response tokenResponse = tokenRequest.get (CustomerMS +CIDN);
        log.info(" BAN Retrieval from Customer MS through BDS Response:--->" + tokenResponse.asString ());

        assertEquals(200, tokenResponse.getStatusCode());
//        Assert.assertEquals(tokenResponse.getStatusCode(), 200);

        tokenResponse.then().log().all();

        JsonPath jsonRespBody = tokenResponse.jsonPath();

        int statuscode = jsonRespBody.get("status");
        return statuscode;
    }

    // Start- Setting up the certificates to invoke API
//    private static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException {
//
//        String password = "secret";
//
//        KeyStore keyStore = KeyStore.getInstance("jks");
//        KeyStore trustStore = KeyStore.getInstance("jks");
//
//        keyStore.load(
//                new FileInputStream (new File ("src/test/resources/certificates/keystore.jks")),
//                password.toCharArray());
//
//        trustStore.load(
//                new FileInputStream(new File("src/test/resources/certificates/okapi.jks")),
//                password.toCharArray());
//
//        RestAssuredConfig restAssuredConfig = null;
//
//        restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig()
//                .keyStore("src/test/resources/certificates/keystore.jks", password).
//                        trustStore("src/test/resources/certificates/okapi.jks", password));
//
//
//
//        restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig()
//                .trustStore(trustStore).trustStoreType("JKS")
//                .keyStore(new File("src/test/resources/certificates/keystore.jks"), password).keystoreType("JKS").and().allowAllHostnames());
//        // restAssuredConfig.getSSLConfig().allowAllHostnames();
//
//        if (null == restAssuredConfig) {
//            System.out.println("Certificate not Set");
//        }
//        return restAssuredConfig;
//    }

    // End- Setting up the certificates to invoke API
}
