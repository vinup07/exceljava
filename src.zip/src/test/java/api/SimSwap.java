package api;

import apiUtils.ApiUtils;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.*;

import static apiUtils.ApiUtils.randomAlphaNumeric;
import static apiUtils.GlobalConstants.*;
import static io.restassured.specification.ProxySpecification.host;
import static org.junit.Assert.assertEquals;

public class SimSwap {

    static Logger log = Logger.getLogger(SimSwap.class);
    public static void SimReplacement() {
        String correlationId = "";
        correlationId = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (12);
        System.out.println ("Correlation Id is " + correlationId);
        try {
            String token = AllocateBAN.getToken ();
            int statuscode = simswap (correlationId,token);
            
        }catch (Exception e) {
            System.out.println (e.getMessage ());
            log.fatal ("Modify subscription failed from BDS/ARIA and needs investigation");
            e.printStackTrace ();

        }}

    public static int simswap (String correlationId, String token) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
    	Properties p=new Properties();
    	p.load(reader);
    	String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
        RequestSpecification tokenRequest = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
        tokenRequest.auth().none();
        tokenRequest.header ("Content-Type", "application/json");
        String tokenHeader = "Bearer " + token;
        System.out.println (token);
        tokenRequest.header ("Authorization", tokenHeader);
        tokenRequest.header("Source-System","SFDC");
        UUID uuid = UUID.randomUUID();
        tokenRequest.header("Correlation-Id", uuid.toString());
        System.out.println ("Correlation Id is " + uuid.toString());
        tokenRequest.header ("X-HTTP-Method-Override", "PATCH");
        tokenRequest.config (PostSub.setCertificates ());


       // Start - Generating unique  Product ID

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat ("ddMMyyhhmmss");
        String finalUuid = simpleDateFormat.format (new Date ());
        System.out.println (finalUuid);

        SimpleDateFormat Effdate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        Effdate.setTimeZone (TimeZone.getTimeZone ("UTC"));
        String Efecdate = Effdate.format (new Date ());
        System.out.println (Efecdate);

        int ParCnt = 0;
        ParCnt++;

        String ParentID = "";
        //ParentID = "FN" + "-" + finalUuid + ParCnt;
        ParentID = "FN-1408181117251";

        System.out.println ("ParentProductinstanceID Id is " + ParentID);

        // End - Generating unique  Product ID

        // Start - Generating unique Recurring charge product instance ID

        int RcCnt = 1;
        RcCnt++;

        String RCParentID = "";
        RCParentID = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (3) + "-" + finalUuid + RcCnt;
        System.out.println ("RCProductinstanceID Id is " + RCParentID);

        // End - Generating unique Recurring charge product instance ID

        // Start - Generating unique Non-Recurring charge product instance ID

        int NRCCnt = 2;
        NRCCnt++;

        String NRCParentID = "";
        NRCParentID = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (3) + "-" + finalUuid + NRCCnt;
        System.out.println ("NRCProductinstanceID Id is " + NRCParentID);

        // End -   Generating unique Non-Recurring charge product instance ID

        // Start - Generating unique Usage charge product instance ID

        int USGCnt = 3;
        USGCnt++;
        //System.out.println(USGCnt);

        String USGParentID = "";
        USGParentID = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (3) + "-" + finalUuid + USGCnt;
        System.out.println ("USGProductinstanceID Id is " + USGParentID);

        // End - Generating unique Usage charge product instance ID

        // Start - Generating Unique service instance ID//

        String RCServiceID = "";
        RCServiceID = randomAlphaNumeric (3) + "-" + finalUuid + RcCnt;

        String NRCServiceID = "";
        NRCServiceID = randomAlphaNumeric (3) + "-" + finalUuid + NRCCnt;

        String USGServiceID = "";
        USGServiceID = randomAlphaNumeric (3) + "-" + finalUuid + USGCnt;

        // End- Generating Unique service instance ID//

        //  Start - Reading Json body as a  file  //
         JSONObject jsonBody = ApiUtils.getJsonFromFile(SimswapInputfile);
        //  End - Reading Json body as a  file  //

        // Start - Reading billing account created in Allocate BAN from the file
        BufferedReader br = null;
        FileReader fr = null;
        
        
        fr = new FileReader ("accountsit.txt");
        br = new BufferedReader (fr);

        String Billact;

        while ((Billact = br.readLine ()) != null && !Billact.equals ("")) {
            System.out.println (Billact);
            break;
        }

        if (br != null)
            br.close ();

        if (fr != null)
            fr.close ();

        // Read product ID and product instance ID from create Subscription
        File file = new File ("ProdInIDSIT.txt");

        Scanner sc = new Scanner (file);

        String ProdID = null;
        int a=0;
        String Prod_id[] = new String [10];
        //  for ( array[a]=1; array[a]<=2; array[a]++){
        while (sc.hasNextLine ()) {
            ProdID = sc.nextLine ();
            System.out.println (ProdID);
            Prod_id[a] =  ProdID;
            a++;
        }
        sc.close ();

        String ParentProd_ID =  Prod_id[0];
        String RCProd_id1     =  Prod_id[3];
        String RCProd_id2     =  Prod_id[4];
        String RCProd_id3     =  Prod_id[5];


        System.out.println(ParentProd_ID);
        System.out.println(RCProd_id1);


//          Start - Building Json body before sending request to API
//
//          Update dynamic values in the payload

        jsonBody.remove ("billingAccountNumber");
        jsonBody.put ("billingAccountNumber",Long.valueOf (Billact));

//      System.out.println("billingAccountNumber");

        JSONObject Prodoffr = (JSONObject) jsonBody.get("productOffering");
        Prodoffr.remove ("productInstanceId");
        Prodoffr.put ("productInstanceId",ParentProd_ID);

//      System.out.println("Prod Offering  : "+ ParentID);

        jsonBody.remove ("effectiveDate");
        jsonBody.put ("effectiveDate",Efecdate);  // put current date

//      System.out.println("effectiveDate  : "+ Efecdate);

        JSONArray orderitem = new JSONArray ();

        JSONArray array = (JSONArray) jsonBody.get ("orderItems");
        JSONObject orderItems = (JSONObject) array.get (0);
        orderItems.remove ("effectiveDate");
        orderItems.put ("effectiveDate",Efecdate); // put current date

        orderItems = (JSONObject) array.get (0);
        JSONArray billingSpecification = (JSONArray) orderItems.get ("billingSpecifications");
        JSONObject billingSpecObj = (JSONObject) billingSpecification.get (0);
        billingSpecObj.remove ("instanceId");
        billingSpecObj.put ("instanceId",RCProd_id1);


        /*orderItems = (JSONObject) array.get (1);
        JSONArray billingSpecification1 = (JSONArray) orderItems.get ("billingSpecifications");
        JSONObject billingSpecObj1 = (JSONObject) billingSpecification1.get (0);
        billingSpecObj1.remove ("instanceId");
        billingSpecObj1.put ("instanceId",RCProd_id2);
        orderItems.remove ("effectiveDate");
        orderItems.put ("effectiveDate",Efecdate);

        orderItems = (JSONObject) array.get (2);
        JSONArray billingSpecification2 = (JSONArray) orderItems.get ("billingSpecifications");
        JSONObject billingSpecObj2 = (JSONObject) billingSpecification2.get (0);
        billingSpecObj2.remove ("instanceId");
        billingSpecObj2.put ("instanceId",RCProd_id3);
        orderItems.remove ("effectiveDate");
        orderItems.put ("effectiveDate",Efecdate);

        orderItems = (JSONObject) array.get (3);
        JSONArray billingSpecification3 = (JSONArray) orderItems.get ("billingSpecifications");
        JSONObject billingSpecObj3 = (JSONObject) billingSpecification3.get (0);
        billingSpecObj3.remove ("instanceId");
        billingSpecObj3.put ("instanceId",RCParentID);
        orderItems.remove ("effectiveDate");
        orderItems.put ("effectiveDate",Efecdate);

        orderItems = (JSONObject) array.get (4);
        JSONArray billingSpecification4 = (JSONArray) orderItems.get ("billingSpecifications");
        JSONObject billingSpecObj4 = (JSONObject) billingSpecification4.get (0);
        billingSpecObj4.remove ("instanceId");
        billingSpecObj4.put ("instanceId",NRCParentID);
        orderItems.remove ("effectiveDate");
        orderItems.put ("effectiveDate",Efecdate);*/



//
//        JSONObject billingSpecObj1 = (JSONObject) billingSpecification.get (1);
//        billingSpecObj1.remove ("instanceId");
//        billingSpecObj1.put ("instanceId",RCParentID);
//
//        JSONObject billingSpecObj2 = (JSONObject) billingSpecification.get (2);
//        billingSpecObj2.remove ("instanceId");
//        billingSpecObj2.put ("instanceId",NRCParentID);

//      Changes end

        Long Billingno = 0L;
        Billingno = Long.valueOf (Billact);

        tokenRequest.body (jsonBody.toString ());
        log.info("Sim Replacement Post Subscription API");
        log.info("Sim Replacement Request:--->" + jsonBody.toString ());

        System.out.println (jsonBody.toString ());

        Response tokenResponse = tokenRequest.post (SimSwapURL + Billingno + "/subscriptions/" + ParentProd_ID);

        log.info("Sim Replacement Response:--->" + tokenResponse.asString ());
        assertEquals(202, tokenResponse.getStatusCode());

        tokenResponse.then ().log ().all ();

        JsonPath jsonRespBody = tokenResponse.jsonPath ();
        int statuscode = jsonRespBody.get ("status");
        return statuscode;
    }

}



