package api;

import static apiUtils.GlobalConstants.AgileKeyStore;
import static apiUtils.GlobalConstants.AgileTrustStore;
import static apiUtils.GlobalConstants.OffercreateInputfile;
import static apiUtils.GlobalConstants.SigmaOffer;
import static apiUtils.GlobalConstants.AgileKeyStoreForAuthToekn;
import static apiUtils.GlobalConstants.AgileTrustStoreForAuthToeknPresit;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

import javax.net.ssl.SSLContext;
//import javax.net.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.SSLSocketFactory;

import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

//import com.aventstack.extentreports.ExtentReports;
//import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.*;

import apiUtils.ApiUtils;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreatePlan
{
	static Logger log = Logger.getLogger(CreatePlan.class);
	public static ExtentTest exTest;

	public static void createplan() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException
	{
		RequestSpecification tokenRequest = new RestAssured().given();
		RequestSpecification tokenRequestForAuthKey = new RestAssured().given();
		tokenRequest.auth().none();
		tokenRequest.header("Content-Type", "application/json");
		UUID uuid = UUID.randomUUID();
		tokenRequest.header("CorrelationId", uuid.toString());
		// tokenRequest.header("Source-System", "BillingCatalogService");
		tokenRequestForAuthKey.config(setCertificatesForAuthToken());
		Response authKey = tokenRequestForAuthKey.get("https://b2b-agilebiller-presit.np.in.telstra.com.au/jwttoken/getToken");
		// System.out.println("Auth Key " + authKey.body().toString());
		// System.out.println("Auth Key " + authKey.asString());
		String authKey1 = authKey.asString();
		tokenRequest.header("Authorization", "Bearer " + authKey1);
		System.out.println("Correlation Id is " + uuid.toString());
		tokenRequest.config(setCertificates());
		// Start - Generating unique Product ID
		// JSONObject jsonBody = ApiUtils.getJsonFromFile("/src/test/resources/payloads/sigmaoffercreate.json");
		JSONObject jsonBody = ApiUtils.getJsonFromFile(OffercreateInputfile);
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("ddMMyyhhmmss");
		String finalUuid = simpleDateFormat.format(new Date());
		System.out.println(finalUuid);
		Date curDate = new Date();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String EffDate = format.format(curDate);
		System.out.println(EffDate);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar c = Calendar.getInstance();
		c.setTime(new Date()); // Now use today date.
		c.add(Calendar.DATE, 90); // Adding 5 days
		String Availd = sdf.format(c.getTime());
		System.out.println(c);
		System.out.println(Availd);
		int OffCnt = 0;
		OffCnt++;
		String SpecID = "";
		SpecID = "FMCAT_Offer_" + finalUuid + OffCnt;
		System.out.println("Offer Id is " + SpecID);
		// Start - Write Offer ID to File
		FileWriter fw = new FileWriter("sigmaspecidsit.txt");
		PrintWriter pw = new PrintWriter(fw, true);
		pw.println(SpecID);
		fw.close();
		JSONObject Package = (JSONObject) jsonBody.get("package");
		System.out.println("package is " + Package.get("specId"));
		Package.remove("specId");
		Package.remove("effectiveStartDate");
		Package.remove("availableStartDate");
		Package.put("specId", SpecID);
		Package.put("effectiveStartDate", EffDate);
		Package.put("availableStartDate", Availd);
		tokenRequest.body(jsonBody.toString());
		System.out.println(jsonBody.toString());
		log.info("Invoke Sigma Offer Creation API");
		log.info("SIGMA Offer Creation:--->" + jsonBody.toString());
		// Response tokenResponse = tokenRequest.post ("https://b2b-agilebiller-sit.np.in.telstra.com.au/offermanagement/manageoffer");
		Response tokenResponse = tokenRequest.post(SigmaOffer);
		System.out.println(tokenResponse.asString());
		System.out.println(tokenResponse.body().toString());
		log.info("SIGMA Offer creation Response:--->" + tokenResponse.asString());
		String statuscode = tokenResponse.then().extract().path("errorCode").toString();
		System.out.println("StatusCode = " +statuscode);
		Assert.assertEquals("[200]",statuscode);
		tokenResponse.then().log().all();
		JsonPath jsonRespBody = tokenResponse.jsonPath();
	}

	// Start - Setting certificates for this API call
	public static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException
	{
	String password = "U2CEDGE";
	KeyStore keyStore = KeyStore.getInstance("jks");
	//KeyStore keyStore = KeyStore.getInstance("PKCS12");
	// KeyStore trustStore = KeyStore.getInstance("JKS");
	TrustStrategy acceptingTrustStrategy = new TrustStrategy()
	{
		@Override
		public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException
		{
			return true;
		}
	};
	keyStore.load(new FileInputStream(new File(AgileKeyStore)), password.toCharArray());
	// keyStore.load(new FileInputStream(workingDir + "//src//test//resources//b2b-agilebiller-quovadis-keystore-presit.p12"), password.toCharArray());
	SSLContext sslContext1 = new SSLContextBuilder().useProtocol("TLSv1.2").loadKeyMaterial(keyStore, password.toCharArray()).loadTrustMaterial(null, acceptingTrustStrategy).build();
	@SuppressWarnings("deprecation")
	SSLSocketFactory factory = new SSLSocketFactory(sslContext1, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
	RestAssuredConfig restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig().sslSocketFactory(factory));
	return restAssuredConfig;
	}
	public static RestAssuredConfig setCertificatesForAuthToken() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException
	{
		String password = "U2CEDGE";
		KeyStore keyStore = KeyStore.getInstance("jks");
		TrustStrategy acceptingTrustStrategy = new TrustStrategy()
		{
			@Override
			public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException
			{
				return true;
			}
		};
		keyStore.load(new FileInputStream(new File(AgileKeyStoreForAuthToekn)), password.toCharArray());
		SSLContext sslContext1 = new SSLContextBuilder().useProtocol("TLSv1.2").loadKeyMaterial(keyStore, password.toCharArray()).loadTrustMaterial(null, acceptingTrustStrategy).build();
		@SuppressWarnings("deprecation")
		SSLSocketFactory factory = new SSLSocketFactory(sslContext1, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
		RestAssuredConfig restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig().sslSocketFactory(factory));
		return restAssuredConfig;
	}

//************* Old code for setCertificatesForAuthToken**********
//public static RestAssuredConfig setCertificatesForAuthToken() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException
//{
//	String password = "U2CEDGE";
//	KeyStore keyStore = KeyStore.getInstance("jks");
//	KeyStore trustStore = KeyStore.getInstance("jks");
//	keyStore.load(new FileInputStream(new File(AgileKeyStoreForAuthToekn)), password.toCharArray());
//	// new FileInputStream (new File ("src/test/resources/certificates/b2b-agilebiller-keystore-sit.jks")),
//	trustStore.load(new FileInputStream(new File(AgileTrustStoreForAuthToeknPresit)), password.toCharArray());
//	// new FileInputStream(new File("src/test/resources/certificates/b2b-agilebiller-truststore-sit.jks")),
//	RestAssuredConfig restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig().keyStore(AgileKeyStoreForAuthToekn, password).trustStore(AgileTrustStoreForAuthToeknPresit, password));
//	// .keyStore("src/test/resources/certificates/b2b-agilebiller-keystore-sit.jks",password)
//	// .trustStore("src/test/resources/certificates/b2b-agilebiller-truststore-sit.jks",password));
//	System.out.println("Certificate Loaded Successfully");
//	return restAssuredConfig;
//}
}