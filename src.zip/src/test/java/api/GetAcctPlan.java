package api;

import apiUtils.ApiUtils;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import java.io.*;
import java.util.*;
import java.security.*;
import java.security.cert.CertificateException;

import static io.restassured.specification.ProxySpecification.host;

public class GetAcctPlan {


        static Logger log = Logger.getLogger(api.GetAccountdetailsm.class);

        public static void GetAccountplan() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {

        	FileReader reader=new FileReader("configs/credentialSetting.properties");  
        	Properties p=new Properties();
        	p.load(reader);
        	String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
            RequestSpecification tokenRequest = new RestAssured().given ().proxy (host ("bcavi.tcif.telstra.com.au").withPort (8080).withAuth ("d318101", decodedPassword));
//        RequestSpecification tokenRequest = new RestAssured().given ();
            tokenRequest.auth ().none ();
            tokenRequest.header ("Content-Type", "application/json");
            tokenRequest.config (setCertificates ());

            // Start - Generating unique  Product ID

            JSONObject jsonBody = ApiUtils.getJsonFromFile("/src/test/resources/payloads/getacctplan.json");

            BufferedReader br = null;
            FileReader fr = null;

            //br = new BufferedReader(new FileReader(FILENAME));
            fr = new FileReader ("accountsit.txt");
            br = new BufferedReader (fr);

            String Billact;

            while ((Billact = br.readLine ()) != null && !Billact.equals ("")) {
                System.out.println (Billact);
                break;
            }

            if (br != null)
                br.close ();

            if (fr != null)
                fr.close ();

            jsonBody.remove ("client_acct_id");
            jsonBody.put ("client_acct_id",Long.valueOf (Billact));

            tokenRequest.body (jsonBody.toString ());
            System.out.println(jsonBody.toString());

            Response tokenResponse = tokenRequest.post ("https://api.current.stage.aus.ariasystems.net/api/ws/api_ws_class_dispatcher.php");
//        System.out.println (tokenResponse.asString ());
            System.out.println(tokenResponse.body().toString());
            log.info("ARIA Account creation Response:--->" + tokenResponse.asString ());
            Assert.assertEquals(200 ,tokenResponse.getStatusCode());
//        tokenResponse.then ().log ().all ();
            JsonPath jsonRespBody = tokenResponse.jsonPath ();
        }

//      public static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException {
//
//        String password = "changeit";
//        KeyStore keyStore = KeyStore.getInstance ("jks");
//        KeyStore trustStore = KeyStore.getInstance ("jks");
//
//        keyStore.load (
//                new FileInputStream (new File ("src/test/resources/certificates/svc-bds-subscription-client.sit.jks")),
//                password.toCharArray ());
//
//        trustStore.load (
//                new FileInputStream (new File ("src/test/resources/certificates/cacerts.jks")),
//                password.toCharArray ());
//        RestAssuredConfig restAssuredConfig = null;
//
//        restAssuredConfig = RestAssured.config ().sslConfig (SSLConfig.sslConfig ()
//                .keyStore ("src/test/resources/certificates/svc-bds-subscription-client.sit.jks", password).
//                        trustStore ("src/test/resources/certificates/cacerts.jks", password));
//
//        restAssuredConfig = RestAssured.config ().sslConfig (SSLConfig.sslConfig ()
//                .trustStore (trustStore).trustStoreType ("JKS")
//                .keyStore (new File ("src/test/resources/certificates/svc-bds-subscription-client.sit.jks"), password).keystoreType ("JKS").and ().allowAllHostnames ());
//
//        if (null == restAssuredConfig) {
//            System.out.println ("Certificate not Set");
//            log.fatal ("certificates not set successfully and needs investigation ");
//        }
//        return restAssuredConfig;
//        // End - setting the certificates
//    }

        public static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException {

            String password = "secret";
            KeyStore keyStore = KeyStore.getInstance ("jks");
            KeyStore trustStore = KeyStore.getInstance ("jks");

            keyStore.load (
                    new FileInputStream(new File("src/test/resources/certificates/AriaKeystore.jks")),
                    password.toCharArray ());

            trustStore.load (
                    new FileInputStream (new File ("src/test/resources/certificates/AriaTruststore.jks")),
                    password.toCharArray ());
            RestAssuredConfig restAssuredConfig = null;

            restAssuredConfig = RestAssured.config ().sslConfig (SSLConfig.sslConfig ()
                    .keyStore ("src/test/resources/certificates/AriaKeystore.jks", password).
                            trustStore ("src/test/resources/certificates/AriaTruststore.jks", password));

            restAssuredConfig = RestAssured.config ().sslConfig (SSLConfig.sslConfig ()
                    .trustStore (trustStore).trustStoreType ("JKS")
                    .keyStore (new File ("src/test/resources/certificates/AriaKeystore.jks"), password).keystoreType ("JKS").and ().allowAllHostnames ());

            if (null == restAssuredConfig) {
                System.out.println ("Certificate not Set");
                log.fatal ("certificates not set successfully and needs investigation ");
            }
            return restAssuredConfig;
            // End - setting the certificates
        }
    }


