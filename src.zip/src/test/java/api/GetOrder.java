package api;

import apiUtils.ApiUtils;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import java.io.*;
import java.util.*;

import javax.net.ssl.SSLContext;

import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import static apiUtils.GlobalConstants.ARIAKeyStore;
import static io.restassured.specification.ProxySpecification.host;
import static java.sql.DriverManager.println;

public class GetOrder {

        static Logger log = Logger.getLogger(api.GetOrder.class);

        public static void Getorder() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {

        	FileReader reader=new FileReader("configs/credentialSetting.properties");  
        	Properties p=new Properties();
        	p.load(reader);
        	String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
            RequestSpecification tokenRequest = new RestAssured().given ().proxy (host ("bcavi.tcif.telstra.com.au").withPort (8080).withAuth (p.getProperty("userName"), decodedPassword));
//        	RequestSpecification tokenRequest = new RestAssured().given ();
            tokenRequest.auth ().none ();
            tokenRequest.header ("Content-Type", "application/json");
            tokenRequest.config (setCertificates ());
            JSONObject jsonBody = ApiUtils.getJsonFromFile("/src/test/resources/payloads/getorder.json");

            // Start - Reading billing account created in Allocate BAN from the file

            BufferedReader br = null;
            FileReader fr = null;

            //br = new BufferedReader(new FileReader(FILENAME));
            fr = new FileReader ("accountsit.txt");
            br = new BufferedReader (fr);

            String Billact;

            while ((Billact = br.readLine ()) != null && !Billact.equals ("")) {
                System.out.println (Billact);
                break;
            }

            if (br != null)
                br.close ();

            if (fr != null)
                fr.close ();

            jsonBody.remove ("client_acct_id");
            jsonBody.put ("client_acct_id",Long.valueOf (Billact));


            tokenRequest.body (jsonBody.toString ());
//            System.out.println(jsonBody.toString());
            Response tokenResponse = tokenRequest.post ("https://api.current.stage.aus.ariasystems.net/api/ws/api_ws_class_dispatcher.php");
            System.out.println(tokenResponse.body().toString());

//            JSONArray array = (JSONArray) tokenResponse.body().toString();
//            JSONArray array = (JSONArray) tokenResponse.body().toString()
//            JSONObject orders = (JSONObject) array.get (0);


//            JSONObject jsonObject = new JSONObject(jsonString);
//            JSONObject myResponse = jsonObject.getJSONObject("MyResponse");
//            JSONArray tsmresponse = (JSONArray) myResponse.get("listTsm");


            System.out.println("orders.amount");
            System.out.println("orders.client_plan_instance_id");
            System.out.println("orders.client_order_id");

//
//            log.info("ARIA Account creation Response:--->" + tokenResponse.asString ());
//            Assert.assertEquals(200 ,tokenResponse.getStatusCode());
            tokenResponse.then ().log ().all ();
            JsonPath jsonRespBody = tokenResponse.jsonPath ();
//
//            JSONArray array = (JSONArray) jsonRespBody.get ("orders");
//            JSONObject orders = (JSONObject) array.get (0);
//            orders.get("")

//            int ErrorCode = 0;
//            ErrorCode = jsonRespBody.get ("error_code");
//
//            System.out.println ("ErrorCode : " + ErrorCode);


                   }
//        public static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException {
//
//            String password = "secret";
//            KeyStore keyStore = KeyStore.getInstance ("jks");
//            KeyStore trustStore = KeyStore.getInstance ("jks");
//
//            keyStore.load (
//                    new FileInputStream(new File("src/test/resources/certificates/AriaKeystore.jks")),
//                    password.toCharArray ());
//
//            trustStore.load (
//                    new FileInputStream (new File ("src/test/resources/certificates/AriaTruststore.jks")),
//                    password.toCharArray ());
//            RestAssuredConfig restAssuredConfig = null;
//
//            restAssuredConfig = RestAssured.config ().sslConfig (SSLConfig.sslConfig ()
//                    .keyStore ("src/test/resources/certificates/AriaKeystore.jks", password).
//                            trustStore ("src/test/resources/certificates/AriaTruststore.jks", password));
//
//            restAssuredConfig = RestAssured.config ().sslConfig (SSLConfig.sslConfig ()
//                    .trustStore (trustStore).trustStoreType ("JKS")
//                    .keyStore (new File ("src/test/resources/certificates/AriaKeystore.jks"), password).keystoreType ("JKS").and ().allowAllHostnames ());
//
//            if (null == restAssuredConfig) {
//                System.out.println ("Certificate not Set");
//                log.fatal ("certificates not set successfully and needs investigation ");
//            }
//            return restAssuredConfig;
//            // End - setting the certificates
//        }
        
        public static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException
    	{
    		String password = "U2CEDGE";
    		KeyStore keyStore = KeyStore.getInstance("jks");
    		TrustStrategy acceptingTrustStrategy = new TrustStrategy()
    		{
    			@Override
    			public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException
    			{
    				return true;
    			}
    		};
    		keyStore.load(new FileInputStream(new File(ARIAKeyStore)), password.toCharArray());
    		SSLContext sslContext1 = new SSLContextBuilder().useProtocol("TLSv1.2").loadKeyMaterial(keyStore, password.toCharArray()).loadTrustMaterial(null, acceptingTrustStrategy).build();
    		@SuppressWarnings("deprecation")
    		SSLSocketFactory factory = new SSLSocketFactory(sslContext1, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
    		RestAssuredConfig restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig().sslSocketFactory(factory));
    		return restAssuredConfig;
    	}
    }


