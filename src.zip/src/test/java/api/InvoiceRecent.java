package api;

import static apiUtils.GlobalConstants.InvoiceRecentPath;
import static org.junit.Assert.assertEquals;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.UUID;
import org.apache.log4j.Logger;
import org.json.simple.parser.ParseException;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class InvoiceRecent
{
	static Logger log = Logger.getLogger(InvoiceRecent.class);

	public static void invoiceRec() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException
	{
		RequestSpecification tokenRequest = new RestAssured().given();
		tokenRequest.auth().none();
		tokenRequest.header("Content-Type", "application/json");
		UUID uuid = UUID.randomUUID();
		tokenRequest.header("CorrelationId", uuid.toString());
		System.out.println("Correlation Id is " + uuid.toString());
		// tokenRequest.header ("Accept", "application/pdf");
		tokenRequest.config(CreatePlan.setCertificates());
		BufferedReader br = null;
		FileReader fr = null;
		fr = new FileReader("testReports/invoicebansit.txt");
		br = new BufferedReader(fr);
		String Billact;
		while ((Billact = br.readLine()) != null && !Billact.equals(""))
		{
			System.out.println(Billact);
			break;
		}

		if (br != null)
			br.close();

		if (fr != null)
			fr.close();

		log.info("Invoke Invoice Manager(Recent Invoice) API");
		log.info("Invoice Manager(Recent Invoice) Request:--->" + Billact);
		Response tokenResponse = tokenRequest.get(InvoiceRecentPath + Billact);
		System.out.println(tokenResponse.asString());
		log.info("Invoice Manager(Recent Invoice) Response:--->" + tokenResponse.asString());
		assertEquals(200, tokenResponse.getStatusCode());
		// Assert.assertEquals (tokenResponse.getStatusCode (), 200);
		log.info("Invoice Manager(Recent Invoice) Response:--->" + tokenResponse.asString());
		tokenResponse.then().log().all();
		JsonPath jsonRespBody = tokenResponse.jsonPath();
	}

	// Start - Setting certificates for this API call

	// private static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException {
	//
	// String password = "U2CEDGE";
	// KeyStore keyStore = KeyStore.getInstance("jks");
	// KeyStore trustStore = KeyStore.getInstance("jks");
	//
	// keyStore.load(
	// new FileInputStream (new File ("src/test/resources/certificates/b2b-agilebiller-keystore-sit.jks")),
	// password.toCharArray());
	//
	// trustStore.load(
	// new FileInputStream(new File("src/test/resources/certificates/b2b-agilebiller-truststore-sit.jks")),
	// password.toCharArray());
	//
	// RestAssuredConfig restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig()
	// .keyStore("src/test/resources/certificates/b2b-agilebiller-keystore-sit.jks",password)
	// .trustStore("src/test/resources/certificates/b2b-agilebiller-truststore-sit.jks",password));
	//
	// return restAssuredConfig;
	//
	// }
	// End - setting the certificates
}
