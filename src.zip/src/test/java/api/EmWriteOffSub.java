package api;

import apiUtils.ApiUtils;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static apiUtils.ApiUtils.randomAlphaNumeric;
import static apiUtils.GlobalConstants.*;
import static io.restassured.specification.ProxySpecification.host;
import static org.junit.Assert.assertEquals;

public class EmWriteOffSub {


    static Logger log = Logger.getLogger(ModSub.class);
    public static String Billact=null;
    static String ParentProd_ID=null;
    static String RcParentID1=null;
    
    public static void CancelsubscriptionEM() {
        String correlationId = "";
        correlationId = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (12);
        System.out.println ("Correlation Id is " + correlationId);
        try {
            String token = AllocateBAN.getToken ();
            int statuscode = CancelSubEM (correlationId,token);
            //System.out.println ("Cor Id : Statuscode" + "-" + correlationId + ":" + statuscode);
        }catch (Exception e) {
            System.out.println (e.getMessage ());
            log.fatal ("Modify subscription failed from BDS/ARIA and needs investigation");
            e.printStackTrace ();

        }}
    public static void CancelSolutionEM() {
        String correlationId = "";
        correlationId = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (12);
        System.out.println ("Correlation Id is " + correlationId);
        try {
            String token = AllocateBAN.getToken ();
            int statuscode = CancelSolEM (correlationId,token);
            //System.out.println ("Cor Id : Statuscode" + "-" + correlationId + ":" + statuscode);
        }catch (Exception e) {
            System.out.println (e.getMessage ());
            log.fatal ("Modify subscription failed from BDS/ARIA and needs investigation");
            e.printStackTrace ();

        }}

    public static int CancelSubEM (String correlationId, String token) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException, InterruptedException {
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
    	Properties p=new Properties();
    	p.load(reader);
    	String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
        RequestSpecification tokenRequest = new RestAssured ().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
        tokenRequest.auth().none();
        tokenRequest.header ("Content-Type", "application/json");
        String tokenHeader = "Bearer " + token;
        System.out.println (token);
        tokenRequest.header ("Authorization", tokenHeader);
        tokenRequest.header("Source-System","SFDC");
        UUID uuid = UUID.randomUUID();
        tokenRequest.header("Correlation-Id", uuid.toString());
        System.out.println ("Correlation Id is " + uuid.toString());
        tokenRequest.header ("X-HTTP-Method-Override", "PATCH");
        tokenRequest.config (PostSub.setCertificates ());


        // Start - Generating unique  Product ID

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat ("ddMMyyhhmmss");
        String finalUuid = simpleDateFormat.format (new Date ());
        System.out.println (finalUuid);

        SimpleDateFormat Effdate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        Effdate.setTimeZone (TimeZone.getTimeZone ("UTC"));
        String Efecdate = Effdate.format (new Date ());
        System.out.println (Efecdate);

        int ParCnt = 0;
        ParCnt++;

        String ParentID = "";
        //ParentID = "FN" + "-" + finalUuid + ParCnt;
        ParentID = "FN-1408181117251";

        System.out.println ("ParentProductinstanceID Id is " + ParentID);

        // End - Generating unique  Product ID

        // Start - Generating unique Recurring charge product instance ID

        int RcCnt = 1;
        RcCnt++;

        String RCParentID = "";
        RCParentID = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (3) + "-" + finalUuid + RcCnt;
        System.out.println ("RCProductinstanceID Id is " + RCParentID);

        // End - Generating unique Recurring charge product instance ID

        // Start - Generating unique Non-Recurring charge product instance ID

        int NRCCnt = 2;
        NRCCnt++;

        String NRCParentID = "";
        NRCParentID = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (3) + "-" + finalUuid + NRCCnt;
        System.out.println ("NRCProductinstanceID Id is " + NRCParentID);

        // End -   Generating unique Non-Recurring charge product instance ID

        // Start - Generating unique Usage charge product instance ID

        int USGCnt = 3;
        USGCnt++;
        //System.out.println(USGCnt);

        String USGParentID = "";
        //USGParentID = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (12);
        USGParentID = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (3) + "-" + finalUuid + USGCnt;
        System.out.println ("USGProductinstanceID Id is " + USGParentID);

        // End - Generating unique Usage charge product instance ID

        // Start - Generating Unique service instance ID//

        String RCServiceID = "";
        RCServiceID = randomAlphaNumeric (3) + "-" + finalUuid + RcCnt;

        String NRCServiceID = "";
        NRCServiceID = randomAlphaNumeric (3) + "-" + finalUuid + NRCCnt;

        String USGServiceID = "";
        USGServiceID = randomAlphaNumeric (3) + "-" + finalUuid + USGCnt;

        // End- Generating Unique service instance ID//

        //  Start - Reading Json body as a  file  //
        JSONObject jsonBody = ApiUtils.getJsonFromFile(CancelSubEMFile);
        //  End - Reading Json body as a  file  //

        // Start - Reading billing account created in Allocate BAN from the file

        BufferedReader br = null;
        FileReader fr = null;

        //br = new BufferedReader(new FileReader(FILENAME));
        fr = new FileReader ("accountsit.txt");
        br = new BufferedReader (fr);

        

        while ((Billact = br.readLine ()) != null && !Billact.equals ("")) {
            System.out.println (Billact);
            break;
        }

        if (br != null)
            br.close ();

        if (fr != null)
            fr.close ();

        // Read product ID and product instance ID from create Subscription

        File file = new File ("ProdInIDSIT.txt");

        Scanner sc = new Scanner (file);

        String ProdID = null;
        int a=0;
        String Prod_id[] = new String [11];
        //  for ( array[a]=1; array[a]<=2; array[a]++){
        while (sc.hasNextLine ()) {
            ProdID = sc.nextLine ();
            System.out.println (ProdID);
            Prod_id[a] =  ProdID;
            a++;
        }
        sc.close ();
        ParentProd_ID =  Prod_id[0];
        String USGParentID1  =  Prod_id[1];
        String USGParentID2  =  Prod_id[2];
        RcParentID1   =  Prod_id[3];
        String RcParentID2   =  Prod_id[4];
        String RcParentID3   =  Prod_id[5];
        String RcParentID4   =  Prod_id[6];
        String MIAServiceID  =  Prod_id[7];
        String IMSI          =  Prod_id[8];
        String Voice         =  Prod_id[9];
        String PriceAltID    =  Prod_id[10];


        System.out.println(ParentProd_ID);
        System.out.println(USGParentID1);
        System.out.println(USGParentID2);
        System.out.println(RcParentID1);
        System.out.println(RcParentID2);
        System.out.println(RcParentID3);
        System.out.println(PriceAltID);



        jsonBody.remove ("billingAccountNumber");
        jsonBody.put ("billingAccountNumber",Long.valueOf (Billact));

//          System.out.println("billingAccountNumber");

        JSONObject Prodoffr = (JSONObject) jsonBody.get("productOffering");
        Prodoffr.remove ("productInstanceId");
        Prodoffr.put ("productInstanceId",ParentProd_ID);
        
        Prodoffr.remove ("offerInstanceId");
        Prodoffr.put ("offerInstanceId",PphhSolutionsubscription.ParentID);

        JSONArray array = (JSONArray) jsonBody.get ("orderItems");
        JSONObject orderItems = (JSONObject) array.get (0);
        
        JSONArray productCharacteristics = (JSONArray) orderItems.get ("productCharacteristics");
        JSONObject productCharacteristicsObj = (JSONObject) productCharacteristics.get (0);
        JSONArray characteristics = (JSONArray) productCharacteristicsObj.get("characteristics");
        JSONObject characteristicsObj1 = (JSONObject) characteristics.get (0);
        characteristicsObj1.remove("value");
        characteristicsObj1.put ("value",MIAServiceID);
        
        JSONObject characteristicsObj2 = (JSONObject) characteristics.get (1);
        characteristicsObj2.remove ("value");
        characteristicsObj2.put ("value",IMSI);
        //         System.out.println("Prod Offering santhosh : "+ ParentID);

        jsonBody.remove ("effectiveDate");
        jsonBody.put ("effectiveDate",Efecdate);

//            System.out.println("effectiveDate santhosh : "+ Efecdate);

        JSONArray orderitem = new JSONArray ();
        JSONArray Billspec = new JSONArray ();

//        JSONArray array = (JSONArray) jsonBody.get ("orderItems");
//        JSONObject orderItems = (JSONObject) array.get (0);
        orderItems.remove ("effectiveDate");
        orderItems.put ("effectiveDate",Efecdate);


        orderItems = (JSONObject) array.get (0);
        JSONArray billingSpecification = (JSONArray) orderItems.get ("billingSpecifications");
        JSONObject billingSpecObj = (JSONObject) billingSpecification.get (0);
        billingSpecObj.remove ("instanceId");
        billingSpecObj.put ("instanceId",USGParentID1);
        System.out.println("Santhosh Bill1  "+ USGParentID1);

//        orderItems = (JSONObject) array.get (1);
//        JSONArray billingSpecification1 = (JSONArray) orderItems.get ("billingSpecifications");
        JSONObject billingSpecObj1 = (JSONObject) billingSpecification.get (1);
        billingSpecObj1.remove ("instanceId");
        billingSpecObj1.put ("instanceId",USGParentID2);
        
        JSONArray priceAltArr = (JSONArray) billingSpecObj1.get("priceAlteration");
        JSONObject priceAltObj = (JSONObject) priceAltArr.get(0);
        priceAltObj.remove("instanceId");
        priceAltObj.put("instanceId", PriceAltID);
        
        orderItems.remove ("effectiveDate");
        orderItems.put ("effectiveDate",Efecdate);

        orderItems = (JSONObject) array.get (1);
        JSONArray billingSpecification2 = (JSONArray) orderItems.get ("billingSpecifications");
        JSONObject billingSpecObj2 = (JSONObject) billingSpecification2.get (0);
        billingSpecObj2.remove ("instanceId");
        billingSpecObj2.put ("instanceId",RcParentID1);
        orderItems.remove ("effectiveDate");
        orderItems.put ("effectiveDate",Efecdate);
        
        orderItems = (JSONObject) array.get (2);
        JSONArray billingSpecification3 = (JSONArray) orderItems.get ("billingSpecifications");
        JSONObject billingSpecObj3 = (JSONObject) billingSpecification3.get (0);
        billingSpecObj3.remove ("instanceId");
        billingSpecObj3.put ("instanceId",RcParentID2);
        orderItems.remove ("effectiveDate");
        orderItems.put ("effectiveDate",Efecdate);
  
        int RCCnt1 = 3;
        String RcParentID5 = "";
        RcParentID5 = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (3) + "-" + finalUuid + RCCnt1;
        System.out.println ("RcParentID5 Id is " + RcParentID5);
        
        JSONObject billingSpecObj4 = (JSONObject) billingSpecification3.get (1);
        billingSpecObj4.remove ("instanceId");
        billingSpecObj4.put ("instanceId",RcParentID5);

        Long Billingno = 0L;
        Billingno = Long.valueOf (Billact);

        tokenRequest.body (jsonBody.toString ());
        log.info("Modify Post Subscription API");
        log.info("Modify Subscription Request:--->" + jsonBody.toString ());

        System.out.println (jsonBody.toString ());
        
        System.out.println("URL is " + PphhIndSubsURL+Billingno+"/subscriptions/"+ParentProd_ID);

        TimeUnit.SECONDS.sleep(10);
        Response tokenResponse = tokenRequest.patch(PphhIndSubsURL+Billingno+"/subscriptions/"+ParentProd_ID);

//        Assert.assertEquals (tokenResponse.getStatusCode (), 202);
        log.info("Cancel Subscription Response:--->" + tokenResponse.asString ());
        assertEquals(202, tokenResponse.getStatusCode());

        tokenResponse.then ().log ().all ();

        JsonPath jsonRespBody = tokenResponse.jsonPath ();
        log.info("Post Subscription Response:--->" + tokenResponse.asString ());

        int statuscode = jsonRespBody.get ("status");
        
        TimeUnit.SECONDS.sleep(10);
        
//      Terminating the contract for 1 month Individual subscription -tax
        RequestSpecification terminateContractReq = new RestAssured ().given ().proxy (host ("bcavi.tcif.telstra.com.au").withPort (8080).withAuth (p.getProperty("userName"), decodedPassword));
        terminateContractReq.auth ().none ();
        terminateContractReq.header ("Content-Type", "application/json");
        terminateContractReq.config (GetAccountdetailsm.setCertificates ());
        
        JSONObject terminateContractJSON = ApiUtils.getJsonFromFile("/src/test/resources/payloads/cancel_instance_contract_m.json");

        terminateContractJSON.remove ("client_acct_id");
        terminateContractJSON.put ("client_acct_id",Long.valueOf (Billact));
        
        terminateContractJSON.remove("client_contract_id");
        terminateContractJSON.put("client_contract_id", RcParentID1+"-tax-RO");

        terminateContractReq.body (terminateContractJSON.toString ());
        System.out.println(terminateContractJSON.toString());

        Response terminateContractResponse = terminateContractReq.post ("https://api.current.stage.aus.ariasystems.net/api/ws/api_ws_class_dispatcher.php");

        System.out.println(terminateContractResponse.body().toString());
        log.info("Terminate Contract Response:--->" + terminateContractResponse.asString ());
        Assert.assertEquals(200 ,terminateContractResponse.getStatusCode());
        terminateContractResponse.then ().log ().all ();
        
//      Cancellation of the plan 1 month Individual subscription -tax
        RequestSpecification cancelPlanReq = new RestAssured ().given ().proxy (host ("bcavi.tcif.telstra.com.au").withPort (8080).withAuth (p.getProperty("userName"), decodedPassword));
        cancelPlanReq.auth ().none ();
        cancelPlanReq.header ("Content-Type", "application/json");
        cancelPlanReq.config (GetAccountdetailsm.setCertificates ());
        
        JSONObject cancelPlanJSON = ApiUtils.getJsonFromFile("/src/test/resources/payloads/update_acct_plan_status_m.json");

        cancelPlanJSON.remove ("client_acct_id");
        cancelPlanJSON.put ("client_acct_id",Long.valueOf (Billact));
        
        cancelPlanJSON.remove("client_plan_instance_id");
        cancelPlanJSON.put("client_plan_instance_id", RcParentID1+"-tax");

        cancelPlanReq.body (cancelPlanJSON.toString ());
        System.out.println(cancelPlanJSON.toString());

        Response cancelPlanResponse = cancelPlanReq.post ("https://api.current.stage.aus.ariasystems.net/api/ws/api_ws_class_dispatcher.php");

        System.out.println(cancelPlanResponse.body().toString());
        log.info("Cancel Individual Subscription Response:--->" + cancelPlanResponse.asString ());
        Assert.assertEquals(200 ,cancelPlanResponse.getStatusCode());
        cancelPlanResponse.then ().log ().all ();
        
        return statuscode;
    }
    
    public static int CancelSolEM (String correlationId, String token) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException, InterruptedException {
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
    	Properties p=new Properties();
    	p.load(reader);
    	String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
        RequestSpecification tokenRequest = new RestAssured ().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
        tokenRequest.auth().none();
        tokenRequest.header ("Content-Type", "application/json");
        String tokenHeader = "Bearer " + token;
        System.out.println (token);
        tokenRequest.header ("Authorization", tokenHeader);
        tokenRequest.header("Source-System","SFDC");
        UUID uuid = UUID.randomUUID();
        tokenRequest.header("Correlation-Id", uuid.toString());
        System.out.println ("Correlation Id is " + uuid.toString());
        tokenRequest.header ("X-HTTP-Method-Override", "PATCH");
        tokenRequest.config (PostSub.setCertificates ());
        
        JSONObject jsonBody = ApiUtils.getJsonFromFile(CancelSolEMFile);
        
        jsonBody.remove ("billingAccountNumber");
        jsonBody.put ("billingAccountNumber",Long.valueOf (Billact));
        
        JSONObject Prodoffr = (JSONObject) jsonBody.get("productOffering");
        Prodoffr.remove ("productInstanceId");
        Prodoffr.put ("productInstanceId",PphhSolutionsubscription.ParentID);       
        Prodoffr.remove ("offerInstanceId");
        Prodoffr.put ("offerInstanceId",PphhSolutionsubscription.ParentID);

        Long Billingno = 0L;
        Billingno = Long.valueOf (Billact);

        tokenRequest.body (jsonBody.toString ());
        log.info("Cease CMP Solution API");
        log.info("Cease CMP Solution Request:--->" + jsonBody.toString ());

        System.out.println (jsonBody.toString ());
        
        System.out.println("URL is " + PphhIndSubsURL+Billingno+"/subscriptions/"+PphhSolutionsubscription.ParentID);

//        TimeUnit.SECONDS.sleep(10);
        Response tokenResponse = tokenRequest.patch(PphhIndSubsURL+Billingno+"/subscriptions/"+PphhSolutionsubscription.ParentID);

        log.info("Cancel solution Response:--->" + tokenResponse.asString ());
        assertEquals(202, tokenResponse.getStatusCode());

        tokenResponse.then ().log ().all ();

        JsonPath jsonRespBody = tokenResponse.jsonPath ();
        log.info("Cancel Solution Response:--->" + tokenResponse.asString ());
       
     int statuscode = jsonRespBody.get ("status");
     return statuscode;
        
    }

    public static void setBillLagDays() throws IOException, KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, CertificateException, KeyStoreException, ParseException
   {
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
		Properties p=new Properties();
		p.load(reader);
		String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));   	
   		RequestSpecification tokenRequest = new RestAssured ().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
   		tokenRequest.auth().none();
   		tokenRequest.header ("Content-Type", "application/json"); 		
   		tokenRequest.config (GetAccountdetailsm.setCertificates ());
        
        JSONObject jsonBody = ApiUtils.getJsonFromFile("/src/test/resources/payloads/set_bill_lag_days.json");

        jsonBody.remove ("client_acct_id");
        jsonBody.put ("client_acct_id",Long.valueOf (Billact));
        
        JSONObject plan_updates = (JSONObject) jsonBody.get("plan_updates");
        JSONArray plan_updates_row = (JSONArray) plan_updates.get("plan_updates_row");
        
        JSONObject plan_updates_row1 = (JSONObject) plan_updates_row.get(0);
        plan_updates_row1.remove("existing_client_plan_instance_id");
        plan_updates_row1.put("existing_client_plan_instance_id", Billact+"_mp1");
        
        JSONObject plan_updates_row2 = (JSONObject) plan_updates_row.get(1);
        plan_updates_row2.remove("existing_client_plan_instance_id");
        plan_updates_row2.put("existing_client_plan_instance_id", PphhSolutionsubscription.ParentID);
        
        JSONObject plan_updates_row3 = (JSONObject) plan_updates_row.get(2);
        plan_updates_row3.remove("existing_client_plan_instance_id");
        plan_updates_row3.put("existing_client_plan_instance_id", ParentProd_ID);
        
        JSONObject plan_updates_row4 = (JSONObject) plan_updates_row.get(3);
        plan_updates_row4.remove("existing_client_plan_instance_id");
        plan_updates_row4.put("existing_client_plan_instance_id", RcParentID1+"-tax");

        tokenRequest.body (jsonBody.toString ());
        System.out.println(jsonBody.toString());

        Response tokenResponse = tokenRequest.post ("https://api.current.stage.aus.ariasystems.net/api/ws/api_ws_class_dispatcher.php");

        System.out.println(tokenResponse.body().toString());
        log.info("Set bill lag days Response:--->" + tokenResponse.asString ());
        Assert.assertEquals(200 ,tokenResponse.getStatusCode());
        tokenResponse.then ().log ().all ();
   }
    
    public static void generateInvoice()
    {
		try
		{
			FileReader reader=new FileReader("configs/credentialSetting.properties");  
	   		Properties p=new Properties();
	   		p.load(reader);
	   		String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
	   		RequestSpecification genInvoiceReq = new RestAssured ().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
	   		genInvoiceReq.auth().none();
	   		genInvoiceReq.header ("Content-Type", "application/json"); 		
	   		genInvoiceReq.config (GetAccountdetailsm.setCertificates ());
	   		
	   		JSONObject jsonBody = ApiUtils.getJsonFromFile("/src/test/resources/payloads/gen_invoice_m.json");

	        jsonBody.remove ("client_acct_id");
	        jsonBody.put ("client_acct_id",Long.valueOf (Billact));
	        
	        genInvoiceReq.body (jsonBody.toString ());
	        System.out.println(jsonBody.toString());

	        Response genInvoiceResponse = genInvoiceReq.post ("https://api.current.stage.aus.ariasystems.net/api/ws/api_ws_class_dispatcher.php");
	   		
	   		
	   		System.out.println(genInvoiceResponse.body().toString());
	        log.info("Generate invoice Response:--->" + genInvoiceResponse.asString ());
	        Assert.assertEquals(200 ,genInvoiceResponse.getStatusCode());
	        genInvoiceResponse.then ().log ().all ();

			/**
			 * Code for statement generation below
			 */
	        
	        RequestSpecification genStatementReq = new RestAssured ().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
	        genStatementReq.auth().none();
	        genStatementReq.header ("Content-Type", "application/json"); 		
	        genStatementReq.config (GetAccountdetailsm.setCertificates ());
	   		
	        JSONObject jsonBody1 = ApiUtils.getJsonFromFile("/src/test/resources/payloads/gen_statement_m.json");

	        jsonBody1.remove ("client_acct_id");
	        jsonBody1.put ("client_acct_id",Long.valueOf (Billact));
	        
	        jsonBody1.remove("client_master_plan_instance_id");
	        jsonBody1.put("client_master_plan_instance_id",ParentProd_ID);
	        
	        genStatementReq.body (jsonBody1.toString ());
	        System.out.println(jsonBody1.toString());

	        Response genStatementResponse = genStatementReq.post ("https://api.current.stage.aus.ariasystems.net/api/ws/api_ws_class_dispatcher.php");
	   		
	   		
	   		System.out.println(genStatementResponse.body().toString());
	        log.info("Generate invoice Response:--->" + genStatementResponse.asString ());
	        Assert.assertEquals(200 ,genStatementResponse.getStatusCode());
	        genStatementResponse.then ().log ().all ();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			log.info("Failed in Statement Creation " + e.getMessage());
		}
    }
    
    public static void update_acct_status(String status) throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, CertificateException, FileNotFoundException, KeyStoreException, IOException, ParseException
    {
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
        Properties p=new Properties();
        p.load(reader);
        String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
        RequestSpecification request = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
        request.auth().none();
        request.header ("Content-Type", "application/json");
        String token = AllocateBAN.getToken ();
        String tokenHeader = "Bearer " + token;
        System.out.println (token);
        request.header ("Authorization", tokenHeader);
        request.header("Source-System","SFDC");
        UUID uuid = UUID.randomUUID();
        request.header("Correlation-Id", uuid.toString());
        System.out.println ("Correlation Id is " + uuid.toString());
        request.config (PphhSolutionsubscription.setCertificates());
        
        JSONObject jsonBody = ApiUtils.getJsonFromFile("/src/test/resources/payloads/update_acct_status.json");
        JSONObject billingAccount = (JSONObject) jsonBody.get("billingAccount");
		billingAccount.remove("billingAccountNumber");
		billingAccount.put("billingAccountNumber", Long.valueOf (Billact));
    	switch(status)
    	{
    	case "Pending Finalisation" :   		
    		billingAccount.remove("status");
    		billingAccount.put("status", status);   
        	
    		break;
    	case "Final" :    		
    		billingAccount.remove("status");
    		billingAccount.put("status", status);
    		break;
    	}
    	

    	request.body (jsonBody.toString ());
        System.out.println(jsonBody.toString());

        Response response = request.patch(ViewBanURL+Long.valueOf (Billact));

        log.info("Acct status update Response:--->" + response.asString ());
        Assert.assertEquals(200 ,response.getStatusCode());
        response.then ().log ().all ();
        
        Response responseARIA=get_acct_status_ARIA(Billact);
        Response responseBDS=get_acct_status_BDS(Billact,token);
        
        JsonPath var = responseARIA.jsonPath();
        String acctStatusARIA = var.get("supp_field[2].supp_field_value");
        
        JsonPath var1 = responseBDS.jsonPath();
        String acctStatusBDS = var1.get("billingAccount.status");
        
        Assert.assertEquals(status, acctStatusARIA);
        Assert.assertEquals(status, acctStatusBDS);
    	
    }
    
    public static Response get_acct_status_ARIA(String BAN) throws IOException, KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, CertificateException, KeyStoreException, ParseException
    {
    	String acctStatus=null;
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
		Properties p=new Properties();
		p.load(reader);
		String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));   	
   		RequestSpecification tokenRequest = new RestAssured ().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
   		tokenRequest.auth().none();
   		tokenRequest.header ("Content-Type", "application/json"); 		
   		tokenRequest.config (GetAccountdetailsm.setCertificates ());
        
        JSONObject jsonBody = ApiUtils.getJsonFromFile("/src/test/resources/payloads/getaccount.json");
        Long Billingno = 0L;
        Billingno = Long.valueOf (Billact);
        jsonBody.remove ("client_acct_id");
        jsonBody.put ("client_acct_id",Billingno);
        
        tokenRequest.body (jsonBody.toString ());
        System.out.println(tokenRequest.toString());

        Response tokenResponse = tokenRequest.post ("https://api.current.stage.aus.ariasystems.net/api/ws/api_ws_class_dispatcher.php");

        System.out.println(tokenResponse.body().toString());
        log.info("Get Account Response:--->" + tokenResponse.asString ());
        Assert.assertEquals(200 ,tokenResponse.getStatusCode());
        tokenResponse.then ().log ().all ();
    	return tokenResponse;
    }
    
    public static Response get_acct_status_BDS(String BAN,String token) throws IOException, KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, CertificateException, KeyStoreException
    {
    	String acctStatus=null;
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
		Properties p=new Properties();
		p.load(reader);
		String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));   	
		RequestSpecification tokenRequest = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
        tokenRequest.auth().none();
        tokenRequest.header ("Content-Type", "application/json");
        String tokenHeader = "Bearer " + token;
        System.out.println (token);
        tokenRequest.header ("Authorization", tokenHeader);
        tokenRequest.header("Source-System","SFDC");
        UUID uuid = UUID.randomUUID();
        tokenRequest.header("Correlation-Id", uuid.toString()); 		
   		tokenRequest.config (PphhSolutionsubscription.setCertificates());
   		
   		Long Billingno = 0L;
        Billingno = Long.valueOf (BAN);
        
        Response tokenResponse = tokenRequest.get (ViewBanURL+Billingno);

        System.out.println(tokenResponse.body().toString());
        log.info("Retrieve Account Response:--->" + tokenResponse.asString ());
        Assert.assertEquals(200 ,tokenResponse.getStatusCode());
        tokenResponse.then ().log ().all ();
    	return tokenResponse;
    }

    public static void write_off() throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, CertificateException, KeyStoreException, IOException, ParseException
    {
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
        Properties p=new Properties();
        p.load(reader);
        String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
        RequestSpecification request = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
        request.auth().none();
        request.header ("Content-Type", "application/json");
        String token = AllocateBAN.getToken ();
        String tokenHeader = "Bearer " + token;
        System.out.println (token);
        request.header ("Authorization", tokenHeader);
        request.header("Source-System","SFDC");
        UUID uuid = UUID.randomUUID();
        request.header("Correlation-Id", uuid.toString());
        System.out.println ("Correlation Id is " + uuid.toString());
        request.config (PphhSolutionsubscription.setCertificates());
        
        JSONObject jsonBody = ApiUtils.getJsonFromFile("/src/test/resources/payloads/update_acct_status.json");
        JSONObject billingAccount = (JSONObject) jsonBody.get("billingAccount");
		billingAccount.remove("billingAccountNumber");
		billingAccount.put("billingAccountNumber", Long.valueOf (Billact));
		billingAccount.remove("writeOff");
		billingAccount.put("writeOff", true);
    	
    	request.body (jsonBody.toString ());
        System.out.println("WriteOff request body "+jsonBody.toString());

        Response response = request.patch(ViewBanURL+Long.valueOf (Billact));

        log.info("WriteOff Response:--->" + response.asString ());
        Assert.assertEquals(200 ,response.getStatusCode());
        response.then ().log ().all ();
        
        Response responseARIA=get_acct_status_ARIA(Billact);       
        JsonPath var = responseARIA.jsonPath();
        
        String acctStatusARIA = var.get("supp_field[2].supp_field_value");
        Assert.assertEquals("Final", acctStatusARIA);
        
        String writeOffStatus = var.get("supp_field[5].supp_field_value");
        Assert.assertEquals("WriteOff", writeOffStatus);
        
        String writeOffDebt = var.get("supp_field[4].supp_field_value");
        Assert.assertEquals("1569.61", writeOffDebt);
              
        Response responseBDS=get_acct_status_BDS(Billact,token); 
        JsonPath var1 = responseBDS.jsonPath();
        
        String acctStatusBDS = var1.get("billingAccount.status");       
        Assert.assertEquals("Final", acctStatusBDS);
        
        String writeOffStatusBDS = var1.get("billingAccount.writtenOffStatus");       
        Assert.assertEquals("WriteOff", writeOffStatusBDS);
        
        String writeOffAmount = var1.get("billingAccount.accountBalance.writtenOffAmount");       
        Assert.assertEquals("1569.61", writeOffAmount);
        
        int totalBalance = var1.get("billingAccount.accountBalance.totalBalance");       
        Assert.assertEquals(0, totalBalance);
    }

    public static void adjustment(String adjustmentType) throws IOException, UnrecoverableKeyException, KeyManagementException, CertificateException, NoSuchAlgorithmException, KeyStoreException, ParseException
    {
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
        Properties p=new Properties();
        p.load(reader);
        String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
        RequestSpecification request = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
        request.auth().none();
        request.header ("Content-Type", "application/json");
        String token = AllocateBAN.getToken ();
        String tokenHeader = "Bearer " + token;
        System.out.println (token);
        request.header ("Authorization", tokenHeader);
        request.header("Source-System","SFDC");
        UUID uuid = UUID.randomUUID();
        request.header("Correlation-Id", uuid.toString());
        System.out.println ("Correlation Id is " + uuid.toString());
        request.config (PphhSolutionsubscription.setCertificates());
        
        JSONObject jsonBody = ApiUtils.getJsonFromFile(adjustmentGoodWillFile);
        
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat ("ddMMyyhhmmss");
        String finalUuid = simpleDateFormat.format (new Date ());      
        int usCnt1 = 1;        
        String instanceID = "";
        instanceID = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (3) + "-" + finalUuid + usCnt1;
        System.out.println ("instanceId is " + instanceID);

        int num = new SecureRandom().nextInt(100000);
        String rand = String.format("%05d", num);
        String caseRefNum = "T0009"+rand;
        System.out.println ("caseReferenceNumber is " + caseRefNum);
        
        jsonBody.remove("instanceId");
        jsonBody.put("instanceId", instanceID);
             
        jsonBody.remove("caseReferenceNumber");
        jsonBody.put("caseReferenceNumber", caseRefNum);
        
        switch(adjustmentType)
        {
        case "Partial":
        	jsonBody.remove("amount");
            jsonBody.put("amount", 100);
        	break;
        case "Full":
        	jsonBody.remove("amount");
            jsonBody.put("amount", 1469.61);
        	break;
        }
   	
    	request.body (jsonBody.toString ());
        System.out.println("Adjustment request body "+jsonBody.toString());
        

        Response response = request.post(adjustmentURL+Long.valueOf (Billact)+"/adjustments");

        log.info("Goodwill credit adjsutment Response:--->" + response.asString ());
        Assert.assertEquals(201 ,response.getStatusCode());
        response.then ().log ().all ();
        
        Response responseARIA=get_acct_status_ARIA(Billact);       
        JsonPath var = responseARIA.jsonPath();
        
        Response responseBDS=get_acct_status_BDS(Billact,token); 
        JsonPath var1 = responseBDS.jsonPath();
                
        switch(adjustmentType)
        {
        case "Partial":
            String acctStatusARIA = var.get("supp_field[2].supp_field_value");
            Assert.assertEquals("Final", acctStatusARIA);
            
            String writeOffStatus = var.get("supp_field[5].supp_field_value");
            Assert.assertEquals("WriteOff", writeOffStatus);
            
            String writeOffDebt = var.get("supp_field[4].supp_field_value");
            Assert.assertEquals("1469.61", writeOffDebt);
                          
            String acctStatusBDS = var1.get("billingAccount.status");       
            Assert.assertEquals("Final", acctStatusBDS);
            
            String writeOffStatusBDS = var1.get("billingAccount.writtenOffStatus");       
            Assert.assertEquals("WriteOff", writeOffStatusBDS);
            
            String writeOffAmount = var1.get("billingAccount.accountBalance.writtenOffAmount");       
            Assert.assertEquals("1469.61", writeOffAmount);
            
            int totalBalance = var1.get("billingAccount.accountBalance.totalBalance");       
            Assert.assertEquals(0, totalBalance);
        	break;
        case "Full":
        	ResponseBody bodyARIA = responseARIA.getBody();
        	String bodyStringARIA = bodyARIA.asString();
        	System.out.println("Response is " +bodyStringARIA);
        	
        	 String acctStatusARIA1 = var.get("supp_field[2].supp_field_value");
             Assert.assertEquals("Final", acctStatusARIA1);
        	
        	ResponseBody bodyBDS = responseBDS.getBody();
        	String bodyStringBDS = bodyBDS.asString();
        	System.out.println("Response is " +bodyStringBDS);
        	
        	 String acctStatusBDS1 = var1.get("billingAccount.status");       
             Assert.assertEquals("Final", acctStatusBDS1);
             
             int totalBalance1 = var1.get("billingAccount.accountBalance.totalBalance");       
             Assert.assertEquals(0, totalBalance1);
        	
            Assert.assertTrue(bodyStringBDS.contains("\"status\":\"Final\","));
        	Assert.assertFalse(bodyStringARIA.contains("\"supp_field_name\" : \"writeoff_status\","));
        	Assert.assertFalse(bodyStringBDS.contains("\"writtenOffStatus\": \"WriteOff\","));
        	
        	break;
        }

            
        
    }

    public static void makePayment(String payment_Type , float amount) throws IOException, UnrecoverableKeyException, KeyManagementException, CertificateException, NoSuchAlgorithmException, KeyStoreException, ParseException
    {
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
        Properties p=new Properties();
        p.load(reader);
        String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
        RequestSpecification request = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
        request.auth().none();
        request.header ("Content-Type", "application/json");
        String token = AllocateBAN.getToken ();
        String tokenHeader = "Bearer " + token;
        System.out.println (token);
        request.header ("Authorization", tokenHeader);
        request.header("Source-System","SFDC");
        UUID uuid = UUID.randomUUID();
        request.header("Correlation-Id", uuid.toString());
        System.out.println ("Correlation Id is " + uuid.toString());
        request.config (PphhSolutionsubscription.setCertificates());
        
        JSONObject jsonBody = ApiUtils.getJsonFromFile(adjustmentGoodWillFile);
        
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat ("ddMMyyhhmmss");
        String finalUuid = simpleDateFormat.format (new Date ());      
        int usCnt1 = 1;        
        String instanceID = "";
        instanceID = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (3) + "-" + finalUuid + usCnt1;
        System.out.println ("instanceId is " + instanceID);

        int num = new SecureRandom().nextInt(100000);
        String rand = String.format("%05d", num);
        String caseRefNum = "T0009"+rand;
        System.out.println ("caseReferenceNumber is " + caseRefNum);
        
        jsonBody.remove("instanceId");
        jsonBody.put("instanceId", instanceID);
             
        jsonBody.remove("caseReferenceNumber");
        jsonBody.put("caseReferenceNumber", caseRefNum);
        
//        int paymentAmt = Integer.parseInt(amount);
        switch(payment_Type)
        {
        case "Partial":
        	jsonBody.remove("amount");
            jsonBody.put("amount", amount);
        	break;
        case "Full":
        	jsonBody.remove("amount");
            jsonBody.put("amount", amount);
        	break;
        }
   	
    	request.body (jsonBody.toString ());
        System.out.println("Adjustment request body "+jsonBody.toString());
        

        Response response = request.post(adjustmentURL+Long.valueOf (Billact)+"/adjustments");

        log.info("Goodwill credit adjsutment Response:--->" + response.asString ());
        Assert.assertEquals(201 ,response.getStatusCode());
        response.then ().log ().all ();
    }

    public static void writeOffPaymnetProcessor() throws KeyManagementException, UnrecoverableKeyException, NoSuchAlgorithmException, CertificateException, FileNotFoundException, KeyStoreException, IOException, ParseException
    {
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
        Properties p=new Properties();
        p.load(reader);
        String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
        RequestSpecification request = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
        request.auth().none();
        request.header ("Content-Type", "application/json");
        String token = PaymentBds.getToken_PaymentProcessor();
        String tokenHeader = "Bearer " + token;
        System.out.println (token);
        request.header ("Authorization", tokenHeader);
        request.header ("Accept", "application/json");
//        request.header("Source-System","SFDC");
        UUID uuid = UUID.randomUUID();
        request.header("correlationId", uuid.toString());
        System.out.println ("Correlation Id is " + uuid.toString());
        request.config (PphhSolutionsubscription.setCertificates());
        
        JSONObject jsonBody = ApiUtils.getJsonFromFile("/src/test/resources/payloads/writeOffPP.json");
        jsonBody.remove("billingAccountNumber");
        jsonBody.put("billingAccountNumber", Long.valueOf (Billact));
    	
    	request.body (jsonBody.toString ());
        System.out.println("WriteOff request body "+jsonBody.toString());

        Response response = request.post(WriteOff_agb_PP_URL);
        log.info("Acct status update Response:--->" + response.asString ());
        response.then ().log ().all ();
        
        Assert.assertEquals(200 ,response.getStatusCode());
        JsonPath resp = response.jsonPath();
        String errorMsg = resp.get("message");       
        Assert.assertEquals("No open Invoice to writeOff", errorMsg);
        
        Response responseARIA=get_acct_status_ARIA(Billact);       
        JsonPath var = responseARIA.jsonPath();
        
        String oAuthtoken = AllocateBAN.getToken ();
        Response responseBDS=get_acct_status_BDS(Billact,oAuthtoken); 
        JsonPath var1 = responseBDS.jsonPath();
        
        ResponseBody bodyARIA = responseARIA.getBody();
    	String bodyStringARIA = bodyARIA.asString();
    	System.out.println("Response is " +bodyStringARIA);
    	
    	 String acctStatusARIA1 = var.get("supp_field[2].supp_field_value");
         Assert.assertEquals("Final", acctStatusARIA1);
    	
    	ResponseBody bodyBDS = responseBDS.getBody();
    	String bodyStringBDS = bodyBDS.asString();
    	System.out.println("Response is " +bodyStringBDS);
    	
    	 String acctStatusBDS1 = var1.get("billingAccount.status");       
         Assert.assertEquals("Final", acctStatusBDS1);
         
         int totalBalance1 = var1.get("billingAccount.accountBalance.totalBalance"); 
//         int totalBalance11 = Math.round(totalBalance1);
         Assert.assertEquals(0, totalBalance1);
    	
        Assert.assertTrue(bodyStringBDS.contains("\"status\":\"Final\","));
    	Assert.assertFalse(bodyStringARIA.contains("\"supp_field_name\" : \"writeoff_status\","));
    	Assert.assertFalse(bodyStringBDS.contains("\"writtenOffStatus\": \"WriteOff\","));
        
    }
}
