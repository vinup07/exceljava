package api;

import static apiUtils.ApiUtils.randomAlphaNumeric;
import static apiUtils.GlobalConstants.CreateBANInputFile;
import static apiUtils.GlobalConstants.CreateBan;
import static io.restassured.specification.ProxySpecification.host;
import static org.junit.Assert.assertEquals;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Properties;
import java.util.UUID;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import apiUtils.ApiUtils;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateBAN
{
	static Logger log = Logger.getLogger(CreateBAN.class);

	public static void PostCreateBan()
	{
		String correlationId = "";
		correlationId = randomAlphaNumeric(8) + "-" + randomAlphaNumeric(4) + "-" + randomAlphaNumeric(4) + "-" + randomAlphaNumeric(4) + "-" + randomAlphaNumeric(12);
		// System.out.println ("Correlation Id is " + correlationId);
		try
		{
			String token = AllocateBAN.getToken();
			int statuscode = createBAN(correlationId, token);
			// System.out.println ("Cor Id : Statuscode" + "-" + correlationId + ":" + statuscode);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
			log.fatal("Create BAN failed from BDS and needs investigation");
			e.printStackTrace();
		}
	}

	public static int createBAN(String correlationId, String token) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException
	{
		FileReader reader = new FileReader("configs/credentialSetting.properties");
		Properties p = new Properties();
		p.load(reader);
		String decodedPassword = utils.EncryptPassword.decryptPassword(p.getProperty("password"));
		RequestSpecification tokenRequest = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
		tokenRequest.auth().none();
		tokenRequest.header("Content-Type", "application/json");
		String tokenHeader = "Bearer " + token;
		System.out.println(token);
		tokenRequest.header("Authorization", tokenHeader);
		tokenRequest.header("Source-System", "SFDC");
		UUID uuid = UUID.randomUUID();
		tokenRequest.header("Correlation-Id", uuid.toString());
		System.out.println("Correlation Id is " + uuid.toString());
		// tokenRequest.config(setCertificates());
		tokenRequest.config(AllocateBAN.setCertificates());

		// JSONObject jsonBody = ApiUtils.getJsonFromFile("/src/test/resources/payloads/createban.json");
		JSONObject jsonBody = ApiUtils.getJsonFromFile(CreateBANInputFile);

		BufferedReader br = null;
		FileReader fr = null;

		fr = new FileReader("accountsit.txt");
		br = new BufferedReader(fr);

		String Billact;

		while ((Billact = br.readLine()) != null && !Billact.equals(""))
		{
			System.out.println(Billact);
			break;
		}

		if (br != null)
			br.close();

		if (fr != null)
			fr.close();

		JSONObject billingAccount = (JSONObject) jsonBody.get("billingAccount");

		// jsonBody.get ("billingAccountNumber");

//		System.out.println("billingAccountNumber is " + billingAccount.get("billingAccountNumber"));

		billingAccount.remove("billingAccountNumber");

		System.out.println("  billingAccount is " + jsonBody);

		// billingAccount.put (billingAccount.put("billingAccountNumber"),"q233434");

		billingAccount.put("billingAccountNumber", Long.valueOf(Billact));

		System.out.println("  put billingAccount is " + jsonBody);

		tokenRequest.body(jsonBody.toString());
		log.info("Invoke Create Billing account number API");
		log.info("Create BAN Request:--->" + jsonBody.toString());

		System.out.println(jsonBody.toString());
		Response tokenResponse = tokenRequest.post(CreateBan);

		// Assert.assertEquals(tokenResponse.getStatusCode(), 201);
		log.info("Create BAN Response:--->" + tokenResponse.asString());

		System.out.println(tokenResponse.asString());

		// assertEquals(tokenResponse.getStatusCode(), 201);
		assertEquals(201, tokenResponse.getStatusCode());

		tokenResponse.then().log().all();

		JsonPath jsonRespBody = tokenResponse.jsonPath();

		// System.out.println(jsonRespBody.get("errors"));

		int statuscode = jsonRespBody.get("status");
		log.info("Create BAN Response:--->" + tokenResponse.asString());
		return statuscode;
	}
}
