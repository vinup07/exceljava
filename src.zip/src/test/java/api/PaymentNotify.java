package api;

import apiUtils.ApiUtils;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import java.io.*;
import java.util.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

import static api.BillNotify.getNotifyToken;
import static apiUtils.ApiUtils.randomAlphaNumeric;
import static apiUtils.GlobalConstants.NotifyBill;
import static apiUtils.GlobalConstants.PaymentinputFile;
import static io.restassured.specification.ProxySpecification.host;

public class PaymentNotify {

    //    private static Logger Log = Logger.getLogger(org.apache.commons.logging.Log.class.getName())
    static int num = 10, count = 1;
    static Logger log = Logger.getLogger(BillNotify.class);

    public static void PostPaymentNotify() {
        String correlationId = "";
        correlationId = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (12);
        //System.out.println ("Correlation Id is " + correlationId);

        try {
            String token = getNotifyToken ();
            int statuscode = PayNotify (correlationId,token);
            // System.out.println ("Cor Id : Statuscode" + "-" + correlationId + ":" + statuscode);
        }catch (Exception e){
            System.out.println (e.getMessage ());
            log.fatal ("Bill-Notify failed from BDS and needs investigation");
            e.printStackTrace ();

        }
    }

    public static int PayNotify (String correlationId, String token) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
    	Properties p=new Properties();
    	p.load(reader);
    	String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
        RequestSpecification tokenRequest = new RestAssured ().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth("d318101", decodedPassword));
        tokenRequest.auth().none();
        tokenRequest.header("Content-Type", "application/json");
        String tokenHeader = "Bearer " + token;
        System.out.println(token);
        tokenRequest.header("Authorization", tokenHeader);
        tokenRequest.header("Source-System","Agile-biller");
        UUID uuid = UUID.randomUUID();
        tokenRequest.header("Correlation-Id", uuid.toString());
        System.out.println ("Correlation Id is " + uuid.toString());
        tokenRequest.config(BillNotify.setCertificates());

        JSONObject jsonBody = ApiUtils.getJsonFromFile(PaymentinputFile);

        Date curDate = new Date();

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String Pymntdate = format.format(curDate);
        System.out.println(Pymntdate);

       // Start - Building up the Json body for API

        JSONObject eventDetails = (JSONObject) jsonBody.get("eventDetails");
        eventDetails.remove ("paymentDate");

//        System.out.println("  billIssueDate is "+ jsonBody);
        eventDetails.put ("paymentDate",Pymntdate);

        tokenRequest.body(jsonBody.toString());

        log.info("Invoke Payment Notification API from BDS");
        log.info("Payment Notification Payload:--->" + jsonBody.toString ());

        System.out.println(jsonBody.toString());
        Response tokenResponse = tokenRequest.post(NotifyBill);

        Assert.assertEquals(tokenResponse.getStatusCode(), 202);

        tokenResponse.then().log().all();

        JsonPath jsonRespBody = tokenResponse.jsonPath();

        int statuscode = jsonRespBody.get("status");
        log.info("Create BAN Response:--->" + tokenResponse.asString ());
        return statuscode;
    }

    // Start- Setting up the certificates to invoke API
//    private static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException {
//
//        String password = "secret";
//
//        KeyStore keyStore = KeyStore.getInstance("jks");
//        KeyStore trustStore = KeyStore.getInstance("jks");
//
//        keyStore.load(
//                new FileInputStream (new File ("src/test/resources/certificates/notify.jks")),
//                password.toCharArray());
//
//        trustStore.load(
//                new FileInputStream(new File("src/test/resources/certificates/okapi.jks")),
//                password.toCharArray());
//
//        RestAssuredConfig restAssuredConfig = null;
//
//        restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig()
//                .keyStore("src/test/resources/certificates/notify.jks", password).
//                        trustStore("src/test/resources/certificates/okapi.jks", password));
//
//
//
//        restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig()
//                .trustStore(trustStore).trustStoreType("JKS")
//                .keyStore(new File("src/test/resources/certificates/notify.jks"), password).keystoreType("JKS").and().allowAllHostnames());
//        // restAssuredConfig.getSSLConfig().allowAllHostnames();
//
//        if (null == restAssuredConfig) {
//            System.out.println("Certificate not Set");
//        }
//        return restAssuredConfig;
//    }

    // End- Setting up the certificates to invoke API
}
