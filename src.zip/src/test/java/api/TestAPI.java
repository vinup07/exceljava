package api;

import org.junit.Test;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.text.ParseException;

public class TestAPI {
////
//    @Test
//    public void testgettoken() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
//      // AllocateBAN.GetToken();
//
//        //System.out.println ("Cor Id : BAN" + "-" + correlationId + ":" + billingAccountNo);
//
//    }
//
//    @Test
//    public static void getAllocateBan() {
//        String correlationId = "";
//        correlationId = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (12);
//        System.out.println ("Correlation Id is " + correlationId);
//        try {
//            String token = AllocateBAN.getToken ();
//            System.out.println ("token is :" + token);
//            Long billingAccountNo = AllocateBAN.allocateBan (correlationId, token);
//            //Long billingAccountNo = allocateBan (correlationId);
//            System.out.println ("Cor Id : BAN" + "-" + correlationId + ":" + billingAccountNo);
//        } catch (Exception e) {
//            System.out.println (e.getMessage ());
//            e.printStackTrace ();
//        }
//    }

//     @Test
////    public void testcreateBan() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
//    public void PostCreateBan() {
//        String correlationId = "";
//        correlationId = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (12);
//        System.out.println ("Correlation Id is " + correlationId);
//        try {
//            String token = AllocateBAN.getToken ();
//            int statuscode = CreateBAN.createBAN (correlationId, token);
//            System.out.println ("Cor Id : Statuscode" + "-" + correlationId + ":" + statuscode);
//        } catch (Exception e) {
//            System.out.println (e.getMessage ());
//            e.printStackTrace ();
//
//        }
//    }

//     @Test
////     public void Postsubscription() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
//    public void Postsubscription() {
//        String correlationId = "";
//        correlationId = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (12);
//        System.out.println ("Correlation Id is " + correlationId);
//        try {
//            String token = AllocateBAN.getToken ();
//            int statuscode = PostSub.postsub (correlationId, token);
//            System.out.println ("Cor Id : Statuscode" + "-" + correlationId + ":" + statuscode);
//        } catch (Exception e) {
//            System.out.println (e.getMessage ());
//            e.printStackTrace ();
//
//        }
//    }

//    @Test
//
//    public void Postsubscription() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
//         PostSub.Postsubscription ();
//    }
//
//    @Test
//    public void CancelSubscription() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
//        CancelServiceSub.Cancelsubscription ();
//    }

//        @Test
//    public void GetAdjustment() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
//            GetAdjustment.GetAdjust ();
//    }

//    //@Test
//    //public void testViewBAN() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
//    public void ViewBillingAccount() {
//
//        try {
//            String token = AllocateBAN.getToken ();
//            int statuscode = ViewBAN.viewBAN (token);
//            System.out.println ("Statuscode" + ":" + statuscode);
//
//        } catch (Exception e) {
//            System.out.println (e.getMessage ());
//            e.printStackTrace ();
//
//        }
//    }


//    @Test
//    public void testModsubscription() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
//        String correlationId = "";
//        correlationId = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (12);
//        System.out.println ("Correlation Id is " + correlationId);
//        String token = AllocateBAN.GetToken ();
//        int statuscode = ModSub.modsub (correlationId,token);
//        System.out.println ("Cor Id : Statuscode" + "-" + correlationId + ":" + statuscode);
//
////    }
//    @Test
//    public void file() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
//        Sant.testA ();
//

//    @Test
//    public void WriteA() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
//        Writetest.WriteA ();
//
//   }

//
////    @Test
//    public void TestModSubscr() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
//        ModSub.Modsubscription ();
//
//    }
//
////    @Test
//    public void TestModBAN() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
//        ModifyBAN.PostModifyBan ();
//
//    }
//
////    @Test
//    public void TestInvoice() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
//        InvoiceBNum.invoice ();
//    }
//
////    @Test
//    public void TestInvoiceRecent() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
//        InvoiceRecent.invoiceRec ();
//    }
//
////    @Test
//    public void TestInvoiceMult() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
//        InvoiceMult.invoicemult ();
//    }
//
////    @Test
//    public void TestPayment() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
//        PaymentBds.PaymentRet ();
//    }
//
////    @Test
//    public void TestCustMS() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
//        BDSCustomerMS.CustomerMS ();
//    }
//
////    @Test
//    public void TestCreatePlan() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
//        CreatePlan.createplan ();
//    }
//
////    @Test
//    public void TestUpdatePlan() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
//        UpdatePlan.updateplan ();
//    }
//
//
////    @Test
//    public void Testallocate() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
//        AllocateBAN.getAllocateBan ();
//    }
//
////    @Test
//    public void TestPaymentRange() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
//        PaymentStrEnddt.PaymentdatRG ();
//    }
//
////    @Test
//    public void Testlog() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
//        TestA.testLogger ();
//    }
//
////    @Test
//    public void TestPaymentTran() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
//        PaymentTran.Paymenttran ();
//    }
//
//        @Test
//    public void TestBillNotify() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
//        BillNotify.PostNotifyBill ();
//    }
//
////    @Test
//    public void TestPayNotify() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
//        PaymentNotify.PostPaymentNotify ();
//    }

       @Test
    public void GetAccount() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
          GetAccountdetailsm.GetAccount ();
    }

    @Test
    public void GetOrderdetails() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
        GetOrder.Getorder ();
    }
    @Test
    public void GetAcctPlan() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
        GetAcctPlan.GetAccountplan ();
    }

    @Test
    public void PostCredAdjustment() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
        CreditAdjustment.PostCreditAdjust ();
    }

    @Test
    public void PostMobileSeat() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
        CreateMobileSeat.PostMobileSeat ();
    }

//       @Test
//    public void InvoiceMult() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, ParseException, KeyStoreException, org.json.simple.parser.ParseException {
//           InvoiceMult.invoicemult ();
//
//   }

}



