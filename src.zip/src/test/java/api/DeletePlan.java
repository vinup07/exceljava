package api;

import static apiUtils.GlobalConstants.AgileKeyStoreForAuthToekn;
import static apiUtils.GlobalConstants.AgileTrustStoreForAuthToeknPresit;
import static apiUtils.GlobalConstants.*;
import static apiUtils.GlobalConstants.SigmaOffer;
import static io.restassured.specification.ProxySpecification.host;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.UUID;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import apiUtils.ApiUtils;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.parsing.Parser;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DeletePlan
{

	static Logger log = Logger.getLogger(DeletePlan.class);

	public static void deletePlan() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException
	{
		FileReader reader=new FileReader("configs/credentialSetting.properties");  
    	Properties p=new Properties();
    	p.load(reader);
    	String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
//		RequestSpecification request = new RestAssured().given().proxy (host ("bcavi.tcif.telstra.com.au").withPort (8080).withAuth (p.getProperty("userName"), decodedPassword));
//		request.auth().none();
//		RestAssured.defaultParser = Parser.JSON;


    	RequestSpecification request = new RestAssured ().given ().proxy (host ("bcavi.tcif.telstra.com.au").withPort (8080).withAuth (p.getProperty("userName"), decodedPassword));
    	request.auth ().none ();

    	
		request.header("Content-Type", "application/json");
		request.config(GetAccountdetailsm.setCertificates ());
		JSONObject getPlanBody = ApiUtils.getJsonFromFile(GetPlanfile);
		
		BufferedReader br = null;
		FileReader fr = null;
		// br = new BufferedReader(new FileReader(FILENAME));
		fr = new FileReader("sigmaspecidsit.txt");
		br = new BufferedReader(fr);
		String SpecID;

		while ((SpecID = br.readLine()) != null && !SpecID.equals(""))
		{
			System.out.println(SpecID);
			break;
		}

		if (br != null)
			br.close();

		if (fr != null)
			fr.close();
		
		getPlanBody.remove("client_plan_id");
		getPlanBody.put("client_plan_id", SpecID);
		request.body(getPlanBody.toString());
		System.out.println(getPlanBody.toString());
		log.info("Get_plan_details_m request body is--->" + getPlanBody.toString());
		Response planDetails = request.get(AriaAdminTool);
		System.out.println(planDetails.asString());
		log.info("get_plan_details_m Response:--->" + planDetails.asString());
		planDetails.then().log().all();
		String statusCode = planDetails.then().extract().path("error_code").toString();
		System.out.println("Status Code is "+statusCode);
		Assert.assertEquals("0", statusCode);
		String plan_num = planDetails.then().extract().path("plan_no").toString();
		

		JSONObject deletePlanBody = ApiUtils.getJsonFromFile(DeletePlanfile);
		JSONArray plan_nos = (JSONArray) deletePlanBody.get("plan_nos");
		plan_nos.clear();
		plan_nos.add(plan_num);
		request.body(deletePlanBody.toString());
		System.out.println(deletePlanBody.toString());
		log.info("Delete plan request body is--->" + getPlanBody.toString());
		Response deletePlan = request.get(AriaAdminTool);
		System.out.println(deletePlan.asString());
		log.info("Delete plan Response:--->" + planDetails.asString());
		planDetails.then().log().all();
		String statusCode1 = deletePlan.then().extract().path("error_code").toString();
		System.out.println("Status Code is "+statusCode1);
		Assert.assertEquals("0", statusCode1);

	}

//	public static RestAssuredConfig setCertificatesForAuthToken() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException
//	{
//		String password = "U2CEDGE";
//		KeyStore keyStore = KeyStore.getInstance("jks");
//		KeyStore trustStore = KeyStore.getInstance("jks");
//		keyStore.load(new FileInputStream(new File(AgileKeyStoreForAuthToekn)), password.toCharArray());
//		// new FileInputStream (new File ("src/test/resources/certificates/b2b-agilebiller-keystore-sit.jks")),
//		trustStore.load(new FileInputStream(new File(AgileTrustStoreForAuthToeknPresit)), password.toCharArray());
//		// new FileInputStream(new File("src/test/resources/certificates/b2b-agilebiller-truststore-sit.jks")),
//		RestAssuredConfig restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig().keyStore(AgileKeyStoreForAuthToekn, password).trustStore(AgileTrustStoreForAuthToeknPresit, password));
//		// .keyStore("src/test/resources/certificates/b2b-agilebiller-keystore-sit.jks",password)
//		// .trustStore("src/test/resources/certificates/b2b-agilebiller-truststore-sit.jks",password));
//		System.out.println("Certificate Loaded Successfully");
//		return restAssuredConfig;
//	}
	public static RestAssuredConfig setCertificatesForAuthToken() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException
	{
		String password = "U2CEDGE";
		KeyStore keyStore = KeyStore.getInstance("jks");
		TrustStrategy acceptingTrustStrategy = new TrustStrategy()
		{
			@Override
			public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException
			{
				return true;
			}
		};
		keyStore.load(new FileInputStream(new File(AgileKeyStoreForAuthToekn)), password.toCharArray());
		SSLContext sslContext1 = new SSLContextBuilder().useProtocol("TLSv1.2").loadKeyMaterial(keyStore, password.toCharArray()).loadTrustMaterial(null, acceptingTrustStrategy).build();
		@SuppressWarnings("deprecation")
		SSLSocketFactory factory = new SSLSocketFactory(sslContext1, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
		RestAssuredConfig restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig().sslSocketFactory(factory));
		return restAssuredConfig;
	}
	// Start - Setting certificates for this API call

	// private static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException {
	//
	// String password = "U2CEDGE";
	// KeyStore keyStore = KeyStore.getInstance("jks");
	// KeyStore trustStore = KeyStore.getInstance("jks");
	//
	// keyStore.load(
	// new FileInputStream (new File ("src/test/resources/certificates/b2b-agilebiller-keystore-sit.jks")),
	// password.toCharArray());
	//
	// trustStore.load(
	// new FileInputStream(new File("src/test/resources/certificates/b2b-agilebiller-truststore-sit.jks")),
	// password.toCharArray());
	//
	// RestAssuredConfig restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig()
	// .keyStore("src/test/resources/certificates/b2b-agilebiller-keystore-sit.jks",password)
	// .trustStore("src/test/resources/certificates/b2b-agilebiller-truststore-sit.jks",password));
	//
	// return restAssuredConfig;
	//
	// }
	// End - setting the certificates
}
