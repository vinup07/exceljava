package api;

import static apiUtils.ApiUtils.randomAlphaNumeric;
import static apiUtils.GlobalConstants.CancelMROInputfile;
import static apiUtils.GlobalConstants.MroURL;
import static io.restassured.specification.ProxySpecification.host;
import static org.junit.Assert.assertEquals;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;
import java.util.Scanner;
import java.util.TimeZone;
import java.util.UUID;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import apiUtils.ApiUtils;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CancelMRO
{
	static Logger log = Logger.getLogger(CancelMRO.class);

	public static void Cancelmro()
	{
		String correlationId = "";
		correlationId = randomAlphaNumeric(8) + "-" + randomAlphaNumeric(4) + "-" + randomAlphaNumeric(4) + "-" + randomAlphaNumeric(4) + "-" + randomAlphaNumeric(12);
		System.out.println("Correlation Id is " + correlationId);
		try
		{
			String token = AllocateBAN.getToken();
			int statuscode = CancelMro(correlationId, token);
			// System.out.println ("Cor Id : Statuscode" + "-" + correlationId + ":" + statuscode);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
			log.fatal("Modify subscription failed from BDS/ARIA and needs investigation");
			e.printStackTrace();
		}
	}

	public static int CancelMro(String correlationId, String token) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException
	{
		FileReader reader = new FileReader("configs/credentialSetting.properties");
		Properties p = new Properties();
		p.load(reader);
		String decodedPassword = utils.EncryptPassword.decryptPassword(p.getProperty("password"));
		RequestSpecification tokenRequest = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
		tokenRequest.auth().none();
		tokenRequest.header("Content-Type", "application/json");
		String tokenHeader = "Bearer " + token;
		System.out.println(token);
		tokenRequest.header("Authorization", tokenHeader);
		tokenRequest.header("Source-System", "SFDC");
		UUID uuid = UUID.randomUUID();
		tokenRequest.header("Correlation-Id", uuid.toString());
		System.out.println("Correlation Id is " + uuid.toString());
		tokenRequest.header("X-HTTP-Method-Override", "PATCH");
		tokenRequest.config(PostSub.setCertificates());
		// Start - Generating unique Product ID
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("ddMMyyhhmmss");
		String finalUuid = simpleDateFormat.format(new Date());
		System.out.println(finalUuid);
		SimpleDateFormat Effdate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
		Effdate.setTimeZone(TimeZone.getTimeZone("UTC"));
		String Efecdate = Effdate.format(new Date());
		System.out.println(Efecdate);
		int ParCnt = 0;
		ParCnt++;
		String ParentID = "";
		// ParentID = "FN" + "-" + finalUuid + ParCnt;
		ParentID = "FN-1408181117251";
		System.out.println("ParentProductinstanceID Id is " + ParentID);
		// End - Generating unique Product ID
		// Start - Generating unique Recurring charge product instance ID
		int RcCnt = 1;
		RcCnt++;
		String RCParentID = "";
		RCParentID = randomAlphaNumeric(8) + "-" + randomAlphaNumeric(4) + "-" + randomAlphaNumeric(4) + "-" + randomAlphaNumeric(3) + "-" + finalUuid + RcCnt;
		System.out.println("RCProductinstanceID Id is " + RCParentID);
		// End - Generating unique Recurring charge product instance ID
		// Start - Generating unique Non-Recurring charge product instance ID
		int NRCCnt = 2;
		NRCCnt++;
		String NRCParentID = "";
		NRCParentID = randomAlphaNumeric(8) + "-" + randomAlphaNumeric(4) + "-" + randomAlphaNumeric(4) + "-" + randomAlphaNumeric(3) + "-" + finalUuid + NRCCnt;
		System.out.println("NRCProductinstanceID Id is " + NRCParentID);
		// End - Generating unique Non-Recurring charge product instance ID
		// Start - Generating unique Usage charge product instance ID
		int USGCnt = 3;
		USGCnt++;
		// System.out.println(USGCnt);
		String USGParentID = "";
		// USGParentID = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (12);
		USGParentID = randomAlphaNumeric(8) + "-" + randomAlphaNumeric(4) + "-" + randomAlphaNumeric(4) + "-" + randomAlphaNumeric(3) + "-" + finalUuid + USGCnt;
		System.out.println("USGProductinstanceID Id is " + USGParentID);
		// End - Generating unique Usage charge product instance ID
		// Start - Generating Unique service instance ID//
		String RCServiceID = "";
		RCServiceID = randomAlphaNumeric(3) + "-" + finalUuid + RcCnt;
		String NRCServiceID = "";
		NRCServiceID = randomAlphaNumeric(3) + "-" + finalUuid + NRCCnt;
		String USGServiceID = "";
		USGServiceID = randomAlphaNumeric(3) + "-" + finalUuid + USGCnt;
		// End- Generating Unique service instance ID//
		// Start - Reading Json body as a file //
		JSONObject jsonBody = ApiUtils.getJsonFromFile(CancelMROInputfile);
		// End - Reading Json body as a file //
		// Start - Reading billing account created in Allocate BAN from the file
		BufferedReader br = null;
		FileReader fr = null;
		// br = new BufferedReader(new FileReader(FILENAME));
		fr = new FileReader("accountsit.txt");
		br = new BufferedReader(fr);
		String Billact;
		while ((Billact = br.readLine()) != null && !Billact.equals(""))
		{
			System.out.println(Billact);
			break;
		}

		if (br != null)
			br.close();

		if (fr != null)
			fr.close();

		// Read product ID and product instance ID from create Subscription

		File file = new File("ProdInIDSIT.txt");

		Scanner sc = new Scanner(file);

		String ProdID = null;
		int a = 0;
		String Prod_id[] = new String[10];
		// for ( array[a]=1; array[a]<=2; array[a]++){
		while (sc.hasNextLine())
		{
			ProdID = sc.nextLine();
			System.out.println(ProdID);
			Prod_id[a] = ProdID;
			a++;
		}
		sc.close();
		String ParentProd_ID = Prod_id[0];
		String USGParentID1 = Prod_id[1];
		String USGParentID2 = Prod_id[2];
		String RcParentID1 = Prod_id[3];
		String RcParentID2 = Prod_id[4];
		String RcParentID3 = Prod_id[5];
		String RcParentID4 = Prod_id[6];
		String MIAServiceID = Prod_id[7];
		String IMSI = Prod_id[8];
		String Voice = Prod_id[9];

		System.out.println(ParentProd_ID);
		System.out.println(USGParentID1);
		System.out.println(USGParentID2);
		System.out.println(RcParentID1);
		System.out.println(RcParentID2);
		System.out.println(RcParentID3);

		jsonBody.remove("billingAccountNumber");
		jsonBody.put("billingAccountNumber", Long.valueOf(Billact));

		// System.out.println("billingAccountNumber");

		JSONObject Prodoffr = (JSONObject) jsonBody.get("productOffering");
		Prodoffr.remove("productInstanceId");
		Prodoffr.put("productInstanceId", ParentProd_ID);
		
		Prodoffr.remove("offerInstanceId");
		Prodoffr.put("offerInstanceId", ParentProd_ID);

		// System.out.println("Prod Offering : "+ ParentID);

		jsonBody.remove("effectiveDate");
		jsonBody.put("effectiveDate", Efecdate);

		// System.out.println("effectiveDate : "+ Efecdate);

		JSONArray orderitem = new JSONArray();
		JSONArray Billspec = new JSONArray();

		JSONArray array = (JSONArray) jsonBody.get("orderItems");
		JSONObject orderItems = (JSONObject) array.get(0);
		orderItems.remove("effectiveDate");
		orderItems.put("effectiveDate", Efecdate);

		orderItems = (JSONObject) array.get(0);
		JSONArray billingSpecification = (JSONArray) orderItems.get("billingSpecifications");
		JSONObject billingSpecObj = (JSONObject) billingSpecification.get(0);
		billingSpecObj.remove("instanceId");
		billingSpecObj.put("instanceId", USGParentID1);
		System.out.println("Bill1  " + USGParentID1);

		// orderItems = (JSONObject) array.get (1);
		// JSONArray billingSpecification1 = (JSONArray) orderItems.get ("billingSpecifications");
		// JSONObject billingSpecObj1 = (JSONObject) billingSpecification1.get (0);
		// billingSpecObj1.remove ("instanceId");
		// billingSpecObj1.put ("instanceId",USGParentID2);
		// orderItems.remove ("effectiveDate");
		// orderItems.put ("effectiveDate",Efecdate);
		//
		//
		// orderItems = (JSONObject) array.get (2);
		// JSONArray billingSpecification2 = (JSONArray) orderItems.get ("billingSpecifications");
		// JSONObject billingSpecObj2 = (JSONObject) billingSpecification2.get (0);
		// billingSpecObj2.remove ("instanceId");
		// billingSpecObj2.put ("instanceId",RcParentID1);
		// orderItems.remove ("effectiveDate");
		// orderItems.put ("effectiveDate",Efecdate);
		//
		//
		// orderItems = (JSONObject) array.get (3);
		// JSONArray billingSpecification3 = (JSONArray) orderItems.get ("billingSpecifications");
		// JSONObject billingSpecObj3 = (JSONObject) billingSpecification3.get (0);
		// billingSpecObj3.remove ("instanceId");
		// billingSpecObj3.put ("instanceId",RcParentID2);
		// orderItems.remove ("effectiveDate");
		// orderItems.put ("effectiveDate",Efecdate);

		// orderItems = (JSONObject) array.get (4);
		// JSONArray billingSpecification4 = (JSONArray) orderItems.get ("billingSpecifications");
		// JSONObject billingSpecObj4 = (JSONObject) billingSpecification4.get (0);
		// billingSpecObj4.remove ("instanceId");
		// billingSpecObj4.put ("instanceId",RcParentID3);
		// orderItems.remove ("effectiveDate");
		// orderItems.put ("effectiveDate",Efecdate);

		// orderItems = (JSONObject) array.get (5);
		// JSONArray billingSpecification5 = (JSONArray) orderItems.get ("billingSpecifications");
		// JSONObject billingSpecObj5 = (JSONObject) billingSpecification5.get (0);
		// billingSpecObj5.remove ("instanceId");
		// billingSpecObj5.put ("instanceId",NRCParentID);
		// orderItems.remove ("effectiveDate");
		// orderItems.put ("effectiveDate",Efecdate);

		// orderItems = (JSONObject) array.get (6);
		// JSONArray billingSpecification6 = (JSONArray) orderItems.get ("billingSpecifications");
		// JSONObject billingSpecObj6 = (JSONObject) billingSpecification6.get (0);
		// billingSpecObj6.remove ("instanceId");
		// billingSpecObj6.put ("instanceId",NRCParentID);
		// orderItems.remove ("effectiveDate");
		// orderItems.put ("effectiveDate",Efecdate);

		// Start - Building Json body before sending request to API
		//
		// Update dynamic values in the payload

		// jsonBody.remove ("billingAccountNumber");
		// jsonBody.put ("billingAccountNumber",Long.valueOf (Billact));
		//
		//// System.out.println("billingAccountNumber");
		//
		// JSONObject Prodoffr = (JSONObject) jsonBody.get("productOffering");
		// Prodoffr.remove ("productInstanceId");
		// Prodoffr.put ("productInstanceId",ParentProd_ID);
		//
		//// System.out.println("Prod Offering : "+ ParentID);
		//
		// jsonBody.remove ("effectiveDate");
		// jsonBody.put ("effectiveDate",Efecdate);
		//
		//// System.out.println("effectiveDate : "+ Efecdate);
		//
		// JSONArray orderitem = new JSONArray ();
		//
		// JSONArray array = (JSONArray) jsonBody.get ("orderItems");
		// JSONObject orderItems = (JSONObject) array.get (0);
		// orderItems.remove ("effectiveDate");
		// orderItems.put ("effectiveDate",Efecdate);
		//
		// JSONArray services = (JSONArray) orderItems.get ("services");
		//
		// JSONObject service = (JSONObject) services.get (0);
		// service.remove ("serviceId");
		// service.remove ("imsi");
		//
		// service.put ("serviceId",MIASer_id);
		// service.put ("imsi",IMSI_id);
		//
		// JSONArray billingSpecification = (JSONArray) orderItems.get ("billingSpecifications");
		// JSONObject billingSpecObj = (JSONObject) billingSpecification.get (0);
		// billingSpecObj.remove ("instanceId");
		// billingSpecObj.put ("instanceId",RCProd_id);
		//
		// JSONObject billingSpecObj1 = (JSONObject) billingSpecification.get (1);
		// billingSpecObj1.remove ("instanceId");
		// billingSpecObj1.put ("instanceId",USGProd_id);
		//
		// JSONObject billingSpecObj2 = (JSONObject) billingSpecification.get (2);
		// billingSpecObj2.remove ("instanceId");
		// billingSpecObj2.put ("instanceId",NRCParentID);

		// JSONObject billingSpecObj2 = (JSONObject) billingSpecification.get (2);
		// billingSpecObj2.remove ("instanceId");
		// billingSpecObj2.put ("instanceId",NRCParentID);

		// Changes end

		Long Billingno = 0L;
		Billingno = Long.valueOf(Billact);

		tokenRequest.body(jsonBody.toString());
		log.info("Cancel MRO API");
		log.info("Cancel MRO Request:--->" + jsonBody.toString());

		System.out.println(jsonBody.toString());

		// Response tokenResonse = tokenRequest.patch ("https://slot1.org009.t-dev.telstra.net/application/b2b-bds-sit/v2.0/billing-accounts/" + Billingno + "/subscriptions/" + ParentProd_ID);
		Response tokenResponse = tokenRequest.post(MroURL + Billingno + "/subscriptions/" + ParentProd_ID);

		// Assert.assertEquals (tokenResponse.getStatusCode (), 202);
		log.info("Cancel MRO Response:--->" + tokenResponse.asString());
		assertEquals(202, tokenResponse.getStatusCode());

		tokenResponse.then().log().all();

		JsonPath jsonRespBody = tokenResponse.jsonPath();
		log.info("Cancel MRO Response:--->" + tokenResponse.asString());

		int statuscode = jsonRespBody.get("status");
		return statuscode;
	}

}
