package api;

import apiUtils.ApiUtils;
import apiUtils.GlobalConstants;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import static apiUtils.ApiUtils.randomAlphaNumeric;
import static apiUtils.GlobalConstants.*;
import static io.restassured.specification.ProxySpecification.host;
import static org.junit.Assert.assertEquals;

public class CreditAdjustment {

    static Logger log = Logger.getLogger(CreditAdjustment.class);

    public static void PostCreditAdjust() {
        String correlationId = "";
        correlationId = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (12);


        try {
            String token = BillNotify.getNotifyToken ();
            int statuscode = postADJ (correlationId,token);

        }catch (Exception e){
            System.out.println (e.getMessage ());
            log.fatal ("Create BAN failed from BDS and needs investigation");
            e.printStackTrace ();

        }
    }

    public static int postADJ(String correlationId, String token) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
    	Properties p=new Properties();
    	p.load(reader);
    	String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
        RequestSpecification tokenRequest = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
        tokenRequest.auth().none();
        tokenRequest.header("Content-Type", "application/json");
        String tokenHeader = "Bearer " + token;
        System.out.println(token);
        tokenRequest.header("Authorization", tokenHeader);
        tokenRequest.header("Source-System","SFDC");
        UUID uuid = UUID.randomUUID();
        tokenRequest.header("Correlation-Id", uuid.toString());
        System.out.println ("Correlation Id is " + uuid.toString());
        tokenRequest.config(AllocateBAN.setCertificates());


        SimpleDateFormat simpleDateFormat = new SimpleDateFormat ("ddMMyyhhmmss");
        String finalUuid = simpleDateFormat.format (new Date());
        System.out.println (finalUuid);

        int NRCCnt1 = 6;

        String InstanceIDuni = "";
        InstanceIDuni = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (3) + "-" + finalUuid + NRCCnt1;
        System.out.println ("InstanceIDuni Id is " + InstanceIDuni);

        JSONObject jsonBody = ApiUtils.getJsonFromFile(CreditAdjustInputFile);

        BufferedReader br = null;
        FileReader fr = null;

        fr = new FileReader("accountsit.txt");
        br = new BufferedReader(fr);

        String Billact;

        while ((Billact = br.readLine()) != null && !Billact.equals("")){
            System.out.println(Billact);
            break;
        }

        if (br != null)
            br.close();

        if (fr != null)
            fr.close();

        jsonBody.remove ("instanceId");
        jsonBody.put ("instanceId",InstanceIDuni);

        Long Billingno = 0L;
        Billingno = Long.valueOf (Billact);

        tokenRequest.body (jsonBody.toString ());
        System.out.println(" Credit Adjustment Request body is "+ jsonBody);

        Response  tokenResponse = tokenRequest.post (GetAdjustmentURL +Billingno+"/adjustments");

        log.info("Credit Adjustment Response:--->" + tokenResponse.asString ());
        assertEquals(201, tokenResponse.getStatusCode());
        System.out.println(tokenResponse.asString());

        assertEquals(201, tokenResponse.getStatusCode());

        tokenResponse.then().log().all();

        JsonPath jsonRespBody = tokenResponse.jsonPath();

        int statuscode = jsonRespBody.get("status");
        log.info("Credit adjustment Response:--->" + tokenResponse.asString ());
        return statuscode;
    }


}
