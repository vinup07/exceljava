package api;

import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.UUID;


public class InvoiceMult {

    public static void invoicemult() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
        RequestSpecification tokenRequest = new RestAssured ().given ();
        tokenRequest.auth ().none ();
//        tokenRequest.header ("Accept", "application/json");
        tokenRequest.header ("Content-Type", "application/json");
        UUID uuid = UUID.randomUUID();
        tokenRequest.header("CorrelationId", uuid.toString());
        System.out.println ("Correlation Id is " + uuid.toString());
        tokenRequest.config (setCertificates ());

        tokenRequest.config (setCertificates ());

        Response tokenResponse = tokenRequest.get ("https://b2b-agilebiller-sit.np.in.telstra.com.au/invoice/generateInvoiceData/all?customerAccountNumber=700000029574");
        System.out.println (tokenResponse.asString ());
        Assert.assertEquals (tokenResponse.getStatusCode (), 404);

        tokenResponse.then ().log ().all ();
        JsonPath jsonRespBody = tokenResponse.jsonPath ();

    }
//  Start - Setting certificates for this API call

    private static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException {

        String password = "U2CEDGE";
        KeyStore keyStore = KeyStore.getInstance("jks");
        KeyStore trustStore = KeyStore.getInstance("jks");

        keyStore.load(
                new FileInputStream (new File ("src/test/resources/certificates/b2b-agilebiller-keystore-sit.jks")),
                password.toCharArray());

        trustStore.load(
                new FileInputStream(new File("src/test/resources/certificates/b2b-agilebiller-truststore-sit.jks")),
                password.toCharArray());

        RestAssuredConfig restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig()
                .keyStore("src/test/resources/certificates/b2b-agilebiller-keystore-sit.jks",password)
                .trustStore("src/test/resources/certificates/b2b-agilebiller-truststore-sit.jks",password));

        return restAssuredConfig;

    }
    // End - setting the certificates

}
