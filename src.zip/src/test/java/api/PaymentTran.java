package api;

import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.log4j.Logger;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import java.io.*;
import java.util.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.Scanner;
import java.util.UUID;

import static apiUtils.GlobalConstants.PaymentRetrievalURL;
import static io.restassured.specification.ProxySpecification.host;

public class PaymentTran {


    static Logger log = Logger.getLogger(PaymentStrEnddt.class);

    public static void Paymenttran() {
        try {
            String token = AllocateBAN.getToken ();
            int statuscode = PaymentTranID (token);
        }catch (Exception e){
            System.out.println (e.getMessage ());
            log.fatal ("Payment Retrieval from ARIA via BDS failed and needs investigation");
            e.printStackTrace ();
        }
    }

    public static int PaymentTranID(String token) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
    	Properties p=new Properties();
    	p.load(reader);
    	String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
        RequestSpecification tokenRequest = new RestAssured ().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth("d898452", decodedPassword));
        tokenRequest.auth().none();
        tokenRequest.header("Content-Type", "application/json");
        String tokenHeader = "Bearer " + token;
        tokenRequest.header("Authorization", tokenHeader);
        UUID uuid = UUID.randomUUID();
        tokenRequest.header("Correlation-Id", uuid.toString());
        tokenRequest.header("Source-System", "TConnect");
        tokenRequest.config(AllocateBAN.setCertificates());

        log.info("T-Connect to invoke Payment retreival API from ARIA via BDS");
//        log.info("Payment Retrieval Request:--->" + jsonBody.toString ());

        File file = new File ("payinput.txt");

        Scanner sc = new Scanner (file);

        String Input = null;
        int a=0;
        String Pay_id[] = new String [5];
        //  for ( array[a]=1; array[a]<=2; array[a]++){
        while (sc.hasNextLine ()) {
            Input = sc.nextLine ();
            System.out.println (Input);
            Pay_id[a] =  Input;
            a++;
        }
        sc.close ();
        String Billing_no =  Pay_id[0];
        String Invoice_no =  Pay_id[1];
//        String Start_date =  Pay_id[2];
//        String End_date   =  Pay_id[3];
        String Tran_ID    =  Pay_id[2];

        System.out.println(Billing_no);
//        System.out.println(Start_date);
//        System.out.println(End_date);
        System.out.println(Tran_ID);

        Response tokenResponse = tokenRequest.get (PaymentRetrievalURL+Billing_no +"/payments?transactionId="+Tran_ID);
        Assert.assertEquals(200,tokenResponse.getStatusCode());
       

        tokenResponse.then().log().all();

        JsonPath jsonRespBody = tokenResponse.jsonPath();
        log.info("Payment Retrieval Response:--->" + tokenResponse.asString ());
        int statuscode = jsonRespBody.get("status");
        return statuscode;
    }

    // Start- Setting up the certificates to invoke API
//    private static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException {
//
//        String password = "secret";
//
//        KeyStore keyStore = KeyStore.getInstance("jks");
//        KeyStore trustStore = KeyStore.getInstance("jks");
//
//        keyStore.load(
//                new FileInputStream (new File ("src/test/resources/certificates/keystore.jks")),
//                password.toCharArray());
//
//        trustStore.load(
//                new FileInputStream(new File("src/test/resources/certificates/okapi.jks")),
//                password.toCharArray());
//
//        RestAssuredConfig restAssuredConfig = null;
//
//        restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig()
//                .keyStore("src/test/resources/certificates/keystore.jks", password).
//                        trustStore("src/test/resources/certificates/okapi.jks", password));
//
//
//
//        restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig()
//                .trustStore(trustStore).trustStoreType("JKS")
//                .keyStore(new File("src/test/resources/certificates/keystore.jks"), password).keystoreType("JKS").and().allowAllHostnames());
//        // restAssuredConfig.getSSLConfig().allowAllHostnames();
//
//        if (null == restAssuredConfig) {
//            System.out.println("Certificate not Set");
//        }
//        return restAssuredConfig;
//    }

    // End- Setting up the certificates to invoke API


}
