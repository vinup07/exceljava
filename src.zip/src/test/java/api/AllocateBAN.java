package api;

import static apiUtils.ApiUtils.randomAlphaNumeric;
import static apiUtils.GlobalConstants.AllocateBANInputFile;
import static apiUtils.GlobalConstants.AllocateBan;
import static apiUtils.GlobalConstants.BillingKeyStore;
import static apiUtils.GlobalConstants.BillingTrustStore;
import static apiUtils.GlobalConstants.Okapi;
import static io.restassured.specification.ProxySpecification.host;
import static org.junit.Assert.assertEquals;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.UUID;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.junit.Ignore;
import org.junit.Test;
import apiUtils.ApiUtils;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class AllocateBAN
{
	static int num = 10, count = 1;
	static Logger log = Logger.getLogger(AllocateBAN.class);
	static String workingDir = System.getProperty("user.dir");

	// public static boolean getAllocateBan() {
	public static void getAllocateBan()
	{

		long billingAccountNo = 0;
		String correlationId = "";
		correlationId = randomAlphaNumeric(8) + "-" + randomAlphaNumeric(4) + "-" + randomAlphaNumeric(4) + "-" + randomAlphaNumeric(4) + "-" + randomAlphaNumeric(12);
		// System.out.println ("Correlation Id is " + correlationId);
		try
		{
			String token = getToken();
			System.out.println("token is :" + token);
			billingAccountNo = allocateBan(correlationId, token);
			System.out.println("BAN: " + billingAccountNo);
		}
		catch (Exception e)
		{
			System.out.println(e.getMessage());
			log.fatal("Allocate BAN failed from BDS and needs investigation");
			e.printStackTrace();
		}
	}

//	@Ignore
	@Test
	public void getTokenTest()
	{
		try
		{
			log.info("Received Token : " + getToken());
		}
		catch (Exception e)
		{
			log.error("Error in Getting Token");
		}
	}

	public static String getToken() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException
	{
		FileReader reader = new FileReader("configs/credentialSetting.properties");
		Properties p = new Properties();
		p.load(reader);
		String decodedPassword = utils.EncryptPassword.decryptPassword(p.getProperty("password"));
		RequestSpecification tokenRequest = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth("d392864", "@Vyas0227"));
		log.warn("Invoked Okapi URL by passing proxy credentials");
		RestAssured.useRelaxedHTTPSValidation();
		tokenRequest.relaxedHTTPSValidation();
		tokenRequest.auth().none();
		log.info("Retrieve token from Okapi to authorize the transaction");
		tokenRequest.header("Content-Type", "application/x-www-form-urlencoded");
//		tokenRequest.config(setCertificates());
		tokenRequest.config(setCertificates());
		String bodyToken = "clie" + "nt_id=8Yzs3QHLZujf0NdbU597vzqAmyjA1jIV&client_secret=qAEzcZK71vAmtG2o&grant_type=client_credentials";
		tokenRequest.body(bodyToken);
		Response tokenResponse = tokenRequest.post(Okapi);
		System.out.println("Status Code is " + tokenResponse.statusCode());
		System.out.println(tokenResponse.asString());
		tokenResponse.then().log().all();
		JsonPath jsonRespBody = tokenResponse.jsonPath();
		String bdsToken = "";
		bdsToken = jsonRespBody.get("access_token");
		System.out.println("Generated Token : " + bdsToken);
		assertEquals(200, tokenResponse.getStatusCode());
		log.info("Token Response:--->" + tokenResponse.asString());
		if (bdsToken == null)
		{
			while (count <= num)
			{
				count++;
				System.out.println("Count of the loop is : " + count);
				log.fatal("Failed to fetch Okapi token for the first time and retry for 10 times");
				log.error("Okapi token failed due to timeout or endpoint issue");
				getToken();
			}
		}
		return bdsToken;
	}

	public static long allocateBan(String correlationId, String token) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException
	{
		FileReader reader = new FileReader("configs/credentialSetting.properties");
		Properties p = new Properties();
		p.load(reader);
		String decodedPassword = utils.EncryptPassword.decryptPassword(p.getProperty("password"));
		RequestSpecification tokenRequest = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
		tokenRequest.auth().none();
		tokenRequest.header("Content-Type", "application/json");
		String tokenHeader = "Bearer " + token;
		tokenRequest.header("Authorization", tokenHeader);
		tokenRequest.config(setCertificates());
		// JSONObject jsonBody = ApiUtils.getJsonFromFile ( "/src/test/resources/payloads/allocateBan.json");
		JSONObject jsonBody = ApiUtils.getJsonFromFile(AllocateBANInputFile);
		UUID uuid = UUID.randomUUID();
		jsonBody.put("correlationId", uuid.toString());
		System.out.println("Correlation Id is " + uuid.toString());
		// System.out.println("from modified file" + jsonBody.toString());
		tokenRequest.body(jsonBody.toString());
		log.info("Invoke Allocate Billing account number API");
		log.info("Allocate BAN Request:--->" + jsonBody.toString());

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Calendar c = Calendar.getInstance();
		c.setTime(new Date()); // Now use today date.
		c.add(Calendar.DATE, 5); // Adding 5 days
		String output = sdf.format(c.getTime());
		System.out.println(output);

		// Response tokenResponse = tokenRequest.post ("https://slot1.org009.t-dev.telstra.net/application/b2b-bds-sit/v2.1/billing-accounts/allocate-ban");

		Response tokenResponse = tokenRequest.post(AllocateBan);
		System.out.println(tokenResponse.asString());
		assertEquals(201,tokenResponse.getStatusCode());
		tokenResponse.then().log().all();
		JsonPath jsonRespBody = tokenResponse.jsonPath();

		String FILENAME = "accountsit.txt";
		BufferedWriter bw = null;
		FileWriter fw = null;
		// long billing = jsonRespBody.get ("billingAccountNumber");
		// System.out.println("acc" + billing);
		String content = jsonRespBody.get("billingAccountNumber").toString();
		// String content = jsonRespBody.get ("billingAccountNumber");

		fw = new FileWriter(FILENAME);
		bw = new BufferedWriter(fw);
		bw.write(content);
		if (bw != null)
			bw.close();

		if (fw != null)
			fw.close();

		long billingAcNo = 0;
		billingAcNo = jsonRespBody.get("billingAccountNumber");
		log.info("Allocate BAN Response:--->" + tokenResponse.asString());
		return billingAcNo;
	}

	// Start - setting the certificates
//	public static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException
//	{
//		String password = "U2CEDGE";
//		KeyStore keyStore = KeyStore.getInstance("jks");
//		KeyStore trustStore = KeyStore.getInstance("jks");
//		RestAssuredConfig restAssuredConfig = null;
//		restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig().trustStore(new File(BillingTrustStore), password).trustStoreType("JKS").keyStore(new File(BillingKeyStore), password).keystoreType("JKS").and().allowAllHostnames());
//		if (null == restAssuredConfig)
//		{
//			System.out.println("Certificate not Set");
//			log.fatal("certificates not set successfully and needs investigation ");
//		}
//		return restAssuredConfig;
//		// End - setting the certificates
//	}
	
	public static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException
	{
		String password = "U2CEDGE";
		KeyStore keyStore = KeyStore.getInstance("jks");
		TrustStrategy acceptingTrustStrategy = new TrustStrategy()
		{
			@Override
			public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException
			{
				return true;
			}
		};
		keyStore.load(new FileInputStream(BillingKeyStore), password.toCharArray());
		SSLContext sslContext1 = new SSLContextBuilder().useProtocol("TLSv1.2").loadKeyMaterial(keyStore, password.toCharArray()).loadTrustMaterial(null, acceptingTrustStrategy).build();
		@SuppressWarnings("deprecation")
		SSLSocketFactory factory = new SSLSocketFactory(sslContext1, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
		RestAssuredConfig restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig().sslSocketFactory(factory));
		return restAssuredConfig;

	}
	
	
}
