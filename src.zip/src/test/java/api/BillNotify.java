package api;

import apiUtils.ApiUtils;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.logging.Log;
import org.apache.http.ssl.TrustStrategy;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;

import javax.net.ssl.SSLContext;

import java.io.*;
import java.util.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;
import static apiUtils.ApiUtils.randomAlphaNumeric;
import static apiUtils.GlobalConstants.*;
import static io.restassured.specification.ProxySpecification.host;

public class BillNotify {

    //    private static Logger Log = Logger.getLogger(org.apache.commons.logging.Log.class.getName())
    static int num = 10, count = 1;
    static Logger log = Logger.getLogger(BillNotify.class);

    public static void PostNotifyBill() {
        String correlationId = "";
        correlationId = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (12);
        //System.out.println ("Correlation Id is " + correlationId);

        try {
            String token = getNotifyToken ();
            int statuscode = NotifyBill (correlationId,token);
            // System.out.println ("Cor Id : Statuscode" + "-" + correlationId + ":" + statuscode);
        }catch (Exception e){
            System.out.println (e.getMessage ());
            log.fatal ("Bill-Notify failed from BDS and needs investigation");
            e.printStackTrace ();

        }
    }

    public static int NotifyBill(String correlationId, String token) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
    	Properties p=new Properties();
    	p.load(reader);
    	String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
        RequestSpecification tokenRequest = new RestAssured ().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth(p.getProperty("userName"), decodedPassword));
        tokenRequest.auth().none();
        tokenRequest.header("Content-Type", "application/json");
        String tokenHeader = "Bearer " + token;
        System.out.println(token);
        tokenRequest.header("Authorization", tokenHeader);
        tokenRequest.header("Source-System","Agile-biller");
        UUID uuid = UUID.randomUUID();
        tokenRequest.header("Correlation-Id", uuid.toString());
        System.out.println ("Correlation Id is " + uuid.toString());
        tokenRequest.config(setCertificates());

        JSONObject jsonBody = ApiUtils.getJsonFromFile(BillNotifyinputFile);

        Date curDate = new Date();
//
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String Billdate = format.format(curDate);
        System.out.println(Billdate);

        SimpleDateFormat sdf = new SimpleDateFormat ("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date ()); // Now use today date.
        c.add(Calendar.DATE, 30); // Adding 30 days
        String billEnddate = sdf.format(c.getTime());
        System.out.println(c);
        System.out.println(billEnddate);

        SimpleDateFormat sdfd = new SimpleDateFormat ("yyyy-MM-dd");
        Calendar d = Calendar.getInstance();
        d.setTime(new Date ()); // Now use today date.
        d.add(Calendar.DATE, 45); // Adding 45 days
        String duedte = sdf.format(d.getTime());
        System.out.println(d);
        System.out.println(duedte);

        // Start - Update the Json body elements

        JSONObject eventDetails = (JSONObject) jsonBody.get("eventDetails");
        eventDetails.remove ("billIssueDate");
        eventDetails.remove ("billPeriodStartDate");
        eventDetails.remove ("billPeriodEndDate");
        eventDetails.remove ("dueDate");

//        System.out.println("  billIssueDate is "+ jsonBody);
        eventDetails.put ("billIssueDate",Billdate);
        eventDetails.put ("billPeriodStartDate",Billdate);
        eventDetails.put ("billPeriodEndDate",billEnddate);
        eventDetails.put ("dueDate",duedte);

        tokenRequest.body(jsonBody.toString());

        log.info("Invoke Billing Notification API from BDS");
        log.info("Bill Notification Payload:--->" + jsonBody.toString ());

        System.out.println(jsonBody.toString());
        Response tokenResponse = tokenRequest.post(NotifyBill);

        Assert.assertEquals(202 , tokenResponse.getStatusCode());

        tokenResponse.then().log().all();

        JsonPath jsonRespBody = tokenResponse.jsonPath();

        int statuscode = jsonRespBody.get("status");
        log.info("Create BAN Response:--->" + tokenResponse.asString ());
        return statuscode;
    }

    // Start- Setting up the certificates to invoke API
    public static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException {

    	String password = "U2CEDGE";
		KeyStore keyStore = KeyStore.getInstance("jks");
		TrustStrategy acceptingTrustStrategy = new TrustStrategy()
		{
			@Override
			public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException
			{
				return true;
			}
		};
		keyStore.load(new FileInputStream(BillingKeyStore), password.toCharArray());
		SSLContext sslContext1 = new SSLContextBuilder().useProtocol("TLSv1.2").loadKeyMaterial(keyStore, password.toCharArray()).loadTrustMaterial(null, acceptingTrustStrategy).build();
		@SuppressWarnings("deprecation")
		SSLSocketFactory factory = new SSLSocketFactory(sslContext1, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
		RestAssuredConfig restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig().sslSocketFactory(factory));
		return restAssuredConfig;
    	
    }

    // End- Setting up the certificates to invoke API

    public static String getNotifyToken() throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException {
    	FileReader reader=new FileReader("configs/credentialSetting.properties");  
    	Properties p=new Properties();
    	p.load(reader);
    	String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
        RequestSpecification tokenRequest = new RestAssured ().given ().proxy (host ("bcavi.tcif.telstra.com.au").withPort (8080).withAuth (p.getProperty("userName"),decodedPassword));
        log.warn("Invoked Okapi URL by passing proxy credentials");
        RestAssured.useRelaxedHTTPSValidation ();
        tokenRequest.relaxedHTTPSValidation ();
        tokenRequest.auth ().none ();

        log.info("Retrieve token from Okapi to authorize the transaction");

        tokenRequest.header ("Content-Type", "application/x-www-form-urlencoded");

        tokenRequest.config (setCertificates ());

        String bodyToken = "clie" +
                "nt_id=V2hLcILHg6Dn4IAPb17BcZ5PSZI6gZ49&client_secret=Bkzd2CwG81bcNMN4&grant_type=client_credentials";

        tokenRequest.body (bodyToken);
        //Response tokenResponse = tokenRequest.post("https://slot1.org009.t-dev.telstra.net/v2/oauth/token");
        Response tokenResponse = tokenRequest.post (Okapi);

        System.out.println (tokenResponse.asString ());

        tokenResponse.then ().log ().all ();
        JsonPath jsonRespBody = tokenResponse.jsonPath ();

        String notifyToken = "";
        notifyToken = jsonRespBody.get ("access_token");

        System.out.println ("Generated Token : " + notifyToken);

        Assert.assertEquals (tokenResponse.getStatusCode (), 200);

        log.info("Token Response:--->" + tokenResponse.asString ());

        if (notifyToken == null) {

            while (count <= num) {
                count++;
                System.out.println ("Count of the loop is : " + count);
                log.fatal ("Failed to fetch Okapi token for the first time and retry for 10 times");
                log.error("Okapi token failed due to timeout or endpoint issue");
                getNotifyToken ();
            }
        }
        return notifyToken;
    }
}
