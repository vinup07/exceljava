package api;

import apiUtils.ApiUtils;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.config.SSLConfig;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;

import javax.net.ssl.SSLContext;

import java.util.*;
import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;

import static apiUtils.ApiUtils.randomAlphaNumeric;
import static apiUtils.GlobalConstants.*;
import static io.restassured.specification.ProxySpecification.host;
import static org.junit.Assert.assertEquals;

//import org.testng.Assert;

public class NgucUpgrade {

    static Logger log = Logger.getLogger(NgucUpgrade.class);
    public static void NgucUpgrade() {
        String correlationId = "";
        correlationId = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (12);
        System.out.println ("Correlation Id is " + correlationId);
        try {
            String token = AllocateBAN.getToken ();
            int statuscode = Ngucupgrade(correlationId,token);
            //System.out.println ("Cor Id : Statuscode" + "-" + correlationId + ":" + statuscode);
        }catch (Exception e) {
            System.out.println (e.getMessage ());
            log.fatal ("Post subscription failed from BDS/ARIA and needs investigation");
            e.printStackTrace ();

        }}

        public static int Ngucupgrade (String correlationId, String token) throws CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException {
        FileReader reader=new FileReader("configs/credentialSetting.properties");  
        Properties p=new Properties();
        p.load(reader);
        String decodedPassword = utils.EncryptPassword.decryptPassword (p.getProperty("password"));
        RequestSpecification tokenRequest = new RestAssured().given().proxy(host("bcavi.tcif.telstra.com.au").withPort(8080).withAuth("d318101", decodedPassword));
        tokenRequest.auth().none();
        tokenRequest.header ("Content-Type", "application/json");
        String tokenHeader = "Bearer " + token;
        System.out.println (token);
        tokenRequest.header ("Authorization", tokenHeader);
        tokenRequest.header("Source-System","SFDC");
        UUID uuid = UUID.randomUUID();
        tokenRequest.header("Correlation-Id", uuid.toString());
        System.out.println ("Correlation Id is " + uuid.toString());
        tokenRequest.config (setCertificates ());

        // Start - Generating unique  Product ID

         SimpleDateFormat simpleDateFormat = new SimpleDateFormat ("ddMMyyhhmmss");
         String finalUuid = simpleDateFormat.format (new Date ());
         System.out.println (finalUuid);

         SimpleDateFormat Effdate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.US);
         System.out.println (" Effecdate : " + Effdate);

         Effdate.setTimeZone (TimeZone.getTimeZone ("UTC"));
         String Efecdate = Effdate.format (new Date ());
         System.out.println (" Effecdate : " + Efecdate);

        int ParCnt = 0;
//        ParCnt++;

        String ParentID = "";
        ParentID = "FN" + "-" + finalUuid + ParCnt;
        System.out.println ("ParentProductinstanceID Id is " + ParentID);

        // End - Generating unique  Product ID

        // Start - Generating unique Recurring charge product instance ID

        int usCnt1 = 1;
//        usCnt1++;

        String USGParentID1 = "";
        USGParentID1 = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (3) + "-" + finalUuid + usCnt1;
        System.out.println ("USGParentID1 Id is " + USGParentID1);


        int usCnt2 = 2;
//        usCnt2++;

        String USGParentID2 = "";
        USGParentID2 = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (3) + "-" + finalUuid + usCnt2;
        System.out.println ("USGParentID2 Id is " + USGParentID2);


        int RCCnt1 = 3;
//        RCCnt1++;

        String RcParentID1 = "";
        RcParentID1 = randomAlphaNumeric (8) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (4) + "-" + randomAlphaNumeric (3) + "-" + finalUuid + RCCnt1;
        System.out.println ("RcParentID1 Id is " + RcParentID1);


        //  Start - Reading Json body as a  file  //
        JSONObject jsonBody = ApiUtils.getJsonFromFile(NgucIndSubsfile);
        //  End - Reading Json body as a  file  //

        // Start - Reading billing account created in Allocate BAN from the file

        BufferedReader br = null;
        FileReader fr = null;

        //br = new BufferedReader(new FileReader(FILENAME));
        fr = new FileReader ("accountsit.txt");
        br = new BufferedReader (fr);

        String Billact;

        while ((Billact = br.readLine ()) != null && !Billact.equals ("")) {
            System.out.println (Billact);
            break;
        }

        if (br != null)
            br.close ();

        if (fr != null)
            fr.close ();

            String s1=Billact;
            String Billaccount = s1.substring(8,12);
            System.out.println(Billaccount);//returns vatpoint

            // Start - Generating Unique service instance ID//

            int Mobc = 6148998;

            String MIAServiceID = "";
            MIAServiceID = Mobc + Billaccount;

            int Imsitemp = 89999998;
            String IMSI = "";
            IMSI = Imsitemp  +  Billaccount;

            int Voiceid = 6179998;
            String Voice = "";
            Voice = Voiceid + Billaccount;

           // Start - Write Parent and RC Product Instance ID to File
//
            FileWriter fw = new FileWriter("ProdInIDSIT.txt");
            PrintWriter pw = new PrintWriter(fw, true);

            pw.println(ParentID);
            pw.println(USGParentID1);
            pw.println(USGParentID2);
//            pw.println(RcParentID1);
//            pw.println(RcParentID2);
//            pw.println(RcParentID3);
//            pw.println(NRCParentID1);
//            pw.println(MIAServiceID);
//            pw.println  (IMSI);
//            pw.print(Voice);
            fw.close();

            // End - Write Parent and RC Product Instance ID to File
            // End  - Reading Payload from file

//          Start - Building Json body before sending request to API

//          Update dynamic values in the payload
//
            jsonBody.remove ("billingAccountNumber");
            jsonBody.put ("billingAccountNumber",Long.valueOf (Billact));

//          System.out.println("billingAccountNumber");

            JSONObject Prodoffr = (JSONObject) jsonBody.get("productOffering");
            Prodoffr.remove ("productInstanceId");
            Prodoffr.put ("productInstanceId",ParentID);
            
 //         System.out.println("Prod Offering : "+ ParentID);

            jsonBody.remove ("effectiveDate");
            jsonBody.put ("effectiveDate",Efecdate);

//            System.out.println("effectiveDate : "+ Efecdate);

            JSONArray orderitem = new JSONArray ();
            JSONArray Billspec = new JSONArray ();

            JSONArray array = (JSONArray) jsonBody.get ("orderItems");
            JSONObject orderItems = (JSONObject) array.get (0);
            orderItems.remove ("effectiveDate");
            orderItems.put ("effectiveDate",Efecdate);
         
            orderItems = (JSONObject) array.get (0);
            JSONArray billingSpecification = (JSONArray) orderItems.get ("billingSpecifications");
            JSONObject billingSpecObj = (JSONObject) billingSpecification.get (0);
            billingSpecObj.remove ("instanceId");
            billingSpecObj.put ("instanceId",USGParentID1);
            
            orderItems = (JSONObject) array.get (1);
            JSONArray billingSpecification1 = (JSONArray) orderItems.get ("billingSpecifications");
            JSONObject billingSpecObj1 = (JSONObject) billingSpecification1.get (0);
            billingSpecObj1.remove ("instanceId");
            billingSpecObj1.put ("instanceId",USGParentID2);


            orderItems = (JSONObject) array.get (2);
            JSONArray billingSpecification2 = (JSONArray) orderItems.get ("billingSpecifications");
            JSONObject billingSpecObj2 = (JSONObject) billingSpecification2.get (0);
            billingSpecObj2.remove ("instanceId");
            billingSpecObj2.put ("instanceId",RcParentID1);
            
            orderItems = (JSONObject) array.get (2);
            JSONArray billingSpecification3 = (JSONArray) orderItems.get ("billingSpecifications");
            JSONObject billingSpecObj3 = (JSONObject) billingSpecification3.get (1);
            billingSpecObj3.remove ("instanceId");
            billingSpecObj3.put ("instanceId",RcParentID1);
            orderItems.remove ("effectiveDate");
            orderItems.put ("effectiveDate",Efecdate);


            System.out.println("Billing specifications :  "+billingSpecification.get (0).toString ());

//        New changes  - END


        // End - Building Json body before sending request to API

        Long Billingno = 0L;
        Billingno = Long.valueOf (Billact);

        tokenRequest.body (jsonBody.toString ());
        log.info("Invoke NGUC Upgrade API");
        log.info("NGUC Upgrade Request:--->" + jsonBody.toString ());

        System.out.println (jsonBody.toString ());
//       Response tokenResponse = tokenRequest.post (ViewBanURL + Billingno + "subscriptions");
         Response tokenResponse = tokenRequest.post (NgucIndSubsURL+Billingno+"/subscriptions");

//      Assert.assertEquals(tokenResponse.getStatusCode(), 202);
        log.info("NGUC Upgrade Response:--->" + tokenResponse.asString ());
        assertEquals(202, tokenResponse.getStatusCode());
        tokenResponse.then ().log ().all ();
        JsonPath jsonRespBody = tokenResponse.jsonPath ();
        int statuscode = jsonRespBody.get ("status");
        return statuscode;
    }

    public static RestAssuredConfig setCertificates() throws NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, KeyStoreException, KeyManagementException, UnrecoverableKeyException {

    	String password = "U2CEDGE";
		KeyStore keyStore = KeyStore.getInstance("jks");
		TrustStrategy acceptingTrustStrategy = new TrustStrategy()
		{
			@Override
			public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException
			{
				return true;
			}
		};
		keyStore.load(new FileInputStream(BillingKeyStore), password.toCharArray());
		SSLContext sslContext1 = new SSLContextBuilder().useProtocol("TLSv1.2").loadKeyMaterial(keyStore, password.toCharArray()).loadTrustMaterial(null, acceptingTrustStrategy).build();
		@SuppressWarnings("deprecation")
		SSLSocketFactory factory = new SSLSocketFactory(sslContext1, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
		RestAssuredConfig restAssuredConfig = RestAssured.config().sslConfig(SSLConfig.sslConfig().sslSocketFactory(factory));
		return restAssuredConfig;
		
    }
    }

