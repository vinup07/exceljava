package yaml;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

public class YamlReader {

    static APIPayload payload;

    public YamlReader() throws IOException {
       init();
    }

    public void init() throws IOException {
        InputStream file = this.getClass().getClassLoader().getResourceAsStream("properties.yml");
        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
        payload = mapper.readValue(file, APIPayload.class);
        // System.out.println("Payload" +payload);

    }
    public static String getName(String name) {
        // You can access a specific API by it's name like this
        APIEntry apiEntry1 = payload.getApiEntries().stream()
                .filter(api -> name.equals(api.getName()))
                .findFirst()
                .orElse(null);
        // You can use it's methods like this - relative the created class

        return apiEntry1.getName();
    }
    public static String getEndPoint(String name) {
        // You can access a specific API by it's name like this
        APIEntry apiEntry1 = payload.getApiEntries().stream()
                .filter(api -> name.equals(api.getName()))
                .findFirst()
                .orElse(null);
        // You can use it's methods like this - relative the created class

        return apiEntry1.getEndpoint();
    }
    public static Map<String, String> getCrets(String name) {
        APIEntry apiEntry1 = payload.getApiEntries().stream()
                .filter(api -> name.equals(api.getName()))
                .findFirst()
                .orElse(null);
        Map<String, String> apiCerts = payload.getApiEntries().get(payload.getApiEntries().indexOf(apiEntry1)).getCerts();
        return apiCerts;
    }
    public static Map<String, String> getHeaders(String name) {
        APIEntry apiEntry1 = payload.getApiEntries().stream()
                .filter(api -> name.equals(api.getName()))
                .findFirst()
                .orElse(null);
        Map<String, String> api1Headers = payload.getApiEntries().get(payload.getApiEntries().indexOf(apiEntry1)).getHeaders();
        return api1Headers;
    }
    public static String getPayload(String name) {
        // You can access a specific API by it's name like this
        APIEntry apiEntry1 = payload.getApiEntries().stream()
                .filter(api -> name.equals(api.getName()))
                .findFirst()
                .orElse(null);
        // You can use it's methods like this - relative the created class

        return apiEntry1.getPayload();
    }
}
