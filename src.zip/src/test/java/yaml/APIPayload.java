package yaml;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;

public class APIPayload {
    //    You can put this annotation on top of a field declaration to change the name that will be mapped in the YAML
    @JsonProperty("api")
    List<APIEntry> apiEntries;

    public List<APIEntry> getApiEntries() {
        return apiEntries;
    }

    public void setApiEntries(List<APIEntry> apiEntries) {
        this.apiEntries = apiEntries;
    }

}
