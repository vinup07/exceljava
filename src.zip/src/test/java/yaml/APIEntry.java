package yaml;

import java.util.Map;

public class APIEntry {

    String name;
    String endpoint;
    Map<String, String> certs;
    Map<String, String> headers;
    String payload;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public Map<String, String> getCerts() {
        return certs;
    }

    public void setCerts(Map<String, String> certs) {
        this.certs = certs;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public void setHeaders(Map<String, String> headers) {
        this.headers = headers;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }
}
