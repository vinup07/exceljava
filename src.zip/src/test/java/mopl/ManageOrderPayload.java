package mopl;

import io.restassured.path.json.JsonPath;
import org.json.simple.JSONArray;
import org.junit.Test;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

//import static org.testng.AssertJUnit.assertEquals;

public class ManageOrderPayload {
    ArrayList<String> listOfProductsPL1 = new ArrayList<String>();
    HashMap<String,String> mapofProductsPL1 = new HashMap<String,String>();

    public int countOfLineOrderItems(String path) {

//        File jsonMopl = new File(System.getProperty("user.dir"),"src/test/resources/mopl.json");
        File jsonMopl = new File(path);

        JsonPath jsonPath = new JsonPath(jsonMopl);
        ArrayList ret = jsonPath.get("orderItem");
        System.out.println("Count " + ret.size());
        return ret.size();
    }
    @Test
    public void test(){
        createAMapOfProductSpecAndPath();
        viewIndexOfProducts();
        viewMap();
    }
    public void createAMapOfProductSpecAndPath(){
        String path = System.getProperty("user.dir") + "/src/test/resources/mopl.json";
        int noOfProducts = countOfLineOrderItems(path);

        File jsonMopl = new File(path);

        JsonPath jsonPath = new JsonPath(jsonMopl);

        System.out.println("Product Spec Code : Path");
        for(int i=0;i<noOfProducts;i++){
            String productSpecCodePath = "orderItem[" + i + "].product.productSpecification.code";
//            String productSpecCode = jsonPath.get("orderItem[0].product.productSpecification.code");
            String productSpecCode = jsonPath.get(productSpecCodePath);
            listOfProductsPL1.add(productSpecCode);
            mapofProductsPL1.put(productSpecCode,productSpecCodePath);
            System.out.println(productSpecCode + " : " + productSpecCodePath);
        }
    }

    public void viewIndexOfProducts(){
        System.out.println("Index : Product");
        for(int i=0;i < listOfProductsPL1.size();i++){
            System.out.println(i + " : " + listOfProductsPL1.get(i));
        }
    }

    public  void viewMap(){
        System.out.println("Key(Product Spec) : Value (Path in MOPL)");
        for (Map.Entry<String, String> entry : mapofProductsPL1.entrySet()) {
            System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
        }
    }
}
