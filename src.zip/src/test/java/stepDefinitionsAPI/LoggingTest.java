package stepDefinitionsAPI;

import org.apache.log4j.Logger;

public class LoggingTest {
    static Logger log = Logger.getLogger(LoggingTest.class);
    //@Test
     public void testLogger(){
        log.info("Start Login");
        log.warn("Sign in not found");
        log.error("Unable to Login");
        log.fatal("Web Element Not found");
        log.debug("Addtional Buttion Found");
    }
}
