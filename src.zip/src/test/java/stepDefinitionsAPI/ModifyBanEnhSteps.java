package stepDefinitionsAPI;

import api.ModifyBAN;
import api.ViewBAN;
import cucumber.api.java.en.*;

public class ModifyBanEnhSteps {

    @Given("^Logon to salesforce and navigate to billing account to modify account details$")
    public void logon_to_salesforce_and_navigate_to_billing_account_to_modify_account_details() throws Throwable {

    }

    @When("^I click on save after populating updated fields under billing account creation page$")
    public void i_click_on_save_after_populating_updated_fields_under_billing_account_creation_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        //Invoke API
        ModifyBAN.PostModifyBan ();

    }

    @Then("^billing account details will be Modified in ARIA and response will be returned to Salesforce$")
    public void billing_account_details_will_be_Modified_in_ARIA_and_response_will_be_returned_to_Salesforce() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @Given("^Logon to salesforce and navigate to billing account tab under account page to view modified address$")
    public void logon_to_salesforce_and_navigate_to_billing_account_tab_under_account_page_to_view_modified_address() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @When("^I click on edit button on billing account$")
    public void i_click_on_edit_button_on_billing_account() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^billing account details will be retrieved from ARIA to Salesforce$")
    public void billing_account_details_will_be_retrieved_from_ARIA_to_Salesforce() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        ViewBAN.ViewBillingAccount ();
    }

}
