package stepDefinitionsAPI;

import api.NgucIndSubs;
import cucumber.api.java.en.*;

public class NgucIndSubsSteps {

    @Given("^Individual Subscription for NGUC is submitted from SFDC and provisioned in Amdocs and network$")
    public void Individual_Subscription_for_NGUC_is_submitted_from_SFDC_and_provisioned_in_Amdocs_and_network() throws Throwable {

    }

    @When("notification is received from Amdocs back to Salesforce for NGUC Individual Subscription$")
    public void notification_is_received_from_Amdocs_back_to_Salesforce_for_NGUC_Individual_Subscription() throws Throwable {
    	//CreateMRO.Postmro ();
    }

    @Then("^Post subscription will be triggered from SFDC to BDS and plans will be persisted in ARIA for Individual Subscription for NGUC$")
    public void post_subscription_will_be_triggered_from_SFDC_to_BDS_and_plans_will_be_persisted_in_ARIA_for_Individual_Subscription_for_NGUC() throws Throwable {
     //invoke api
    	NgucIndSubs.NgucIndsubs ();
    }



}
