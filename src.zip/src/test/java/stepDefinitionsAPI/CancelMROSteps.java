package stepDefinitionsAPI;

import api.CancelMRO;
import cucumber.api.java.en.*;

public class CancelMROSteps
{

	@Given("^Cancel MRO Order is submitted from SFDC and provisioned in Amdocs and network$")
	public void Cancel_MRO_Order_is_submitted_from_SFDC_and_provisioned_in_Amdocs_and_network() throws Throwable
	{

	}

	@When("notification is received from Amdocs back to Salesforce for Cancel MRO Order$")
	public void notification_is_received_from_Amdocs_back_to_Salesforce_for_Cancel_MRO_Order() throws Throwable
	{
		// CreateMRO.Postmro ();
	}

	@Then("^Post subscription will be triggered from SFDC to BDS and plans will be persisted in ARIA for Cancel MRO$")
	public void post_subscription_will_be_triggered_from_SFDC_to_BDS_and_plans_will_be_persisted_in_ARIA_for_Cancel_MRO() throws Throwable
	{
		CancelMRO.Cancelmro();
	}

}
