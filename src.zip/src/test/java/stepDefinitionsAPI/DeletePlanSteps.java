package stepDefinitionsAPI;

import api.DeletePlan;
import cucumber.api.java.en.*;

public class DeletePlanSteps
{

	@Given("^Sigma to delete Offers in ARIA$")
	public void sigma_to_delete_Offers_in_ARIA() throws Throwable
	{

	}

	@When("^Sigma intitiates delete plan Request$")
	public void sigma_intitiates_delete_plan_Request() throws Throwable
	{
		DeletePlan.deletePlan();
	}

	@Then("^Offer will be deleted in ARIA$")
	public void offer_will_be_deleted_in_ARIA() throws Throwable
	{

	}
}
