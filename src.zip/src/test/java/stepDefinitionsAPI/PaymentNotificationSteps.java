package stepDefinitionsAPI;

import api.PaymentNotify;
import cucumber.api.java.en.*;

public class PaymentNotificationSteps {
    @Given("^Customer has made the payment through usual payment channels$")
    public void customer_has_made_the_payment_through_usual_payment_channels() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @When("^payment is processed in ARIA Payment Manager$")
    public void payment_is_processed_in_ARIA_Payment_Manager() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        PaymentNotify.PostPaymentNotify ();
    }

    @Then("^Payment notification will be triggered from ARIA to customer via Notify$")
    public void payment_notification_will_be_triggered_from_ARIA_to_customer_via_Notify() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

}
