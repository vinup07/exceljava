package stepDefinitionsAPI;

import api.AllocateBAN;
import api.CreateBAN;
import api.ViewBAN;
import cucumber.api.java.en.*;

public class CreateBanEnhSteps
{

	@Given("^Logon to salesforce and navigate to billing account tab$")
	public void logon_to_salesforce_and_navigate_to_billing_account_tab() throws Throwable
	{
		// Write code here that turns the phrase above into concrete actions
	}

	// @When("^I click on save after populating all fields under billing account creation page$")
	// public void i_click_on_save_after_populating_all_fields_under_billing_account_creation_page() throws Throwable
	// {
	// AllocateBAN.getAllocateBan();
	// CreateBAN.PostCreateBan();
	// }

	@Then("^billing account details will be updated in ARIA and response will be returned to Salesforce$")
	public void billing_account_details_will_be_updated_in_ARIA_and_response_will_be_returned_to_Salesforce() throws Throwable
	{
		// Write code here that turns the phrase above into concrete actions
		AllocateBAN.getAllocateBan();
		CreateBAN.PostCreateBan();
	}

	@Given("^Logon to salesforce and navigate to billing account tab under account page$")
	public void logon_to_salesforce_and_navigate_to_billing_account_tab_under_account_page() throws Throwable
	{
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^I click on edit button$")
	public void i_click_on_edit_button() throws Throwable
	{
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^billing account details will be retrieved from ARIA to SFDC$")
	public void billing_account_details_will_be_retrieved_from_ARIA_to_SFDC() throws Throwable
	{
		// Write code here that turns the phrase above into concrete actions
		ViewBAN.ViewBillingAccount();

	}
}
