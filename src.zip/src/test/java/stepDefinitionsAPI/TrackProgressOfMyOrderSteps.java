package stepDefinitionsAPI;

import cucumber.api.PendingException;
import cucumber.api.java.en.*;
import org.junit.Assert;

public class TrackProgressOfMyOrderSteps {
    @Given("^I have placed order online$")
    public void i_have_placed_order_online() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("I have placed order online");
        Assert.assertEquals(true,true);
//        throw new PendingException();
    }

    @When("^I check the order status$")
    public void i_check_the_order_status() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
//        throw new PendingException();
        System.out.println("I check the order status");
        Assert.assertEquals(true,true);
    }

    @Then("^I should be able to track the progress of my order against Feasibility Completion$")
    public void i_should_be_able_to_track_the_progress_of_my_order_against_Feasibility_Completion() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
//        throw new PendingException();
        System.out.println("I should be able to track the progress of my order against Feasibility Completion");
        Assert.assertEquals(true,true);
    }

    @Then("^status is returned within (\\d+) seconds from the request$")
    public void status_is_returned_within_seconds_from_the_request(int arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
//        throw new PendingException();
        System.out.println("status is not returned within 5 seconds");
        Assert.assertEquals("Expected Time : Actual Time - 5:10",5,10);
    }

    @Then("^I should be able to track the progress of my order against Site Visit$")
    public void i_should_be_able_to_track_the_progress_of_my_order_against_Site_Visit() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
//        throw new PendingException();
        System.out.println("I should be able to track the progress of my order against Site Visit");
        Assert.assertEquals(true,true);
    }

    @Then("^I should be given the feedback about the search progress$")
    public void i_should_be_given_the_feedback_about_the_search_progress() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        System.out.println("There is no feedback about the search progress");
        Assert.assertEquals(true,true);
//        throw new PendingException();
    }

    @Then("^time of completion is displayed$")
    public void time_of_completion_is_displayed() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
//        throw new PendingException();
        System.out.println("Time to Complete is not displayed");
        Assert.assertEquals(true,false);
    }
}
