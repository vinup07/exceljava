package stepDefinitionsAPI;

import api.UpdatePlan;
import cucumber.api.java.en.*;

public class UpdatePlanSteps
{

	@Given("^Sigma to Update Offers and dates in ARIA$")
	public void sigma_to_Update_Offers_and_dates_in_ARIA() throws Throwable
	{

	}

	@When("^Sigma intitiates update Request$")
	public void sigma_intitiates_update_Request() throws Throwable
	{
		UpdatePlan.updateplan();
	}

	@Then("^Offer will be updated in ARIA$")
	public void offer_will_be_updated_in_ARIA() throws Throwable
	{

	}
}
