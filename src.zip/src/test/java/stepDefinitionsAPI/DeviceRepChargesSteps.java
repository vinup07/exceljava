package stepDefinitionsAPI;

import api.DeviceRepairCharges;
import cucumber.api.java.en.*;

public class DeviceRepChargesSteps {
    @Given("^Client-NOW would trigger the POST Billing Events API to create the charges in Billing System via OKAPI$")
    public void Client_NOW_would_trigger_the_POST_Billing_Events_API_to_create_the_charges_in_Billing_System_via_OKAPI() throws Throwable {

    }

    @When("^OKAPI will call the lambda function oneTimeCharges which will validate the payload if it is as per the interface$")
    public void OKAPI_will_call_the_lambda_function_oneTimeCharges_which_will_validate_the_payload_if_it_is_as_per_the_interface() throws Throwable {
    	//CreateMRO.Postmro ();
    }

    @Then("^If the validation is successful it will call the processor function createOTC$")
    public void If_the_validation_is_successful_it_will_call_the_processor_function_createOTC() throws Throwable {
     //invoke api
    	DeviceRepairCharges.DevRepCharges ();
    }



}
