package stepDefinitionsAPI;

import api.BDSCustomerMS;
import cucumber.api.java.en.*;

public class CIDNBanRetrSteps {


    @Given("^T-Connect to set up CIDN for Telstra customer$")
    public void t_Connect_to_set_up_CIDN_for_Telstra_customer() throws Throwable {

    }

    @When("^Customer logon to T-connect with their credentials and clicks on Billing summary page$")
    public void customer_logon_to_T_connect_with_their_credentials_and_clicks_on_Billing_summary_page() throws Throwable {
        //Invoke API
        BDSCustomerMS.CustomerMS ();

    }

    @Then("^all the associated Billing account numbers will be fetched from Customer MS & SFDC via BDS interface\\.$")
    public void all_the_associated_Billing_account_numbers_will_be_fetched_from_Customer_MS_SFDC_via_BDS_interface() throws Throwable {

    }

}
