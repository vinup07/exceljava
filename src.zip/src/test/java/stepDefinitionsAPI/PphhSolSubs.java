package stepDefinitionsAPI;

import api.PphhSolutionsubscription;
import cucumber.api.java.en.*;

public class PphhSolSubs {

    @Given("^PPHH Solution Subscription is submitted from SFDC and provisioned in Amdocs and network$")
    public void PPHH_Solution_Subscription_is_submitted_from_SFDC_and_provisioned_in_Amdocs_and_network() throws Throwable {

    }

    @When("notification is received from Amdocs back to Salesforce for PPHH Solution Subscription$")
    public void notification_is_received_from_Amdocs_back_to_Salesforce_for_PPHH_Solution_Subscription() throws Throwable {
    	//CreateMRO.Postmro ();
    }

    @Then("^Post subscription will be triggered from SFDC to BDS and plans will be persisted in ARIA for PPHH Solution Subscription$")
    public void Post_subscription_will_be_triggered_from_SFDC_to_BDS_and_plans_will_be_persisted_in_ARIA_for_PPHH_Solution_Subscription() throws Throwable {
     //invoke api
    	PphhSolutionsubscription.PphhSolsubs ();
    }



}
