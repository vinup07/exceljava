package stepDefinitionsAPI;

import api.PaymentTran;
import cucumber.api.java.en.*;

public class PaymentRetTranID {

    @Given("^T-Connect to set up CIDN for business customer in the system$")
    public void t_Connect_to_set_up_CIDN_for_business_customer_in_the_system() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @When("^Customer logon to T-connect with their credentials and clicks on Transaction payment details$")
    public void customer_logon_to_T_connect_with_their_credentials_and_clicks_on_Transaction_payment_details() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        PaymentTran.Paymenttran ();

    }

    @Then("^all the payments details for the requested Transaction ID  will be fetched and displayed in T-connect page$")
    public void all_the_payments_details_for_the_requested_Transaction_ID_will_be_fetched_and_displayed_in_T_connect_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }


}
