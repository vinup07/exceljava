package stepDefinitionsAPI;

import api.PaymentBds;
import cucumber.api.java.en.*;

public class TConnectPaymentSteps {

    @Given("^T-Connect to set up CIDN for a Telstra customer$")
    public void t_Connect_to_set_up_CIDN_for_a_Telstra_customer() throws Throwable {

    }

    @When("^Customer logon to T-connect with their credentials and clicks on Invoice details$")
    public void customer_logon_to_T_connect_with_their_credentials_and_clicks_on_Invoice_details() throws Throwable {
        // invokeapi
        PaymentBds.PaymentRet ();
    }

    @Then("^all invoice related details along with payment details will be fetched and displayed in T-connect page$")
    public void all_invoice_related_details_along_with_payment_details_will_be_fetched_and_displayed_in_T_connect_page() throws Throwable {

    }
}
