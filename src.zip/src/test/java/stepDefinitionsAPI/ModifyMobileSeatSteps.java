package stepDefinitionsAPI;

import api.ModMobileSeat;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ModifyMobileSeatSteps {


    @Given("^Mobile Seat Order is submitted from SFDC and provisioned in Amdocs and Network$")
    public void mobile_Seat_Order_is_submitted_from_SFDC_and_provisioned_in_Amdocs_and_Network() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    }

    @When("^notification is received from Amdocs back to Salesforce for modify mobile seat order$")
    public void notification_is_received_from_Amdocs_back_to_Salesforce() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //CreateMobileSeat.PostMobileSeat ();
    }

    @Then("^Post subscription for Modify MobileSeat will be triggered from SFDC to BDS and plans will be persisted in ARIA$")
    public void post_subscription_for_Modify_MobileSeat_will_be_triggered_from_SFDC_to_BDS_and_plans_will_be_persisted_in_ARIA() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	ModMobileSeat.Modsubscription();
    }
}
