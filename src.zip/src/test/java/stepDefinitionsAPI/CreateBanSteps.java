package stepDefinitionsAPI;

import api.CreateBAN;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class CreateBanSteps
{

	@Given("^Logon to salesforce and navigate to billing account tab under accounts page$")
	public void logon_to_salesforce_and_navigate_to_billing_account_tab_under_accounts_page() throws Throwable
	{

	}

//	@When("^I click on save after populating  all mandatory fields under billing account creation page$")
//	public void i_click_on_save_after_populating_all_mandatory_fields_under_billing_account_creation_page() throws Throwable
//	{
//		CreateBAN.PostCreateBan();
//	}

	@Then("^billing account details will be persisted in ARIA and response will be returned to SFDC\\.$")
	public void billing_account_details_will_be_persisted_in_ARIA_and_response_will_be_returned_to_SFDC() throws Throwable
	{
		CreateBAN.PostCreateBan();
	}

}
