package stepDefinitionsAPI;

import api.InvoiceBNum;
import cucumber.api.java.en.*;

public class InvoiceSequenceIdSteps
{

	@Given("^T-Connect to set up CIDN and  Billing account number in their site$")
	public void t_Connect_to_set_up_CIDN_and_Billing_account_number_in_their_site() throws Throwable
	{

	}

	// @When("^customer logon to T-connect with their credentials and clicks on invoice based on invoice number$")
	// public void customer_logon_to_T_connect_with_their_credentials_and_clicks_on_invoice_based_on_invoice_number() throws Throwable
	// {
	// InvoiceBNum.invoice();
	// }

	@Then("^most corresponding Invoice will be downloaded from Invoice manager and displayed in T-Connect$")
	public void most_corresponding_Invoice_will_be_downloaded_from_Invoice_manager_and_displayed_in_T_Connect() throws Throwable
	{
		InvoiceBNum.invoice();
	}

	@When("^customer logon to T-connect with their credentials and clicks on invoice based on  invoice number$")
	public void customer_logon_to_T_connect_with_their_credentials_and_clicks_on_invoice_based_on_invoice_number() throws Throwable
	{
		//InvoiceBNum.invoice();
	}
}
