package stepDefinitionsAPI;

import api.ModifyBAN;
import cucumber.api.java.en.*;

public class ModifyBanSteps {

    @Given("^Login to salesforce and navigate to billing accounts tab under accounts page and modify billing account owner and address details$")
    public void login_to_salesforce_and_navigate_to_billing_accounts_tab_under_accounts_page_and_modify_billing_account_owner_and_address_details() throws Throwable {

    }

    @When("^I click on edit button tab and save the details$")
    public void i_click_on_edit_button_tab_and_save_the_details() throws Throwable {

        //Invoke API
        ModifyBAN.PostModifyBan ();

    }

    @Then("^modify billing account details will be invoked from customer MS to BDS and eventually persisted in ARIA$")
    public void modify_billing_account_details_will_be_invoked_from_customer_MS_to_BDS_and_eventually_persisted_in_ARIA() throws Throwable {

    }

}
