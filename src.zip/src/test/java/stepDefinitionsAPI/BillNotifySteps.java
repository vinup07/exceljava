package stepDefinitionsAPI;

import api.BillNotify;
import cucumber.api.java.en.*;

public class BillNotifySteps {

    @Given("^Customer Bill cycle is due to run on the bill cycle day$")
    public void customer_Bill_cycle_is_due_to_run_on_the_bill_cycle_day() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @When("^invoice is generated with the invoice details in ARIA$")
    public void invoice_is_generated_with_the_invoice_details_in_ARIA() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        BillNotify.PostNotifyBill ();
    }

    @Then("^Bill ready notification will be triggered from ARIA and email will be triggered to customer via Notify$")
    public void bill_ready_notification_will_be_triggered_from_ARIA_and_email_will_be_triggered_to_customer_via_Notify() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }
}
