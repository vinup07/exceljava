package stepDefinitionsAPI;

import api.AllocateBAN;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import dataProviders.ConfigFileReader;

public class AllocateBanSteps
{
	private Boolean isEnabledIntTest;

	@Given("^Logon to salesforce and navigate to billing account tab under accounts section$")
	public void logon_to_salesforce_and_navigate_to_billing_account_tab_under_accounts_section() throws Throwable
	{
		ConfigFileReader configFileReader = new ConfigFileReader();
		isEnabledIntTest = configFileReader.IsEnabledIntegration();
		if (isEnabledIntTest)
		{
			System.out.println("Login to SalesForce");
			System.out.println("Navigate to Billing Accounts Tab");
		}
		else
		{
			// Do Nothing
		}
	}

	@When("^I click on new tab$")
	public void i_click_on_new_tab() throws Throwable
	{
		if (isEnabledIntTest)
		{
			System.out.println("Click on New Tab");
		}
		else
		{
			// Do Nothing
		}
		// invoke api
		// AllocateBAN.getAllocateBan();
	}

	@Then("^unique billing account number will be created in SFDC from BDS$")
	public void unique_billing_account_number_will_be_created_in_SFDC_from_BDS() throws Throwable
	{
		// getAllocateBan();
		AllocateBAN.getAllocateBan();
		// boolean result = getAllocateBan();
		// assertEquals ("BAN",true,result);
	}
}
