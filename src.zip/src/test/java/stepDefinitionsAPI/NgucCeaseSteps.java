package stepDefinitionsAPI;

import api.NgucCease;
import cucumber.api.java.en.*;

public class NgucCeaseSteps {

    @Given("^Individual Subscription for NGUC for Cease is submitted from SFDC and provisioned in Amdocs and network$")
    public void Individual_Subscription_for_NGUC_for_Cease_is_submitted_from_SFDC_and_provisioned_in_Amdocs_and_network() throws Throwable {

    }

    @When("notification is received from Amdocs back to Salesforce for NGUC Cease scenario$")
    public void notification_is_received_from_Amdocs_back_to_Salesforce_for_NGUC_Cease_scenario() throws Throwable {
    	//CreateMRO.Postmro ();
    }

    @Then("^Post subscription will be triggered from SFDC to BDS and plans will be persisted in ARIA for NGUC Cease scenario$")
    public void post_subscription_will_be_triggered_from_SFDC_to_BDS_and_plans_will_be_persisted_in_ARIA_for_NGUC_Cease_scenario() throws Throwable {
     //invoke api
    	NgucCease.NgucCease ();
    }

}

