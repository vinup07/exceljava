package stepDefinitionsAPI;

import api.GetAccountdetailsm;
import cucumber.api.java.en.*;

public class GetAccountSteps
{

	@Given("^subscription has flowed down from ordering system$")
	public void subscription_has_flowed_down_from_ordering_system() throws Throwable
	{
		// Write code here that turns the phrase above into concrete actions
	}

	@When("^we initiate get account details call to ARIA$")
	public void we_initiate_get_account_details_call_to_ARIA() throws Throwable
	{
		// Write code here that turns the phrase above into concrete actions
		GetAccountdetailsm.GetAccount();
	}

	@Then("^all details related to plans and prices should retrieve to validate RTB\\.$")
	public void all_details_related_to_plans_and_prices_should_retrieve_to_validate_RTB() throws Throwable
	{
		// Write code here that turns the phrase above into concrete actions
	}
}
