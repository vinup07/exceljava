package stepDefinitionsAPI;

import api.PaymentStrEnddt;
import cucumber.api.java.en.*;

public class PaymentRetRange {
    @Given("^T-Connect to set up CIDN for business customer$")
    public void t_Connect_to_set_up_CIDN_for_business_customer() throws Throwable {
//        // Write code here that turns the phrase above into concrete actions
//        throw new PendingException();
    }

    @When("^Customer logon to T-connect with their credentials and clicks on payment details$")
    public void customer_logon_to_T_connect_with_their_credentials_and_clicks_on_payment_details() throws Throwable {
        PaymentStrEnddt.PaymentdatRG ();
//        // Write code here that turns the phrase above into concrete actions
//        throw new PendingException();
    }

    @Then("^all the payments details for the requested period will be fetched and displayed in T-connect page$")
    public void all_the_payments_details_for_the_requested_period_will_be_fetched_and_displayed_in_T_connect_page() throws Throwable {
//        // Write code here that turns the phrase above into concrete actions
//        throw new PendingException();
    }

}
