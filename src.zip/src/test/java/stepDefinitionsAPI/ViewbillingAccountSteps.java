package stepDefinitionsAPI;

import api.ViewBAN;
import cucumber.api.java.en.*;

public class ViewbillingAccountSteps {

    @Given("^Login to salesforce and navigate to billing accounts tab under accounts page$")
    public void login_to_salesforce_and_navigate_to_billing_accounts_tab_under_accounts_page() throws Throwable {

    }

    @When("^I click on edit button tab$")
    public void i_click_on_edit_button_tab() throws Throwable {
        //invoke api
        ViewBAN.ViewBillingAccount ();
    }

    @Then("^billing account details will be retrieved from ARIA to BDS and then to SFDC$")
    public void billing_account_details_will_be_retrieved_from_ARIA_to_BDS_and_then_to_SFDC() throws Throwable {

    }


}
