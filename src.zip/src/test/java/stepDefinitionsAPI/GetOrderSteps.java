package stepDefinitionsAPI;

import api.GetOrder;
import cucumber.api.java.en.*;

public class GetOrderSteps {

    @Given("^Once off charges have been created under right to bill$")
    public void once_off_charges_have_been_created_under_right_to_bill() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @When("^we initiate get order details call to ARIA$")
    public void we_initiate_get_order_details_call_to_ARIA() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        GetOrder.Getorder ();

    }

    @Then("^order details from ARIA should retrieve to validate RTB\\.$")
    public void order_details_from_ARIA_should_retrieve_to_validate_RTB() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

}
