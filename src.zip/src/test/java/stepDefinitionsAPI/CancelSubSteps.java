package stepDefinitionsAPI;

import api.CancelServiceSub;
import cucumber.api.java.en.*;

public class CancelSubSteps {

    @Given("^Cancel Order is submitted from SFDC and provisioned in Amdocs and network$")
    public void cancel_Order_is_submitted_from_SFDC_and_provisioned_in_Amdocs_and_network() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @When("^notification is received from Amdocs back to Salesforce for Cancel Order$")
    public void notification_is_received_from_Amdocs_back_to_Salesforce_for_Cancel_Order() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^Post subscription will be triggered to BDS and plans and services will be cancelled in ARIA,CMP & OCS\\.$")
    public void post_subscription_will_be_triggered_to_BDS_and_plans_and_services_will_be_cancelled_in_ARIA_CMP_OCS() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        CancelServiceSub.Cancelsubscription ();

    }

}
