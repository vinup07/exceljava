package stepDefinitionsAPI;

import api.CreditAdjustment;
import cucumber.api.java.en.*;

public class CreditAdjustmentSteps {

    @Given("^Salesforce to identify customer who are eligible for credits$")
    public void salesforce_to_identify_customer_who_are_eligible_for_credits() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @When("^credit adjustment amount is applied from Salesforce on billing account$")
    public void credit_adjustment_amount_is_applied_from_Salesforce_on_billing_account() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        CreditAdjustment.PostCreditAdjust ();
        }

    @Then("^credit amount will be appied in ARIA through BDS and Okapi layer and the same can be viewed in T-connect$")
    public void credit_amount_will_be_appied_in_ARIA_through_BDS_and_Okapi_layer_and_the_same_can_be_viewed_in_T_connect() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }
    }