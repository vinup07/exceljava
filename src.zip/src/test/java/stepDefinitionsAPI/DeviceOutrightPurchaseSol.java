package stepDefinitionsAPI;

import api.DevicePurchaseOfferSubs;
import cucumber.api.java.en.*;

public class DeviceOutrightPurchaseSol {

    @Given("^Device Outright Purchase Offer Subscription is submitted from SFDC and provisioned in Amdocs and network$")
    public void Device_Outright_Purchase_Offer_Subscription_is_submitted_from_SFDC_and_provisioned_in_Amdocs_and_network() throws Throwable {

    }

    @When("notification is received from Amdocs back to Salesforce for Device Outright Purchase Offer Subscription$")
    public void notification_is_received_from_Amdocs_back_to_Salesforce_for_Device_Outright_Purchase_Offer_Subscription() throws Throwable {
    	//CreateMRO.Postmro ();
    }

    @Then("^Post subscription will be triggered from SFDC to BDS and plans will be persisted in ARIA for Device Outright Purchase Offer Subscription$")
    public void Post_subscription_will_be_triggered_from_SFDC_to_BDS_and_plans_will_be_persisted_in_ARIA_for_Device_Outright_Purchase_Offer_Subscription() throws Throwable {
     //invoke api
    	DevicePurchaseOfferSubs.DeviceOffersubs ();
    }



}
