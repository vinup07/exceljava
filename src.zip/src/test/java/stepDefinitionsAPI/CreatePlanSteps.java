package stepDefinitionsAPI;

import api.CreatePlan;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreatePlanSteps
{

	@Given("^Sigma to set up Offers and supplementary plans based on Billing SpecID$")
	public void sigma_to_set_up_Offers_and_supplementary_plans_based_on_Billing_SpecID() throws Throwable
	{ // Write code here that turns the phrase above into concrete actions

	}

	@When("^Sigma triggers the launch$")
	public void sigma_triggers_the_launch() throws Throwable
	{
		CreatePlan.createplan();
		// Write code here that turns the phrase above into concrete actions throw new PendingException();
	}

	@Then("^Offer and all associated Chargeblocks will be created in ARIA$")
	public void offer_and_all_associated_Chargeblocks_will_be_created_in_ARIA() throws Throwable
	{
		// Write code here that turns the phrase above into concrete actions

	}
}
