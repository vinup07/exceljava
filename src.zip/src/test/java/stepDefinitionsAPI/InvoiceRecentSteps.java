package stepDefinitionsAPI;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class InvoiceRecentSteps
{

	@Given("^T-Connect to set up CIDN and  Billing account number$")
	public void t_Connect_to_set_up_CIDN_and_Billing_account_number() throws Throwable
	{

	}

	@When("^Customer logon to T-connect with their credentials$")
	public void customer_logon_to_T_connect_with_their_credentials() throws Throwable
	{
		api.InvoiceRecent.invoiceRec();
	}

	@Then("^most recent Invoice will be downloaded from Invoice manager and displayed in T-Connect$")
	public void most_recent_Invoice_will_be_downloaded_from_Invoice_manager_and_displayed_in_T_Connect() throws Throwable
	{

	}

}
