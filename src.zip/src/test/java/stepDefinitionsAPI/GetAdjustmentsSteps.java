package stepDefinitionsAPI;

import api.GetAdjustment;
import cucumber.api.java.en.*;

public class GetAdjustmentsSteps {
    @Given("^T-Connect to set up a CIDN to view Adjustments for Telstra Customer$")
    public void t_Connect_to_set_up_a_CIDN_to_view_Adjustments_for_Telstra_Customer() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @When("^Customer logon to T-connect with their credentials and clicks on Adjustments details$")
    public void customer_logon_to_T_connect_with_their_credentials_and_clicks_on_Adjustments_details() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        GetAdjustment.GetAdjust ();
    }

    @Then("^all invoice related details along with Adjustments details will be fetched and displayed in T-connect page$")
    public void all_invoice_related_details_along_with_Adjustments_details_will_be_fetched_and_displayed_in_T_connect_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    }


