package stepDefinitionsAPI;

import api.PostSub;
import cucumber.api.java.en.*;

public class PostSubscriptionSteps {

    @Given("^CWP Order is submitted from SFDC and provisioned in Amdocs and network$")
    public void cwp_Order_is_submitted_from_SFDC_and_provisioned_in_Amdocs_and_network() throws Throwable {

    }

    @When("^notification is received from Amdocs back to Salesforce$")
    public void notification_is_received_from_Amdocs_back_to_Salesforce() throws Throwable {

    }

    @Then("^Post subscription will be triggered from SFDC to BDS and plans will be persisted in ARIA$")
    public void post_subscription_will_be_triggered_from_SFDC_to_BDS_and_plans_will_be_persisted_in_ARIA() throws Throwable {
     //invoke api
        PostSub.Postsubscription ();
    }



}
