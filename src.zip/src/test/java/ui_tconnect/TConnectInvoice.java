package ui_tconnect;

import uiUtils.Browsers;
import uiUtils.CommonUtils;
import uiUtils.Driver;
import uiUtils.Pages;
import apiUtils.ApiUtils;
import apiUtils.GlobalConstants;
import dataProviders.ConfigFileReader;
import groovyjarjarantlr.collections.List;

import org.slf4j.Logger;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Keys;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.LoggerFactory;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;

import static apiUtils.GlobalConstants.InvoicePDFpath;
import static org.junit.Assert.assertEquals;

public class TConnectInvoice extends Driver {
	
		private static final Logger LOG = LoggerFactory.getLogger(TConnectInvoice.class);
		public static String bills;
		public static String invoices;
		public static String payments;
		public static String adjustments;
		static WebDriverWait wait = new WebDriverWait(driver, 25);
		
		public static void goToInvoice() throws InterruptedException, CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException, AWTException 
		{
			Thread.sleep(10000);
			RandomAccessFile file = new RandomAccessFile("accountsit.txt", "r");
	    	driver.findElement(Pages.bansearch).sendKeys(Keys.ENTER);
	    	Thread.sleep(10000);
	    	String str;
	    	while ((str = file.readLine()) != null) {
				driver.findElement(Pages.bansearch1).sendKeys(str);
	    	}
	    	file.close();
			Thread.sleep(10000);
			driver.findElement(Pages.bandisplay).click();
			Thread.sleep(5000);
			driver.findElement(Pages.bandetails).click();
			Thread.sleep(2000);
			Robot objrobot = new Robot();
			objrobot.keyPress(KeyEvent.VK_PAGE_DOWN);
			objrobot.keyRelease(KeyEvent.VK_PAGE_DOWN);
			Thread.sleep(5000);
			driver.findElement(Pages.pdfdwnld).click();
			//CommonUtils.takeScreenshot("T-Connect");
			//driver.quit();
		}

	}

   







