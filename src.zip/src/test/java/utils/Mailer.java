package utils;

import org.apache.commons.mail.*;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Mailer {
    String result = "";
    InputStream inputStream;
    @Test
    public void sendEmailWithAttachments() throws EmailException, InterruptedException {

        Properties prop = new Properties();
        String propFileName = "config.properties";
        try {
            prop.load(getClass().getClassLoader().getResourceAsStream(propFileName));
        } catch (IOException e) {
            e.printStackTrace();
        }


        String fileName=prop.getProperty("fileName");
        String filePath = prop.getProperty("filePath");
        System.out.println(filePath);
        String addTo = prop.getProperty("addTo");
        String setFrom = prop.getProperty("setFrom");
        String setFromName = prop.getProperty("setFromName");
        String setSubject = prop.getProperty("setSubject");
        String setMsg = prop.getProperty("setMsg");
        EmailAttachment attachment = new EmailAttachment();
        attachment.setPath(filePath+fileName+".html");
        attachment.setDisposition(EmailAttachment.ATTACHMENT);
        MultiPartEmail email = new HtmlEmail();
        email.setDebug(true);
        email.setHostName("smtp.smart-rr.in.telstra.com.au");
        email.addTo(addTo);
        email.setFrom(setFrom, setFromName);
        email.setSubject(setSubject);
        email.setMsg(setMsg);

        email.attach(attachment);
        email.send();
        System.out.println("Email Sent");
        TimeStampFormat.dateFormat();

        File f1 = new File(filePath+fileName+".html");
        File f2 = new File(filePath+fileName+"_"+ TimeStampFormat.dateFormat()+".html");
        boolean b = f1.renameTo(f2);
        System.out.println("File Name Changed");
    }


}