package utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeStampFormat {
    public static String dateFormat() {
        String Dates=new SimpleDateFormat("yyyyMMdd_HH-mm-ss").format(new Date());
        return Dates;
    }
}
