package utils;

import org.apache.commons.codec.binary.Base64;
import org.junit.Test;

public class EncryptPassword {

    @Test
    public void testEncryptPassword(){

// Enter the password below which requires encryption
//        encryptPassword("XXXXXXXX");
    }

    public static String encryptPassword(String pswd) {
        byte[] encodedPwdBytes = Base64.encodeBase64(pswd.getBytes());
        String decodedPwd= new String(encodedPwdBytes);

//        System.out.println("Password in plain text: "+pswd);
//        System.out.println("Encrypted Password: "+decodedPwd);

        return decodedPwd;
    }

    //@Test
    public void testDecryptPassword(){
        decryptPassword("");
    }
    public static String decryptPassword(String pswd) {
        byte[] decodedPwdBytes = Base64.decodeBase64(pswd.getBytes());
        String decodedPwd= new String(decodedPwdBytes);

//        System.out.println("Decrypted Password in plain text: "+decodedPwd);
        return decodedPwd;
    }
}
