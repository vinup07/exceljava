package utils;

import org.apache.commons.mail.EmailException;

import java.io.IOException;

/**
 * @author Crunchify.com
 *
 */

public class ReadConfigMain {

    public static void main(String[] args) throws IOException, InterruptedException, EmailException {
        Mailer properties = new Mailer();
        properties.sendEmailWithAttachments();
    }
}