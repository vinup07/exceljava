package batchInterface;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class RPSDataLayout {

    private static final String fileId = "FDR";
    private static final String sourceCode = "RPS";
    private String sequenceNumber;
    private String fileDateDdMmYy;

    private static final String batchHeaderId = "BHR";
    private String paymentType;
    private String batchAmount;

    private static final String transRecId = "TRR";
    private String ariaAcNum;
    private String appliedAmtInCents;
    private static final String trrPaymentType = "EDIEFT";
    private String trNum;
    private String refNum;

    private static final String footerRecId = "FFR";
    private String amount;
    private String itemCount;

    public static String getFileId() {
        return fileId;
    }

    public static String getSourceCode() {
        return sourceCode;
    }

    public String getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(String sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public String getFileDateDdMmYy() {
        return fileDateDdMmYy;
    }

    public void setFileDateDdMmYy(String fileDateDdMmYy) {
        this.fileDateDdMmYy = fileDateDdMmYy;
    }

    public static String getBatchHeaderId() {
        return batchHeaderId;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getBatchAmount() {
        return batchAmount;
    }

    public void setBatchAmount(String batchAmount) {
        this.batchAmount = batchAmount;
    }

    public static String getTransRecId() {
        return transRecId;
    }

    public String getAriaAcNum() {
        return ariaAcNum;
    }

    public void setAriaAcNum(String ariaAcNum) {
        this.ariaAcNum = ariaAcNum;
    }

    public String getAppliedAmtInCents() {
        return appliedAmtInCents;
    }

    public void setAppliedAmtInCents(String appliedAmtInCents) {
        this.appliedAmtInCents = appliedAmtInCents;
    }

    public static String getTrrPaymentType() {
        return trrPaymentType;
    }

    public String getTrNum() {
        return trNum;
    }

    public void setTrNum(String trNum) {
        this.trNum = trNum;
    }

    public String getRefNum() {
        return refNum;
    }

    public void setRefNum(String refNum) {
        this.refNum = refNum;
    }

    public static String getFooterRecId() {
        return footerRecId;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getItemCount() {
        return itemCount;
    }

    public void setItemCount(String itemCount) {
        this.itemCount = itemCount;
    }

    public void createRpsObject(String sequenceNumber,String amt, String fileDate,String accountNum,String trNum,String refNum,String itemCnt){
        setSequenceNumber(sequenceNumber);
        setFileDateDdMmYy(fileDate);
        setPaymentType("EDIEFT");
        setBatchAmount(amt);
        setAriaAcNum(accountNum);
        setAmount(amt);
        setTrNum(trNum);
        setRefNum(refNum);
        setAmount(amt);
        setItemCount(itemCnt);
    }

    public void createRpsBatchFile(String fileName){
        File batchFile = new File("src/test/resources/rpsBatch/" + fileName);
        try{
            batchFile.createNewFile();
            BufferedWriter batchWriter = new BufferedWriter(new FileWriter("src/test/resources/rpsBatch/" + fileName));

            batchWriter.write(getFileId());
            batchWriter.write(getSourceCode());
            batchWriter.write(getSequenceNumber());
            batchWriter.write(getFileDateDdMmYy());
            batchWriter.write("\n");

            batchWriter.write(getBatchHeaderId());
            batchWriter.write(getPaymentType());
            batchWriter.write(getFileDateDdMmYy());
            batchWriter.write(getBatchAmount());
            batchWriter.write("\n");

            batchWriter.write(getTransRecId());
            batchWriter.write(getAriaAcNum());
            batchWriter.write(getFileDateDdMmYy());
            batchWriter.write(getAmount());
            batchWriter.write(getPaymentType());
            batchWriter.write(getTrNum());
            batchWriter.write(getRefNum());
            batchWriter.write("\n");

            batchWriter.write(getFooterRecId());
            batchWriter.write(getAmount());
            batchWriter.write(getItemCount());
            batchWriter.write("\n");
            batchWriter.close();
        }catch(Exception e){
            e.printStackTrace();
        }


    }
}
