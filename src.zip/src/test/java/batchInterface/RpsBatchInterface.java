package batchInterface;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Date;


public class RpsBatchInterface {
    @Test
    public void testRpsFtp() {
        System.out.println("Start Batch Test\n");

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat ("ddMMyy");
        String currdate = simpleDateFormat.format (new Date ());
        System.out.println (currdate);

        RPSDataLayout rps = new RPSDataLayout();

        //Increment
        String seqNum = "0052";
//        String date = "110918";
        String date = currdate;
        String amt = "0000000001000";
        String accNum = "700000037916";
        //Increment
        String trNum = "00000014";
        String refNum = "9900000002669";
        String itemCnt = "00000001";
        rps.createRpsObject(seqNum,amt,date,accNum,trNum,refNum,itemCnt);
        //Increment
        String transSeqNum = "13";
        String rpsBatchfile = "ARIA" + "2009" + "." + "R" + transSeqNum;
        rps.createRpsBatchFile(rpsBatchfile);


        RpsFtp(rpsBatchfile);
        System.out.println("End Batch Test");




    }
    public void RpsFtp(String batchFile)  {
        JSch jsch = new JSch();
        Session session = null;
        try {
            session = jsch.getSession("PAYMANAGER_SFX_P01", "lbvip0692.dc.corp.telstra.com", 13022);
            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword("paymanagersfx01");
            session.connect();
            Channel channel = session.openChannel("sftp");
            channel.connect();
            ChannelSftp sftpChannel = (ChannelSftp) channel;
//            sftpChannel.put("/tmplocal/testUpload.txt", "/tmpremote/testUpload.txt");
//            sftpChannel.put(System.getProperty("user.dir")+ "\ftpTest.txt", "/RPS/RPS_PAYMANAGER/");
//            sftpChannel.put("D://repos//edge_u2c//ftpTest.txt", "/RPS/RPS_PAYMANAGER/ftpTest.txt");
            sftpChannel.put("src/test/resources/rpsBatch/" + batchFile, "/RPS/RPS_PAYMANAGER/fromRPS/" + batchFile);
            sftpChannel.exit();
            session.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
//        } catch (SftpException e) {
//            e.printStackTrace();
//        }
    }

}
