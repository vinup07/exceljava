package ui_aria;

import uiUtils.Browsers;
import uiUtils.Driver;
import uiUtils.Pages;
import apiUtils.ApiUtils;
import apiUtils.GlobalConstants;
import dataProviders.ConfigFileReader;
import groovyjarjarantlr.collections.List;

import org.slf4j.Logger;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.LoggerFactory;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;

import static org.junit.Assert.assertEquals;

public class AriaAccountSearch extends Driver {
	
		private static final Logger LOG = LoggerFactory.getLogger(AriaAccountSearch.class);
		//public static String OcsViewSubscriber;
		public static String account;
		public static String search;
		//public static String adjustments;
		static WebDriverWait wait = new WebDriverWait(driver, 25);
		
		public static void ariaAccountsearch() throws InterruptedException, CertificateException, UnrecoverableKeyException, NoSuchAlgorithmException, IOException, KeyManagementException, KeyStoreException, ParseException, AWTException 
		{
	    	RandomAccessFile file = new RandomAccessFile("accountsit.txt", "r");
	    	//JavascriptExecutor js = (JavascriptExecutor) driver;
  			Thread.sleep(2000);
			WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(Pages.account));
			element.click();
			Thread.sleep(5000);
			driver.findElement(Pages.account);
			//Thread.sleep(2000);
			driver.findElement(Pages.search).click();
			Thread.sleep(10000);
	    	String str;
	    	while ((str = file.readLine()) != null) {
				driver.findElement(Pages.search_value).sendKeys(str);
	    	}
	    	file.close();
			driver.findElement(Pages.search_button).click();
			Thread.sleep(5000);
			driver.findElement(Pages.accountovrview).click();
			Thread.sleep(2000);
			driver.findElement(Pages.balancedetails).click();
			Thread.sleep(5000);
			//js.executeScript("window.scrollBy(0,200)");
			Robot objrobot = new Robot();
			objrobot.keyPress(KeyEvent.VK_PAGE_DOWN);
			objrobot.keyRelease(KeyEvent.VK_PAGE_DOWN);
			Thread.sleep(5000);
			driver.findElement(Pages.plan).click();
			Thread.sleep(5000);
			Robot objrobot1 = new Robot();
			objrobot1.keyPress(KeyEvent.VK_PAGE_DOWN);
			objrobot1.keyRelease(KeyEvent.VK_PAGE_DOWN);
			//Thread.sleep(5000);
			//driver.quit();
		}

	}

   







