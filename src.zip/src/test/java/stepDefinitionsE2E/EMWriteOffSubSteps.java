package stepDefinitionsE2E;

import uiUtils.Driver;
import ui_aria.AriaAccountSearch;
import ui_tconnect.TConnectInvoice;
import ui_tconnect.TConnect_Billingpage;

import static apiUtils.ApiUtils.randomAlphaNumeric;
import static apiUtils.GlobalConstants.CancelInputFile;
import static apiUtils.GlobalConstants.PostSubURL;
import static io.restassured.specification.ProxySpecification.host;
import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;
import java.util.Scanner;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import api.AllocateBAN;
import api.CreateBAN;
import api.EmWriteOffSub;
import api.NgucIndSubs;
import api.NgucOfferSolSubs;
import api.PostSub;
import api.PphhIndividualsubscription;
import api.PphhSolutionsubscription;
import apiUtils.ApiUtils;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class EMWriteOffSubSteps
{
	@Given("^EM Offer Sol and Individual Subscriptions APIs with payloads\\.$")
	public void EM_Offer_Sol_and_Individual_Subscriptions_APIs_with_payloads() throws Throwable {
		AllocateBAN.getAllocateBan();
		CreateBAN.PostCreateBan();
		PphhSolutionsubscription.PphhSolsubs ();
		PphhIndividualsubscription.PphhIndsubs ();
    
	}
	
	@Given("^user cancels EM Individual subscription and then EM Offer Sol$")
	public void user_cancels_EM_Individual_subscription_and_then_EM_Offer_Sol() throws Throwable {
		EmWriteOffSub.CancelsubscriptionEM();
		EmWriteOffSub.CancelSolutionEM();
		TimeUnit.SECONDS.sleep(40);

	}
	
	@Given("^I set Bill lag Days$")
	public void i_set_Bill_lag_Days() throws Throwable {
       EmWriteOffSub.setBillLagDays();
	}
	
	@Then("^user generates invoice and statement in ARIA using ARIA API$")
	public void generate_invoice_statement_ARIA() throws Throwable {
       EmWriteOffSub.generateInvoice();
	}
	
	@Then("^user triggers \"([^\"]*)\" and verify acct_status in ARIA and BDS$")
	public void user_triggers_and_verify_acct_status_in_ARIA(String status) throws Throwable {
		EmWriteOffSub.update_acct_status(status);
	}
	
	@Then("^user triggers WriteOff and verify acct_status , write_off paramters and Total_Balance in ARIA and BDS$")
	public void user_triggers_WriteOff_and_verify_acct_status_write_off_paramters_and_Total_Balance_in_ARIA_and_BDS() throws Throwable {
		EmWriteOffSub.write_off();
	}
	
	@Then("^user triggers goodwill credit adjustment with \"([^\"]*)\" amount and validate acct_status,write_off paramters and Total_Balance in ARIA and BDS$")
	public void user_triggers_goodwill_credit_adjustment_with_amount_and_validate_acct_status_write_off_paramters_and_Total_Balance_in_ARIA_and_BDS(String arg1) throws Throwable {
		EmWriteOffSub.adjustment(arg1);
	}
	
	@Then("^user makes \"([^\"]*)\" Payment$")
	public void make_Payment(String paymentType) throws Throwable {
		Response response = EmWriteOffSub.get_acct_status_ARIA(EmWriteOffSub.Billact);
		JsonPath var = response.jsonPath();
        float balance = var.get("acct_balance");
        EmWriteOffSub.makePayment(paymentType ,balance);
	}

	@Then("^user triggers WriteOff and verify error message$")
	public void user_triggers_WriteOff_and_verify_error_message() throws Throwable {
		EmWriteOffSub.writeOffPaymnetProcessor();
	}


}