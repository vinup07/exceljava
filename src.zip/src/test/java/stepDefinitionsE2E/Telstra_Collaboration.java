package stepDefinitionsE2E;

import uiUtils.Driver;
import ui_aria.AriaAccountSearch;
import ui_tconnect.TConnectInvoice;
import ui_tconnect.TConnect_Billingpage;
import api.AllocateBAN;
import api.CreateBAN;
import api.NgucIndSubs;
import api.NgucOfferSolSubs;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Telstra_Collaboration extends Driver
{
	@Given("^NGUC Offer Sol and Individual Subscriptions APIs with payloads\\.$")
	public void nguc_Offer_Sol_and_Individual_Subscriptions_APIs_with_payloads() throws Throwable {
		AllocateBAN.getAllocateBan();
		CreateBAN.PostCreateBan();
		NgucOfferSolSubs.NgucOffersubs();
		NgucIndSubs.NgucIndsubs();
    
	}

	@When("^Valid Username and Password for Aria and T-Connect are present$")
	public void valid_Username_and_Password_for_Aria_and_T_Connect_are_present() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
    
	}

	@Then("^User should be able to observe account overview details in Aria and invoice in T-Connect$")
	public void user_should_be_able_to_observe_account_overview_details_in_Aria_and_invoice_in_T_Connect() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Driver.launchbrowser();
		Driver.logintoAria();
		AriaAccountSearch.ariaAccountsearch();
		Driver.launchbrowser();
		Driver.logintoTConnect();
		TConnect_Billingpage.goToBilling();
		TConnectInvoice.goToInvoice();
		
	}
}