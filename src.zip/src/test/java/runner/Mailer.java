package runner;

import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.apache.commons.mail.MultiPartEmail;
import org.junit.Test;
import utils.TimeStampFormat;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Mailer {
    String result = "";
    InputStream inputStream;

    @Test
    public void sendEmailWithAttachments() throws EmailException, InterruptedException, IOException {

        Properties prop = new Properties();
        String propFileName = "config.properties";
        try {
            prop.load(getClass().getClassLoader().getResourceAsStream(propFileName));
        } catch (IOException e) {
            e.printStackTrace();
        }

        int ccCount=Integer.parseInt(prop.getProperty("ccCount"));
        EmailAttachment attachment = new EmailAttachment();
        attachment.setPath(prop.getProperty("filePath")+prop.getProperty("fileName")+".html");
        attachment.setDisposition(EmailAttachment.ATTACHMENT);
        MultiPartEmail email = new HtmlEmail();
        email.setDebug(true);
        email.setHostName("smtp.smart-rr.in.telstra.com.au");
        email.addTo(prop.getProperty("addTo"));
        for (int i=0;i<ccCount;i++) {
            String propCC="addCC"+(i+1);
            System.out.println(i);
            email.addCc(prop.getProperty(propCC));
        }
        email.setFrom(prop.getProperty("setFrom"), prop.getProperty("setFromName"));
        email.setSubject(prop.getProperty("setSubject"));
        email.setMsg(prop.getProperty("setMsg"));
        email.attach(attachment);
        email.send();
        System.out.println("Email Sent");
        TimeStampFormat.dateFormat();

        File f1 = new File(prop.getProperty("filePath")+prop.getProperty("fileName")+".html");
        File f2 = new File(prop.getProperty("filePath")+prop.getProperty("fileName")+"_"+ TimeStampFormat.dateFormat()+".html");
        boolean b = f1.renameTo(f2);
        System.out.println("File Name Changed");
    }


}