package runner;

import com.cucumber.listener.ExtentProperties;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import yaml.YamlReader;

import java.io.File;

@RunWith(Cucumber.class)
@CucumberOptions(format = { "pretty", "html:target/cucumber" }, glue = { "stepDefinitionsUI" }, features = { "@rerun.txt" }, plugin = { "com.cucumber.listener.ExtentCucumberFormatter:", "rerun:rerun.txt" })

public class RunnerFailedTest
{
	static YamlReader yamlreader;

	@AfterClass
	public static void postRun()
	{

		com.cucumber.listener.Reporter.loadXMLConfig(new File("src/test/resources/extentConfig.xml"));
		com.cucumber.listener.Reporter.setSystemInfo("user", System.getProperty("user.name"));
		com.cucumber.listener.Reporter.setTestRunnerOutput("Run U2C E2E Tests");
	}

	@BeforeClass
	public static void setup()
	{
		try
		{
			ExtentProperties extentProperties = ExtentProperties.INSTANCE;
			extentProperties.setReportPath("testReports/U2C_Automated_Test_Report.html");
			yamlreader = new YamlReader();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
