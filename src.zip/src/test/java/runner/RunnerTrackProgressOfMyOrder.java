package runner;

import com.cucumber.listener.ExtentProperties;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import java.io.File;

@RunWith(Cucumber.class)
@CucumberOptions(
        format = { "pretty", "html:target/cucumber" },
        glue = "stepDefinitions",
        features = "classpath:customerExperienceScenarios/TrackProgressOfMyOrder.feature",
        plugin = {"com.cucumber.listener.ExtentCucumberFormatter:testReports/B2B_Customer_Experience_Test_Report.html"}
)

public class RunnerTrackProgressOfMyOrder {
    @AfterClass
    public static void postRun() {

        com.cucumber.listener.Reporter.loadXMLConfig(new File(System.getProperty("user.dir")+"/configs/extentConfigCX.xml"));
        com.cucumber.listener.Reporter.setSystemInfo("user", System.getProperty("user.name"));
        com.cucumber.listener.Reporter.setTestRunnerOutput("Run B2B Customer Experience Tests");
    }

    @BeforeClass
    public static void setup() {
        ExtentProperties extentProperties = ExtentProperties.INSTANCE;
        extentProperties.setReportPath(System.getProperty("user.dir") +"/test-output/SampleExtentReport.html");
    }
}
