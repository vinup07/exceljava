package ui_ocs;

import uiUtils.Browsers;
import uiUtils.Driver;
import uiUtils.Pages;
import apiUtils.ApiUtils;
import apiUtils.GlobalConstants;
import dataProviders.ConfigFileReader;
import groovyjarjarantlr.collections.List;

import org.slf4j.Logger;
import org.junit.Assert;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.LoggerFactory;
import java.io.*;
import java.security.*;
import static org.junit.Assert.assertEquals;

public class OcsLogin extends Driver {
	
		private static final Logger LOG = LoggerFactory.getLogger(OcsLogin.class);
		public static String OcsViewSubscriber;
		public static String invoices;
		public static String payments;
		public static String adjustments;
		static WebDriverWait wait = new WebDriverWait(driver, 25);
		
		public static void ocsViewsubscriber() throws InterruptedException
		{
			
			Thread.sleep(5000);
			WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(Pages.OcsViewSubscriberProfile));
			element.click();
			Thread.sleep(5000);
			driver.findElement(Pages.Ocsmsisdn).sendKeys("61363410511");
			driver.findElement(Pages.OcsNode).click();
			driver.findElement(Pages.OcsViewSubscriber).submit();
			//Thread.sleep(5000);
			//driver.quit();
		}

	}

   







